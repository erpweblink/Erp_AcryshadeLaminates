-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[AUTH_TOKEN_MASTER]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[AUTH_TOKEN_MASTER](
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
	[UserName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[TokenExpiry] [datetime] NOT NULL,
	[Sek] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[ClientId] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[AuthToken] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
 CONSTRAINT [PK_AUTH_TOKEN_MASTER] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[AUTH_TOKEN_MASTER]
SET IDENTITY_INSERT dbo.AUTH_TOKEN_MASTER ON;

INSERT INTO dbo.AUTH_TOKEN_MASTER (ID, UserName, TokenExpiry, Sek, ClientId, AuthToken) VALUES (10007, 'API_WLSPL', '6/11/2026 4:34:21 PM', 'hNeaeVJjLjTJH25aIM0n/UiT6cmFxwgZLY3WZItq4vGa74Y49fXij9AmpEf8Id4c', 'TERAS67GSPNMFGP', '17Rq7HUHWmW2np5PDILTSQ5WX');

SET IDENTITY_INSERT dbo.AUTH_TOKEN_MASTER OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_AssignedMachines]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_AssignedMachines](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MachineID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[OperatorID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FromDate] [date] NULL,
	[ToDate] [date] NULL,
	[FromTime] [time](0) NULL,
	[ToTime] [time](0) NULL,
	[CreatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[IsDeleted] [bit] NULL,
	[DeletedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DeletedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_AssignedMachines]
SET IDENTITY_INSERT dbo.tbl_AssignedMachines ON;

INSERT INTO dbo.tbl_AssignedMachines (ID, MachineID, OperatorID, FromDate, ToDate, FromTime, ToTime, CreatedBy, CreatedOn, IsDeleted, DeletedBy, DeletedOn) VALUES (1, '1', '5', '6/5/2026 12:00:00 AM', '6/6/2026 12:00:00 AM', 09:00:00, 20:00:00, '1', '6/5/2026 4:13:18 PM', 0, NULL, NULL);
INSERT INTO dbo.tbl_AssignedMachines (ID, MachineID, OperatorID, FromDate, ToDate, FromTime, ToTime, CreatedBy, CreatedOn, IsDeleted, DeletedBy, DeletedOn) VALUES (2, '2', '6', '6/10/2026 12:00:00 AM', '6/16/2026 12:00:00 AM', 09:00:00, 22:00:00, '1', '6/10/2026 12:38:48 PM', 0, NULL, NULL);
INSERT INTO dbo.tbl_AssignedMachines (ID, MachineID, OperatorID, FromDate, ToDate, FromTime, ToTime, CreatedBy, CreatedOn, IsDeleted, DeletedBy, DeletedOn) VALUES (3, '3', '7', '6/19/2026 12:00:00 AM', '6/22/2026 12:00:00 AM', 09:00:00, 18:30:00, '1', '6/19/2026 5:24:10 PM', 0, NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_AssignedMachines OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_AuthPages]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_AuthPages](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MenuName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PageName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_AuthPages]
SET IDENTITY_INSERT dbo.tbl_AuthPages ON;

INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (1, 'Dashboard', 'Dashboard.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (2, 'Roles', 'RoleMaster.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (3, 'Users', 'UserList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (4, 'Dealers', 'DealerList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (5, 'Sub Dealers', 'CompanyList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (6, 'Stages', 'StageList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (7, 'Machine', 'MachineList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (8, 'Raw Material', 'RawMaterialList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (9, 'Products', 'ProductList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (10, 'Transporter', 'TransporterList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (11, 'Work Order', 'WorkOrderList.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (12, 'Place Order', 'PlaceOrder.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (13, 'Assign Machine', 'AssignMachine.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (14, 'Approve Designs', 'WorkOrdrForDesign.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (15, 'Start Production', 'AssignWorkOrder.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (16, 'Production Stage 1', 'WoProductionS1.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (17, 'Production Stage 2', 'WoProductionS2.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (18, 'Packaging', 'Packaging.aspx');
INSERT INTO dbo.tbl_AuthPages (ID, MenuName, PageName) VALUES (19, 'User Authorization', 'UserAuthorization.aspx');

SET IDENTITY_INSERT dbo.tbl_AuthPages OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_CompanyContactDtls]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_CompanyContactDtls](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[HeaderID] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FName] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MobileNo] [nvarchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[EmialID] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Department] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Designation] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_CompanyContactDtls]
SET IDENTITY_INSERT dbo.tbl_CompanyContactDtls ON;

INSERT INTO dbo.tbl_CompanyContactDtls (ID, HeaderID, FName, MobileNo, EmialID, Department, Designation) VALUES (1, '1', 'Test', '9876543210', 'test@gmail.com', 'Testing', 'TestEngineer');
INSERT INTO dbo.tbl_CompanyContactDtls (ID, HeaderID, FName, MobileNo, EmialID, Department, Designation) VALUES (2, '2', 'Jack', '8765432109', 'jack@gmail.com', 'Admin', 'Manager');
INSERT INTO dbo.tbl_CompanyContactDtls (ID, HeaderID, FName, MobileNo, EmialID, Department, Designation) VALUES (4, '3', 'vaibhav', '7249175111', 'hfjksdhk@gmail.com', 'sale s', 'Manager');
INSERT INTO dbo.tbl_CompanyContactDtls (ID, HeaderID, FName, MobileNo, EmialID, Department, Designation) VALUES (5, '7', 'ABC', '9876543210', 'abc@gmail.com', 'Admin', 'HR');

SET IDENTITY_INSERT dbo.tbl_CompanyContactDtls OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_CompanyDetails]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_CompanyDetails](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[HeaderID] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillAddress] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillArea] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillPinCode] [nvarchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillCity] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillState] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillCountry] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillGSTNo] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipAddress] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipArea] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipPinCode] [nvarchar](25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipCity] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipState] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipCountry] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipGSTNo] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK__tbl_Comp__3214EC278DED5DF9] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_CompanyDetails]
SET IDENTITY_INSERT dbo.tbl_CompanyDetails ON;

INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (1, '1', 'John DoePlot No. 12, ABC Complex,M.G. Road, Pune - 411001, Maharashtra', 'Pune', '422009', 'Nashik', 'Maharashtra', 'India', '29AAACR7043R1ZP', 'John DoePlot No. 12, ABC Complex,M.G. Road, Pune - 411001, Maharashtra', 'Pune', '422009', 'Nashik', 'Maharashtra', 'India', '29AAACR7043R1ZP');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (2, '2', 'Jane Smith123 Anytown Ave, Apt 4BSpringfield, IL 62704, United States', 'Pune', '411057', 'Pune', 'Maharashtra', 'India', '29AAACB1534F1Z5', 'Jane Smith123 Anytown Ave, Apt 4BSpringfield, IL 62704, United States', 'Pune', '411057', 'Pune', 'Maharashtra', 'India', '29AAACB1534F1Z5');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (5, '3', 'bhosari', 'Bhosarigoan', '411039', 'Pune', 'Maharashtra', 'India', '27AAIFP8828K1ZK', 'bhosari', 'Bhosarigoan', '411039', 'Pune', 'Maharashtra', 'India', '27AAIFP8828K1ZK');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (6, '3', 'moshi', 'moshi', '411026', 'Pune', 'Maharashtra', 'India', '', 'moshi', 'moshi', '411026', 'Pune', 'Maharashtra', 'India', '');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (7, '4', 'Sr.No 547/685 Vikas Puri colony', 'Baroda House, Bengali Market, Bhagat Singh Market, Connaught Place, Constitution House, Election Commission, Janpath, Krishi Bhawan, Lady Harding Medical College, New Delhi , North Avenue, Parliament House, Patiala House, Pragati Maidan, Pragati Maidan Camp, Rail Bhawan, Sansad Marg, Sansadiya Soudh, Secretariat North, Shastri Bhawan, Supreme Court', '110001', 'Central Delhi', 'Delhi', 'India', '07BDQPK7215K1Z4', 'Sr.No. 658/856 Central Delhi', 'A.G.C.R., Ajmeri Gate Extn., Darya Ganj, Gandhi Smarak Nidhi, I.P.Estate, Indraprastha, Minto Road', '110002', 'Central Delhi', 'Delhi', 'India', '');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (11, '6', 'Ahmedabad , Dariapur (Ahmedabad), District Court (Ahmedabad), Gandhi Road (Ahmedabad), Gheekanta Road, Jamalpur (Ahmedabad), Kalupur Chakla, Khadia, Khanpur (Ahmedabad), Lal Darwaja, Manek Chowk, Municipal Corporation, Raikhad, Raipur (Ahmedabad)', 'Ahmedabad , Dariapur (Ahmedabad), District Court (Ahmedabad), Gandhi Road (Ahmedabad), Gheekanta Road, Jamalpur (Ahmedabad), Kalupur Chakla, Khadia, Khanpur (Ahmedabad), Lal Darwaja, Manek Chowk, Municipal Corporation, Raikhad, Raipur (Ahmedabad)', '380001', 'Ahmedabad', 'Gujarat', 'India', '24ABCDE1234F1Z5', 'Ahmedabad , Dariapur (Ahmedabad), District Court (Ahmedabad), Gandhi Road (Ahmedabad), Gheekanta Road, Jamalpur (Ahmedabad), Kalupur Chakla, Khadia, Khanpur (Ahmedabad), Lal Darwaja, Manek Chowk, Municipal Corporation, Raikhad, Raipur (Ahmedabad)', 'Ahmedabad , Dariapur (Ahmedabad), District Court (Ahmedabad), Gandhi Road (Ahmedabad), Gheekanta Road, Jamalpur (Ahmedabad), Kalupur Chakla, Khadia, Khanpur (Ahmedabad), Lal Darwaja, Manek Chowk, Municipal Corporation, Raikhad, Raipur (Ahmedabad)', '380001', 'Ahmedabad', 'Gujarat', 'India', '24ABCDE1234F1Z5');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (12, '6', 'Baranpura, Khanderao Market, Madanzampa, Mandvi (Vadodara), SRP Group I, Vadodara', 'Baranpura, Khanderao Market, Madanzampa, Mandvi (Vadodara), SRP Group I, Vadodara', '390001', 'Vadodara', 'Gujarat', 'India', '24ABCDE1234F1Z5', 'Baranpura, Khanderao Market, Madanzampa, Mandvi (Vadodara), SRP Group I, Vadodara', 'Baranpura, Khanderao Market, Madanzampa, Mandvi (Vadodara), SRP Group I, Vadodara', '390001', 'Vadodara', 'Gujarat', 'India', '24ABCDE1234F1Z8');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (18, '7', 'Ahmedabad , Dariapur (Ahmedabad), District Court (Ahmedabad), Gandhi Road (Ahmedabad), Gheekanta Road, Jamalpur (Ahmedabad), Kalupur Chakla, Khadia, Khanpur (Ahmedabad), Lal Darwaja, Manek Chowk, Municipal Corporation, Raikhad, Raipur (Ahmedabad)', 'Ahmedabad , Dariapur (Ahmedabad), District Court (Ahmedabad), Gandhi Road (Ahmedabad), Gheekanta Road, Jamalpur (Ahmedabad), Kalupur Chakla, Khadia, Khanpur (Ahmedabad), Lal Darwaja, Manek Chowk, Municipal Corporation, Raikhad, Raipur (Ahmedabad)', '380001', 'Ahmedabad', 'Gujarat', 'India', '24ABCDE1234F1Z5', 'Ahmedabad , Dariapur (Ahmedabad), District Court (Ahmedabad), Gandhi Road (Ahmedabad), Gheekanta Road, Jamalpur (Ahmedabad), Kalupur Chakla, Khadia, Khanpur (Ahmedabad), Lal Darwaja, Manek Chowk, Municipal Corporation, Raikhad, Raipur (Ahmedabad)', 'Ahmedabad , Dariapur (Ahmedabad), District Court (Ahmedabad), Gandhi Road (Ahmedabad), Gheekanta Road, Jamalpur (Ahmedabad), Kalupur Chakla, Khadia, Khanpur (Ahmedabad), Lal Darwaja, Manek Chowk, Municipal Corporation, Raikhad, Raipur (Ahmedabad)', '380001', 'Ahmedabad', 'Gujarat', 'India', '24ABCDE1234F1Z5');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (19, '7', 'Baranpura, Khanderao Market, Madanzampa, Mandvi (Vadodara), SRP Group I, Vadodara', 'Baranpura, Khanderao Market, Madanzampa, Mandvi (Vadodara), SRP Group I, Vadodara', '390001', 'Vadodara', 'Gujarat', 'India', '24ABCDE1234F1Z5', 'Baranpura, Khanderao Market, Madanzampa, Mandvi (Vadodara), SRP Group I, Vadodara', 'Baranpura, Khanderao Market, Madanzampa, Mandvi (Vadodara), SRP Group I, Vadodara', '390001', 'Vadodara', 'Gujarat', 'India', '24ABCDE1234F1Z5');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (20, '7', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Gandhinagar (Gujarat), New Sachivalaya Complex, Vibrant Gujarat, Vidhansabha', 'Gandhinagar (Gujarat), New Sachivalaya Complex, Vibrant Gujarat, Vidhansabha', '382010', 'Gandhi Nagar', 'Gujarat', 'India', '24ABCDE1234F1Z5');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (21, '5', 'A.G.C.R., Ajmeri Gate Extn., Darya Ganj, Gandhi Smarak Nidhi, I.P.Estate, Indraprastha, Minto Road', 'A.G.C.R., Ajmeri Gate Extn., Darya Ganj, Gandhi Smarak Nidhi, I.P.Estate, Indraprastha, Minto Road', '110002', 'Central Delhi', 'Delhi', 'India', '07BDQPK7215K1Z4', 'Anand Parbat Indl. Area, Bank Street (Central Delhi), Desh Bandhu Gupta Road, Guru Gobind Singh Marg, Karol Bagh, Master Prithvi Nath Marg', 'Anand Parbat, Anand Parbat Indl. Area, Bank Street (Central Delhi), Desh Bandhu Gupta Road, Guru Gobind Singh Marg, Karol Bagh, Master Prithvi Nath Marg, Sat Nagar', '110005', 'Central Delhi', 'Delhi', 'India', '07BDQPK7215K1Z4');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (22, '5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Baratooti, Chandni Chowk, Chawri Bazar, Dareeba, Delhi , Delhi Sadar Bazar, Hauz Qazi, Jama Masjid, S.T. Road', 'Baratooti, Chandni Chowk, Chawri Bazar, Dareeba, Delhi , Delhi Sadar Bazar, Hauz Qazi, Jama Masjid, S.T. Road', '110006', 'North Delhi', 'Delhi', 'India', '');
INSERT INTO dbo.tbl_CompanyDetails (ID, HeaderID, BillAddress, BillArea, BillPinCode, BillCity, BillState, BillCountry, BillGSTNo, ShipAddress, ShipArea, ShipPinCode, ShipCity, ShipState, ShipCountry, ShipGSTNo) VALUES (23, '5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'I.A.R.I., Inderpuri, National Physical Laboratory', 'I.A.R.I., Inderpuri, National Physical Laboratory', '110012', 'Central Delhi', 'Delhi', 'India', '');

SET IDENTITY_INSERT dbo.tbl_CompanyDetails OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_CompanyMain]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_CompanyMain](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CompanyCode] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompanyName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[OwnerName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompanyOrigin] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompanyEmialId] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompanyPanCard] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PaymentTerms] [nvarchar](1000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UDYAMNo] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CINNo] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WebsiteLink] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
 CONSTRAINT [PK__tbl_Comp__3214EC27D03F1F2E] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_CompanyMain]
SET IDENTITY_INSERT dbo.tbl_CompanyMain ON;

INSERT INTO dbo.tbl_CompanyMain (ID, CompanyCode, CompanyName, OwnerName, CompanyOrigin, CompanyEmialId, CompanyPanCard, PaymentTerms, UDYAMNo, CINNo, WebsiteLink, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (1, '2026-27/001', 'ABC Pvt.Ltd.', 'Testing', 'Domestic', '', '', '', '', NULL, '', 0, '1', '6/2/2026 11:28:56 AM', NULL, NULL);
INSERT INTO dbo.tbl_CompanyMain (ID, CompanyCode, CompanyName, OwnerName, CompanyOrigin, CompanyEmialId, CompanyPanCard, PaymentTerms, UDYAMNo, CINNo, WebsiteLink, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (2, '2026-27/002', 'PQR Pvt.Ltd.', 'Mr. John', 'Domestic', '', '', '', '', NULL, '', 0, '2', '6/2/2026 11:31:22 AM', NULL, NULL);
INSERT INTO dbo.tbl_CompanyMain (ID, CompanyCode, CompanyName, OwnerName, CompanyOrigin, CompanyEmialId, CompanyPanCard, PaymentTerms, UDYAMNo, CINNo, WebsiteLink, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (3, '2026-27/003', 'sgso internlm', 'vaibhav', 'Domestic', '', '', '', '', NULL, '', 0, '1', '6/8/2026 5:10:38 PM', '1', '6/11/2026 12:03:18 PM');
INSERT INTO dbo.tbl_CompanyMain (ID, CompanyCode, CompanyName, OwnerName, CompanyOrigin, CompanyEmialId, CompanyPanCard, PaymentTerms, UDYAMNo, CINNo, WebsiteLink, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (4, '2026-27/004', 'Kapoors and Sons', 'Kapoors', 'Domestic', '', '', '', '', NULL, '', 0, '1', '6/11/2026 12:21:21 PM', NULL, NULL);
INSERT INTO dbo.tbl_CompanyMain (ID, CompanyCode, CompanyName, OwnerName, CompanyOrigin, CompanyEmialId, CompanyPanCard, PaymentTerms, UDYAMNo, CINNo, WebsiteLink, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (5, '2026-27/005', 'Menon and Menon', 'Mr.Menon', 'Domestic', '', '', '', '', NULL, '', 0, '1', '6/11/2026 2:12:09 PM', '1', '6/11/2026 3:11:15 PM');
INSERT INTO dbo.tbl_CompanyMain (ID, CompanyCode, CompanyName, OwnerName, CompanyOrigin, CompanyEmialId, CompanyPanCard, PaymentTerms, UDYAMNo, CINNo, WebsiteLink, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (6, '2026-27/006', 'LEANBOTZ INDIA PRIVATE LIMITED', 'Mr. Javed S. Sayyad', 'Domestic', '', '', '', '', NULL, '', 0, '1', '6/11/2026 2:28:12 PM', NULL, NULL);
INSERT INTO dbo.tbl_CompanyMain (ID, CompanyCode, CompanyName, OwnerName, CompanyOrigin, CompanyEmialId, CompanyPanCard, PaymentTerms, UDYAMNo, CINNo, WebsiteLink, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (7, '2026-27/007', 'LEANBOTZ INDIA PRIVATE LIMITED', 'Mr. Javed S. Sayyad', 'Domestic', '', '', '', '', NULL, '', 0, '1', '6/11/2026 2:28:27 PM', '1', '6/11/2026 3:06:28 PM');

SET IDENTITY_INSERT dbo.tbl_CompanyMain OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_DealersOrderDTLs]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_DealersOrderDTLs](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[HeaderID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductType] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Qty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductNote] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ImagePathName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_DealersOrderDTLs]
SET IDENTITY_INSERT dbo.tbl_DealersOrderDTLs ON;


SET IDENTITY_INSERT dbo.tbl_DealersOrderDTLs OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_DealersOrderHDR]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_DealersOrderHDR](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[OrderID] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DealerID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedDate] [datetime] NULL,
	[OrderStatus] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ApproveOrNotDate] [datetime] NULL,
	[EstimatedDeliveryDate] [datetime] NULL,
 CONSTRAINT [PK__tbl_Deal__3214EC2777D7B772] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_DealersOrderHDR]
SET IDENTITY_INSERT dbo.tbl_DealersOrderHDR ON;


SET IDENTITY_INSERT dbo.tbl_DealersOrderHDR OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_DealersOrderTemp]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_DealersOrderTemp](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ProductID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductType] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Qty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductNote] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ImagePathName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DealersID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AddedDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_DealersOrderTemp]
SET IDENTITY_INSERT dbo.tbl_DealersOrderTemp ON;


SET IDENTITY_INSERT dbo.tbl_DealersOrderTemp OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineMaster]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_MachineMaster](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MachineName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MachineDescription] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MachinePerHRQty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MachineRunningHR] [nvarchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AllocatedStage] [nvarchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsActive] [bit] NULL,
	[IsActivateDate] [datetime] NULL,
	[IsDeactiveDate] [datetime] NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
	[MachineImageName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineMaster]
SET IDENTITY_INSERT dbo.tbl_MachineMaster ON;

INSERT INTO dbo.tbl_MachineMaster (ID, MachineName, MachineDescription, MachinePerHRQty, MachineRunningHR, AllocatedStage, IsActive, IsActivateDate, IsDeactiveDate, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, MachineImageName) VALUES (1, 'Machine 1', 'This is used to grinde the sheet', '15', '12', 'Stage 1 ', 1, '6/10/2026 10:08:14 AM', NULL, 0, NULL, '5/29/2026 12:52:45 PM', '1', '6/26/2026 2:16:07 PM', '');
INSERT INTO dbo.tbl_MachineMaster (ID, MachineName, MachineDescription, MachinePerHRQty, MachineRunningHR, AllocatedStage, IsActive, IsActivateDate, IsDeactiveDate, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, MachineImageName) VALUES (2, 'Machine 2', 'This machine is used to attach the sheet', '15', '12', 'Stage 1 ', 1, '6/1/2026 10:57:07 AM', NULL, 0, NULL, '5/29/2026 1:59:56 PM', '1', '6/26/2026 2:00:38 PM', '');
INSERT INTO dbo.tbl_MachineMaster (ID, MachineName, MachineDescription, MachinePerHRQty, MachineRunningHR, AllocatedStage, IsActive, IsActivateDate, IsDeactiveDate, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, MachineImageName) VALUES (3, 'Machine 3', 'Printing Machine for stage 2', '200', '8', 'Stage 2', 1, '6/10/2026 10:03:55 AM', NULL, 0, NULL, '6/1/2026 10:58:36 AM', '1', '6/19/2026 12:31:25 PM', '~/MachineImages/afd89a41-0798-4fb7-a811-be6cf800cee4_videoframe_6064.png');

SET IDENTITY_INSERT dbo.tbl_MachineMaster OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineProductionAllocation]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_MachineProductionAllocation](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ProductDtlID] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MachineID] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AllocatedQty] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AllocatedSqFeet] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompletedQty] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompletedSqFeet] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompletedDate] [datetime] NULL,
	[NextStageId] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineProductionAllocation]
SET IDENTITY_INSERT dbo.tbl_MachineProductionAllocation ON;

INSERT INTO dbo.tbl_MachineProductionAllocation (ID, ProductDtlID, MachineID, AllocatedQty, AllocatedSqFeet, CompletedQty, CompletedSqFeet, CompletedDate, NextStageId) VALUES (1, '1', '1', '5', '40', '2', '16', NULL, NULL);
INSERT INTO dbo.tbl_MachineProductionAllocation (ID, ProductDtlID, MachineID, AllocatedQty, AllocatedSqFeet, CompletedQty, CompletedSqFeet, CompletedDate, NextStageId) VALUES (2, '2', '1', '4', '128', '0', '0', NULL, NULL);
INSERT INTO dbo.tbl_MachineProductionAllocation (ID, ProductDtlID, MachineID, AllocatedQty, AllocatedSqFeet, CompletedQty, CompletedSqFeet, CompletedDate, NextStageId) VALUES (3, '2', '2', '1', '32', '0', '0', NULL, NULL);
INSERT INTO dbo.tbl_MachineProductionAllocation (ID, ProductDtlID, MachineID, AllocatedQty, AllocatedSqFeet, CompletedQty, CompletedSqFeet, CompletedDate, NextStageId) VALUES (4, '3', '2', '2', '64', '0', '0', NULL, NULL);
INSERT INTO dbo.tbl_MachineProductionAllocation (ID, ProductDtlID, MachineID, AllocatedQty, AllocatedSqFeet, CompletedQty, CompletedSqFeet, CompletedDate, NextStageId) VALUES (5, '4', '2', '1', '32', '0', '0', NULL, NULL);
INSERT INTO dbo.tbl_MachineProductionAllocation (ID, ProductDtlID, MachineID, AllocatedQty, AllocatedSqFeet, CompletedQty, CompletedSqFeet, CompletedDate, NextStageId) VALUES (6, '5', '2', '1', '32', '0', '0', NULL, NULL);
INSERT INTO dbo.tbl_MachineProductionAllocation (ID, ProductDtlID, MachineID, AllocatedQty, AllocatedSqFeet, CompletedQty, CompletedSqFeet, CompletedDate, NextStageId) VALUES (7, '1', '3', '2', '16', NULL, NULL, NULL, '1');

SET IDENTITY_INSERT dbo.tbl_MachineProductionAllocation OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineProductionDTLS]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_MachineProductionDTLS](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[HeaderID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductName] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[TotalQty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[SqFeet] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AllocatedQty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AllocatedSqFeet] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Stage1MachineID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Stage1CompletedQty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Stage1CompetedSqFeet] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Stage1CompletedDate] [datetime] NULL,
	[Stage2MachineID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Stage2CompletedQty] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Stage2CompetedSqFeet] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Stage2CompletedDate] [datetime] NULL,
 CONSTRAINT [PK__tbl_Mach__3214EC2792253968] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineProductionDTLS]
SET IDENTITY_INSERT dbo.tbl_MachineProductionDTLS ON;

INSERT INTO dbo.tbl_MachineProductionDTLS (ID, HeaderID, ProductName, Size, TotalQty, SqFeet, AllocatedQty, AllocatedSqFeet, Stage1MachineID, Stage1CompletedQty, Stage1CompetedSqFeet, Stage1CompletedDate, Stage2MachineID, Stage2CompletedQty, Stage2CompetedSqFeet, Stage2CompletedDate) VALUES (1, '1', 'AS 3D 105 Acrylic Laminates', '2x4', '5', '40', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_MachineProductionDTLS (ID, HeaderID, ProductName, Size, TotalQty, SqFeet, AllocatedQty, AllocatedSqFeet, Stage1MachineID, Stage1CompletedQty, Stage1CompetedSqFeet, Stage1CompletedDate, Stage2MachineID, Stage2CompletedQty, Stage2CompetedSqFeet, Stage2CompletedDate) VALUES (2, '1', 'AS 3D 116 Acrylic Laminates', '4x8', '5', '160', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_MachineProductionDTLS (ID, HeaderID, ProductName, Size, TotalQty, SqFeet, AllocatedQty, AllocatedSqFeet, Stage1MachineID, Stage1CompletedQty, Stage1CompetedSqFeet, Stage1CompletedDate, Stage2MachineID, Stage2CompletedQty, Stage2CompetedSqFeet, Stage2CompletedDate) VALUES (3, '2', 'AS HD 074(A) Textura Sheet', '8x4', '2', '64', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_MachineProductionDTLS (ID, HeaderID, ProductName, Size, TotalQty, SqFeet, AllocatedQty, AllocatedSqFeet, Stage1MachineID, Stage1CompletedQty, Stage1CompetedSqFeet, Stage1CompletedDate, Stage2MachineID, Stage2CompletedQty, Stage2CompetedSqFeet, Stage2CompletedDate) VALUES (4, '2', 'AS HD 073(B) Textura Sheet', '8x4', '1', '32', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_MachineProductionDTLS (ID, HeaderID, ProductName, Size, TotalQty, SqFeet, AllocatedQty, AllocatedSqFeet, Stage1MachineID, Stage1CompletedQty, Stage1CompetedSqFeet, Stage1CompletedDate, Stage2MachineID, Stage2CompletedQty, Stage2CompetedSqFeet, Stage2CompletedDate) VALUES (5, '2', 'AS HD 066(A) Textura Sheet', '8x4', '2', '64', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_MachineProductionDTLS OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineProductionHDR]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_MachineProductionHDR](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[WorkOrderID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WorkOrderNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RankSrNo] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[AssignedDate] [date] NULL,
	[S1Status] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[S2Status] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK__tbl_Mach__3214EC279B240748] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineProductionHDR]
SET IDENTITY_INSERT dbo.tbl_MachineProductionHDR ON;

INSERT INTO dbo.tbl_MachineProductionHDR (ID, WorkOrderID, WorkOrderNo, RankSrNo, AssignedDate, S1Status, S2Status) VALUES (1, '4', 'WO/2026-27/003', NULL, '6/26/2026 12:00:00 AM', 'Machine Allocated', NULL);
INSERT INTO dbo.tbl_MachineProductionHDR (ID, WorkOrderID, WorkOrderNo, RankSrNo, AssignedDate, S1Status, S2Status) VALUES (2, '7', 'WO/2026-27/12345', NULL, '6/26/2026 12:00:00 AM', 'Machine Allocated', NULL);

SET IDENTITY_INSERT dbo.tbl_MachineProductionHDR OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_ProdcutMaster]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_ProdcutMaster](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Productcode] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductCategory] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Productname] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Thickness] [nchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PartNo] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PartName] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ImagenamePath] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsActive] [bit] NULL,
	[isdeleted] [bit] NULL,
	[Createdon] [datetime] NULL,
	[CreatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
	[FavoriteProduct] [bit] NULL,
	[FavoriteProductRank] [int] NULL,
 CONSTRAINT [PK_tbl_prodcutmaster_1] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_ProdcutMaster]
SET IDENTITY_INSERT dbo.tbl_ProdcutMaster ON;

INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (1, 'P001', 'Textura Sheet', 'AS HD 065(A) Textura Sheet', '15        ', 'N/A', 'N/A', '8x4', '~/MyProducts/0b0c7ff4-e2cd-4db4-81d4-a79a41be2a47.jpg', 1, 0, '6/20/2026 11:16:59 AM', '1', '1', '6/20/2026 11:49:53 AM', 0, 0);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (2, 'P002', 'Textura Sheet', 'AS HD 066(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/7bcdddf3-506e-4fd2-a28c-d863cbc9998d.jpg', 1, 0, '6/20/2026 11:56:00 AM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (3, 'P003', 'Textura Sheet', 'AS HD 067(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/14f14a7e-4188-4f56-a43c-1a6c4f73f600.jpg', 1, 0, '6/20/2026 11:56:50 AM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (4, 'P004', 'Textura Sheet', 'AS HD 068(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/cc8cadc5-fb0d-4a89-b369-ad76906e91be.jpg', 1, 0, '6/20/2026 11:57:22 AM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (5, 'P005', 'Textura Sheet', 'AS HD 068(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/57adbd84-ac89-4c31-9ed9-ca3b97194925.jpg', 1, 0, '6/20/2026 11:57:52 AM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (6, 'P006', 'Textura Sheet', 'AS HD 069(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/1c058b03-ee86-41d1-a019-de197ceadb9e.jpg', 1, 0, '6/20/2026 12:01:51 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (7, 'P007', 'Textura Sheet', 'AS HD 069(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/16895ec8-f948-4bba-a043-5f714e31735d.jpg', 1, 0, '6/20/2026 12:02:12 PM', '1', NULL, NULL, 0, 0);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (8, 'P008', 'Textura Sheet', 'AS HD 070(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/6d0ccd24-a479-4d48-b639-343dd1e3056a.jpg', 1, 0, '6/20/2026 12:02:31 PM', '1', NULL, NULL, 0, 0);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (9, 'P009', 'Textura Sheet', 'AS HD 070(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/b044f525-ac6f-4752-858e-3f8ad4d58e65.jpg', 1, 0, '6/20/2026 12:02:54 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (10, 'P010', 'Textura Sheet', 'AS HD 071(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/c7fe4585-4ee4-4903-94a2-169a5969f0e5.jpg', 1, 0, '6/20/2026 12:03:14 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (11, 'P011', 'Textura Sheet', 'AS HD 072(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/02a18cca-56cf-4632-b9e6-cebd923f0f93.jpg', 1, 0, '6/20/2026 12:03:42 PM', '1', NULL, NULL, 0, 0);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (12, 'P012', 'Textura Sheet', 'AS HD 072(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/b41f4907-7de9-4939-a6d5-92cc5d5cecde.jpg', 1, 0, '6/20/2026 12:04:05 PM', '1', NULL, NULL, 0, 0);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (13, 'P013', 'Textura Sheet', 'AS HD 073(B) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/a226da13-7d89-4934-a543-3130db02a0eb.jpg', 1, 0, '6/20/2026 12:41:42 PM', '1', NULL, NULL, 1, 2);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (14, 'P014', 'Textura Sheet', 'AS HD 073(C) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/2f8990b6-4f37-4c65-b9c9-a69659cf240b.jpg', 1, 0, '6/20/2026 4:29:31 PM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (15, 'P015', 'Textura Sheet', 'AS HD 073(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/cef2e48f-98fa-4c8d-8c4d-b2e45d89f036.jpg', 1, 0, '6/20/2026 4:30:16 PM', '1', NULL, NULL, 0, 0);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (16, 'P016', 'Textura Sheet', 'Acryalic Sheet', '          ', '', '', '8x2', NULL, 1, 1, '6/22/2026 10:03:50 AM', '1', NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_ProdcutMaster (ID, Productcode, ProductCategory, Productname, Thickness, PartNo, PartName, Size, ImagenamePath, IsActive, isdeleted, Createdon, CreatedBy, UpdatedBy, UpdatedOn, FavoriteProduct, FavoriteProductRank) VALUES (17, 'P017', 'Textura Sheet', 'AS HD 074(A) Textura Sheet', '          ', '', '', '8x4', '~/MyProducts/d330cac1-842e-448a-bafc-c1ab24ea3b1d_AS HD 074A.jpg', 1, 0, '6/23/2026 5:14:58 PM', '1', NULL, NULL, 1, 1);

SET IDENTITY_INSERT dbo.tbl_ProdcutMaster OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_ProductionInatial]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_ProductionInatial](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[WorkOrderId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WorkOrderNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[TotalQty] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_ProductionInatial]
SET IDENTITY_INSERT dbo.tbl_ProductionInatial ON;


SET IDENTITY_INSERT dbo.tbl_ProductionInatial OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_ProductionMachineLoading]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_ProductionMachineLoading](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[ProductionPlanId] [int] NULL,
	[WorkOrderId] [int] NULL,
	[MachineId] [int] NULL,
	[AllocatedStage] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ScheduleDate] [datetime] NULL,
	[PlannedQty] [decimal](18, 2) NULL,
	[ProducedQty] [decimal](18, 2) NULL,
	[Status] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK__tbl_Prod__3214EC0755EFB886] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [dbo].[tbl_ProductionMachineLoading] ADD  CONSTRAINT [DF__tbl_Produ__Produ__671F4F74]  DEFAULT ((0)) FOR [ProducedQty]

-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_ProductionMachineLoading]
SET IDENTITY_INSERT dbo.tbl_ProductionMachineLoading ON;


SET IDENTITY_INSERT dbo.tbl_ProductionMachineLoading OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_ProductionPlan]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_ProductionPlan](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[WorkOrderId] [int] NULL,
	[ScheduleDate] [date] NULL,
	[PlannedQty] [decimal](18, 2) NULL,
	[ProducedQty] [decimal](18, 2) NULL,
	[Status] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK__tbl_Prod__3214EC070A46DA88] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE [dbo].[tbl_ProductionPlan] ADD  CONSTRAINT [DF__tbl_Produ__Produ__5D95E53A]  DEFAULT ((0)) FOR [ProducedQty]
ALTER TABLE [dbo].[tbl_ProductionPlan] ADD  CONSTRAINT [DF__tbl_Produ__Statu__5E8A0973]  DEFAULT ('Planned') FOR [Status]

-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_ProductionPlan]
SET IDENTITY_INSERT dbo.tbl_ProductionPlan ON;


SET IDENTITY_INSERT dbo.tbl_ProductionPlan OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_RawMaterial_DTLS]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_RawMaterial_DTLS](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[HeaderId] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RawMaterialName] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RawMaterialCode] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RawMaterialCategory] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RawMaterialDesc] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RawMaterialQty] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Unit] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PerQtyRate] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[GstPercentage] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[GstAmount] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK__tbl_RawM__3214EC2783192077] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_RawMaterial_DTLS]
SET IDENTITY_INSERT dbo.tbl_RawMaterial_DTLS ON;

INSERT INTO dbo.tbl_RawMaterial_DTLS (ID, HeaderId, RawMaterialName, RawMaterialCode, RawMaterialCategory, RawMaterialDesc, RawMaterialQty, Unit, PerQtyRate, GstPercentage, GstAmount) VALUES (1, '1', 'Wooden Sheet', 'WO-001', 'Wood', 'Wooden sheets ', '500', 'PCS', '0', '0', '0');
INSERT INTO dbo.tbl_RawMaterial_DTLS (ID, HeaderId, RawMaterialName, RawMaterialCode, RawMaterialCategory, RawMaterialDesc, RawMaterialQty, Unit, PerQtyRate, GstPercentage, GstAmount) VALUES (2, '1', 'Glue', 'GU-001', 'Adhesive', 'Pasting Glue', '5', 'LTRS', '0', '0', '0');

SET IDENTITY_INSERT dbo.tbl_RawMaterial_DTLS OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_RawMaterial_HDR]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_RawMaterial_HDR](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SupplierName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PurchaseNo] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PurchaseDate] [date] NULL,
	[IsActive] [bit] NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
 CONSTRAINT [PK__tbl_RawM__3214EC27ECBEEA37] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_RawMaterial_HDR]
SET IDENTITY_INSERT dbo.tbl_RawMaterial_HDR ON;

INSERT INTO dbo.tbl_RawMaterial_HDR (ID, SupplierName, PurchaseNo, PurchaseDate, IsActive, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (1, 'Shubham P', 'PO-2026/27-001', '6/12/2026 12:00:00 AM', 1, 0, NULL, '6/5/2026 9:46:13 AM', NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_RawMaterial_HDR OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_RoleMaster]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_RoleMaster](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Roles] [nvarchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Departments] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsDeleted] [bit] NULL,
 CONSTRAINT [PK__tbl_Role__3214EC27AD0FEC49] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_RoleMaster]
SET IDENTITY_INSERT dbo.tbl_RoleMaster ON;

INSERT INTO dbo.tbl_RoleMaster (ID, Roles, Departments, IsDeleted) VALUES (1, 'Admin', 'In-House', 0);
INSERT INTO dbo.tbl_RoleMaster (ID, Roles, Departments, IsDeleted) VALUES (2, 'Dealers', 'Outsourcing', 0);
INSERT INTO dbo.tbl_RoleMaster (ID, Roles, Departments, IsDeleted) VALUES (3, 'User', 'In-House', 0);
INSERT INTO dbo.tbl_RoleMaster (ID, Roles, Departments, IsDeleted) VALUES (4, 'SubDealer', 'Outsourcing', 0);
INSERT INTO dbo.tbl_RoleMaster (ID, Roles, Departments, IsDeleted) VALUES (5, 'Operator', 'In-House', 0);

SET IDENTITY_INSERT dbo.tbl_RoleMaster OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_Stage1Production]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_Stage1Production](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MachineId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WOHeaderId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PartNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ReceivedQty] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ReceivedDate] [datetime] NULL,
	[CompletedQty] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompletedDate] [datetime] NULL,
	[RejectedQty] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WOStatus] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[sheduledate] [date] NULL,
 CONSTRAINT [PK__tbl_Stag__3214EC278DE4B4F9] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_Stage1Production]
SET IDENTITY_INSERT dbo.tbl_Stage1Production ON;


SET IDENTITY_INSERT dbo.tbl_Stage1Production OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_Stage2Production]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_Stage2Production](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Stage1HeaderId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MachineId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WOHeaderId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PartNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ReceivedQty] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ReceivedDate] [datetime] NULL,
	[CompletedQty] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompletedDate] [datetime] NULL,
	[RejectedQty] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WOStatus] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK__tbl_Stag__3214EC27A3212BC6] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_Stage2Production]
SET IDENTITY_INSERT dbo.tbl_Stage2Production ON;


SET IDENTITY_INSERT dbo.tbl_Stage2Production OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_StageMaster]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_StageMaster](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SatgeName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[SatgeDescription] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[SatgeCapacity] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CapacityUnit] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
 CONSTRAINT [PK__tbl_Stag__3214EC2755069901] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_StageMaster]
SET IDENTITY_INSERT dbo.tbl_StageMaster ON;

INSERT INTO dbo.tbl_StageMaster (ID, SatgeName, SatgeDescription, SatgeCapacity, CapacityUnit, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (1, 'Stage 1 ', 'There are three machines working under this stage', '1000', 'KGS', 0, NULL, '5/29/2026 11:38:42 AM', NULL, NULL);
INSERT INTO dbo.tbl_StageMaster (ID, SatgeName, SatgeDescription, SatgeCapacity, CapacityUnit, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (2, 'Stage 2', 'Printing ', '120', 'NOS', 0, NULL, '6/1/2026 10:57:47 AM', NULL, NULL);
INSERT INTO dbo.tbl_StageMaster (ID, SatgeName, SatgeDescription, SatgeCapacity, CapacityUnit, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (1002, 'Stage 3', 'Quality ', '100', 'no', 0, '1', '6/8/2026 5:11:48 PM', NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_StageMaster OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_Transportermaster]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_Transportermaster](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[transporter_code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[transporter_name] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[gst_no] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[pan_no] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[contact_person] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[mobile] [nvarchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[email] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[address] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[city] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[state] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[pincode] [nvarchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[vehicle_type] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[rate_per_km] [decimal](10, 2) NULL,
	[bank_name] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[account_no] [nvarchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ifsc_code] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[status] [bit] NULL,
	[serviceRoute] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsDeleted] [bit] NULL,
	[CreatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_Transportermaster]
SET IDENTITY_INSERT dbo.tbl_Transportermaster ON;

INSERT INTO dbo.tbl_Transportermaster (id, transporter_code, transporter_name, gst_no, pan_no, contact_person, mobile, email, address, city, state, pincode, vehicle_type, rate_per_km, bank_name, account_no, ifsc_code, status, serviceRoute, IsDeleted, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn) VALUES (1, 'TR001', 'Sai Transport Services', '7ABCDE1234F1Z5', 'ABCDE1234F', 'Amit Patil', '9876543210', 'saitransport@gmail.com', 'Chakan MIDC, Pune', 'Pune', 'Maharashtra', '410501', 'Container TrucK', 28.50, 'HDFC Bank', '1234567890', 'HDFC0000123', 1, 'Pune To Nashik', 0, NULL, '5/29/2026 12:51:43 PM', '1', '6/5/2026 10:27:57 AM');

SET IDENTITY_INSERT dbo.tbl_Transportermaster OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_UserMaster]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_UserMaster](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[UserCode] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[FullName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CompanyName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MobileNo] [nvarchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[EmailId] [nvarchar](250) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[LoginPass] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Type] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[GstNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PanCardNo] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UANNo] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillAddress] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillArea] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillPinCode] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillState] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillCity] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillCountry] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipAddress] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipArea] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipPinCode] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipState] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipCity] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShipCountry] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UserRole] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RelationId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsActivate] [bit] NULL,
	[IsDeleted] [bit] NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[EmailId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_UserMaster]
SET IDENTITY_INSERT dbo.tbl_UserMaster ON;

INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (1, 'AL/2026-27/001', 'Admin', NULL, '9876543210', 'erpweblink@gmail.com', '123', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Admin', NULL, 1, 0, '5/28/2026 10:15:13 AM', NULL, '6/5/2026 9:33:24 AM', NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (2, 'AL/2026-27/002', 'TATA MOTORS PASSENGER VEHICLES LIMITED', 'TATA MOTORS PASSENGER VEHICLES LIMITED', '8765432109', 'admin@gmail.com', '9016', 'Authorized', '27AAACT2727Q1ZW', 'AACT2727Q', '00125632582002145', 'Sector No. 15 and 15A PCNTDA K Block  Chikhali Road ', 'Pimpri Chinchwad Chikhali', '411062', 'Maharashtra', 'Pimpri Chinchwad Chikhali', 'India', 'Sector No. 15 and 15A PCNTDA K Block  Chikhali Road ', 'Pimpri Chinchwad Chikhali', '411062', 'Maharashtra', 'Pimpri Chinchwad Chikhali', 'India', 'Dealers', NULL, 1, 0, NULL, 'May 28 2026  5:50PM', NULL, NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (3, 'AL/2026-27/003', 'MRUGESH LASER ENGRAVERS', 'MRUGESH LASER ENGRAVERS', '8912459610', 'MRUGESH@gmail.com', '3301', 'Authorized', '27AGCPL0333M1ZH', 'abz10oop', 'abz10oop', 'GAT NO 2 RCC GROUND FLOOR AUTOMATION & CONTROL SYSTEMS PLOT NO 144A MIDC Road ', 'Pimpri Chinchwad ', '411026', 'Maharashtra', 'Pimpri Chinchwad ', 'India', 'GAT NO 2 RCC GROUND FLOOR AUTOMATION & CONTROL SYSTEMS PLOT NO 144A MIDC Road ', 'Pimpri Chinchwad ', '411026', 'Maharashtra', 'Pimpri Chinchwad ', 'India', 'Dealers', NULL, 1, 0, NULL, 'Jun  2 2026  5:49PM', '6/5/2026 10:31:56 AM', '1');
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (4, 'AL/2026-27/004', 'Vaibhav Zope', NULL, '7249175114', 'vaibhav@weblinkservices.net', '123', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Admin', NULL, 1, 0, NULL, 'Jun  4 2026  3:53PM', NULL, NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (5, 'AL/2026-27/005', 'M/C Operator 1', NULL, '', 'opra1@gmail.com', '123', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Operator', NULL, 1, 0, '6/5/2026 2:28:16 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (6, 'AL/2026-27/006', 'M/C Operator 2', NULL, '', 'opra2@gmail.com', '111', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Operator', NULL, 1, 0, '6/5/2026 2:28:43 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (7, 'AL/2026-27/007', 'M/C Operator 3', NULL, '', 'opra3@gmail.com', '121', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Operator', NULL, 1, 0, '6/5/2026 2:29:02 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (8, 'AL/2026-27/008', 'M/C Operator 4', NULL, '', 'opra4@gmail.com', '131', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Operator', NULL, 1, 0, '6/5/2026 2:29:23 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (9, 'AL/2026-27/009', 'S.S. INSULATION', 'S.S. INSULATION', '7249175114', 'warjeoffice2026@gmail.com', '0284', 'Authorized', '27ABYPS7431A1ZA', 'ABYPS7431A', '', ' GAT NO. 337/12 PLOT NO. 10A NANEKARWADI PUNE-NASIK HIGHWAY ', 'CHAKAN ', '410501', 'Maharashtra', 'CHAKAN ', 'India', ' GAT NO. 337/12 PLOT NO. 10A NANEKARWADI PUNE-NASIK HIGHWAY ', 'CHAKAN ', '410501', 'Maharashtra', 'CHAKAN ', 'India', 'Dealers', NULL, 1, 0, '6/8/2026 4:58:07 PM', '1', NULL, NULL);
INSERT INTO dbo.tbl_UserMaster (ID, UserCode, FullName, CompanyName, MobileNo, EmailId, LoginPass, Type, GstNo, PanCardNo, UANNo, BillAddress, BillArea, BillPinCode, BillState, BillCity, BillCountry, ShipAddress, ShipArea, ShipPinCode, ShipState, ShipCity, ShipCountry, UserRole, RelationId, IsActivate, IsDeleted, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy) VALUES (10, 'AL/2026-27/010', 'KEY AUTOMATION', 'KEY AUTOMATION', '7798077777', 'AUTOMATION@gmail.com', '9252', 'Authorized', '27AAUFK6791L1Z9', 'AAUFK6791L', '', '1 144A Automation & Control Systems PCNTDA , MIDC DIAS C Tool And Company', 'Pimpri Chinchwad Sector 7', '411026', 'Maharashtra', 'Pimpri Chinchwad Sector 7', 'India', '1 144A Automation & Control Systems PCNTDA , MIDC DIAS C Tool And Company', 'Pimpri Chinchwad Sector 7', '411026', 'Maharashtra', 'Pimpri Chinchwad Sector 7', 'India', 'Dealers', NULL, 1, 0, '6/10/2026 5:28:12 PM', '1', NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_UserMaster OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_UserRoleAuthorization]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_UserRoleAuthorization](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [int] NULL,
	[UserName] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[MenuId] [int] NULL,
	[MenuName] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PageName] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PageAccess] [bit] NULL,
	[PagesButtonAccess] [bit] NULL,
	[CreatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CreatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
	[IsDeleted] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_UserRoleAuthorization]
SET IDENTITY_INSERT dbo.tbl_UserRoleAuthorization ON;

INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (19, 1, 'Admin', 1, 'Dashboard', 'Dashboard.aspx', 1, 0, '1', '6/23/2026 2:26:39 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (20, 1, 'Admin', 2, 'Roles', 'RoleMaster.aspx', 1, 0, '1', '6/23/2026 2:26:39 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (21, 1, 'Admin', 3, 'Users', 'UserList.aspx', 1, 0, '1', '6/23/2026 2:26:39 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (22, 1, 'Admin', 4, 'Dealers', 'DealerList.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (23, 1, 'Admin', 5, 'Sub Dealers', 'CompanyList.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (24, 1, 'Admin', 6, 'Stages', 'StageList.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (25, 1, 'Admin', 7, 'Machine', 'MachineList.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (26, 1, 'Admin', 8, 'Raw Material', 'RawMaterialList.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (27, 1, 'Admin', 9, 'Products', 'ProductList.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (28, 1, 'Admin', 10, 'Transporter', 'TransporterList.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (29, 1, 'Admin', 11, 'Work Order', 'WorkOrderList.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (30, 1, 'Admin', 12, 'Place Order', 'PlaceOrder.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (31, 1, 'Admin', 13, 'Assign Machine', 'AssignMachine.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (32, 1, 'Admin', 14, 'Approve Designs', 'WorkOrdrForDesign.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (33, 1, 'Admin', 15, 'Start Production', 'AssignWorkOrder.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (34, 1, 'Admin', 16, 'Production Stage 1', 'WoProductionS1.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (35, 1, 'Admin', 17, 'Production Stage 2', 'WoProductionS2.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (36, 1, 'Admin', 18, 'Packaging', 'Packaging.aspx', 1, 0, '1', '6/23/2026 2:26:40 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (37, 1, 'Admin', 19, 'User Authorization', 'UserAuthorization.aspx', 1, 0, '1', '6/23/2026 2:26:41 PM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (38, 10, 'KEY AUTOMATION', 1, 'Dashboard', 'Dashboard.aspx', 0, 0, '1', '6/24/2026 11:50:42 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (39, 10, 'KEY AUTOMATION', 2, 'Roles', 'RoleMaster.aspx', 0, 0, '1', '6/24/2026 11:50:42 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (40, 10, 'KEY AUTOMATION', 3, 'Users', 'UserList.aspx', 0, 0, '1', '6/24/2026 11:50:42 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (41, 10, 'KEY AUTOMATION', 4, 'Dealers', 'DealerList.aspx', 0, 0, '1', '6/24/2026 11:50:42 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (42, 10, 'KEY AUTOMATION', 5, 'Sub Dealers', 'CompanyList.aspx', 0, 0, '1', '6/24/2026 11:50:42 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (43, 10, 'KEY AUTOMATION', 6, 'Stages', 'StageList.aspx', 0, 0, '1', '6/24/2026 11:50:42 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (44, 10, 'KEY AUTOMATION', 7, 'Machine', 'MachineList.aspx', 0, 0, '1', '6/24/2026 11:50:42 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (45, 10, 'KEY AUTOMATION', 8, 'Raw Material', 'RawMaterialList.aspx', 0, 0, '1', '6/24/2026 11:50:42 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (46, 10, 'KEY AUTOMATION', 9, 'Products', 'ProductList.aspx', 0, 0, '1', '6/24/2026 11:50:43 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (47, 10, 'KEY AUTOMATION', 10, 'Transporter', 'TransporterList.aspx', 0, 0, '1', '6/24/2026 11:50:43 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (48, 10, 'KEY AUTOMATION', 11, 'Work Order', 'WorkOrderList.aspx', 0, 0, '1', '6/24/2026 11:50:43 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (49, 10, 'KEY AUTOMATION', 12, 'Place Order', 'PlaceOrder.aspx', 1, 0, '1', '6/24/2026 11:50:43 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (50, 10, 'KEY AUTOMATION', 13, 'Assign Machine', 'AssignMachine.aspx', 0, 0, '1', '6/24/2026 11:50:43 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (51, 10, 'KEY AUTOMATION', 14, 'Approve Designs', 'WorkOrdrForDesign.aspx', 0, 0, '1', '6/24/2026 11:50:43 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (52, 10, 'KEY AUTOMATION', 15, 'Start Production', 'AssignWorkOrder.aspx', 0, 0, '1', '6/24/2026 11:50:43 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (53, 10, 'KEY AUTOMATION', 16, 'Production Stage 1', 'WoProductionS1.aspx', 0, 0, '1', '6/24/2026 11:50:43 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (54, 10, 'KEY AUTOMATION', 17, 'Production Stage 2', 'WoProductionS2.aspx', 0, 0, '1', '6/24/2026 11:50:43 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (55, 10, 'KEY AUTOMATION', 18, 'Packaging', 'Packaging.aspx', 0, 0, '1', '6/24/2026 11:50:43 AM', NULL, NULL, NULL);
INSERT INTO dbo.tbl_UserRoleAuthorization (ID, UserID, UserName, MenuId, MenuName, PageName, PageAccess, PagesButtonAccess, CreatedBy, CreatedOn, UpdatedBy, UpdatedOn, IsDeleted) VALUES (56, 10, 'KEY AUTOMATION', 19, 'User Authorization', 'UserAuthorization.aspx', 0, 0, '1', '6/24/2026 11:50:44 AM', NULL, NULL, NULL);

SET IDENTITY_INSERT dbo.tbl_UserRoleAuthorization OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_WorkOrderDetails]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_WorkOrderDetails](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[HeaderID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[ProductId] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ProductName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PartNo] [nvarchar](300) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Description] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Size] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Unit] [nvarchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Qty] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[SqFeet] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UploadedImage] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Type] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK__tbl_Work__3214EC07377E67F7] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

ALTER TABLE [dbo].[tbl_WorkOrderDetails] ADD  CONSTRAINT [DF__tbl_WorkOrd__Qty__3864608B]  DEFAULT ((0)) FOR [Qty]

-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_WorkOrderDetails]
SET IDENTITY_INSERT dbo.tbl_WorkOrderDetails ON;

INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (1, '1', '4', 'Acryalic Sheet', 'A121425', 'Sheet with gloze finish', '2x8', 'NOS', '5', '80', '~/WOCustomProducts/15f7998d-9fac-4ad0-a88d-fe000147bc80_1.jpg', 'Custom');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (2, '1', '1', 'HDMR Board', 'PAA', 'Sheet with gloze finish', '4x8', 'NOS', '3', '96', '~/WOCustomProducts/01576389-9a37-4690-b7fb-9126a84408eb_9.jpg', 'Custom');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (5, '2', '3', 'HDMR Boards', 'PAAaaaa', '', '4x8', 'NOS', '8', '256', '~/WOCustomProducts/74b63131-9636-4d16-b1d4-3504d3aeeacc_13.jpg', 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (6, '2', '4', 'Acryalic Sheet', 'A121425', 'Sheet with glose finished', '2x4', 'NOS', '15', '120', '~/WOCustomProducts/a78be816-c35f-4d75-9e57-20528c9e0330_24.jpg', 'Custom');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (9, '3', '314', 'AS 3D 117 Acrylic Laminates', 'Acrylic Sheet', '', '4x8', 'NOS', '3', '96', '~/WOCustomProducts/d0e5f364-2fd4-47c4-9ef0-c1271cae6d4f_25.jpg', 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (10, '3', '455', 'AS PD 058 Acrylic Laminates', 'Acrylic Sheet', '', '2x8', 'NOS', '6', '96', '~/WOCustomProducts/ea084495-51ff-4c12-b57d-5adba54c1c0b_26.jpg', 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (11, '4', '302', 'AS 3D 105 Acrylic Laminates', 'Acrylic Sheet', 'sadsadsadsdsadsdsadas', '2x4', 'NOS', '5', '40', '~/WOCustomProducts/098ef13e-c04a-49e5-b0e4-8ceb0b57854b_17.jpg', 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (12, '4', '313', 'AS 3D 116 Acrylic Laminates', 'Acrylic Sheet', 'sadase f wsA FDFFADSSAD ASD SDD S dfsdsfsd', '4x8', 'NOS', '5', '160', NULL, 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (13, '5', '316', 'AS 3D 119 Acrylic Laminates', 'Acrylic Sheet', 'sda asfer b t xv gjfgd sfdsfdfd', '2x8', 'NOS', '5', '80', NULL, 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (14, '5', '312', 'AS 3D 115 Acrylic Laminates', 'Acrylic Sheet', 'shab bsafdhsajbshasftysabhj dahsdabgdya dndas', '2x4', 'NOS', '10', '80', NULL, 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (15, '6', '15', 'AS HD 073(A) Textura Sheet', '0', '', '8x4', 'NOS', '2', '64', '~/MyProducts/cef2e48f-98fa-4c8d-8c4d-b2e45d89f036.jpg', 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (16, '6', '11', 'AS HD 072(A) Textura Sheet', '0', '', '8x4', 'NOS', '2', '64', '~/MyProducts/02a18cca-56cf-4632-b9e6-cebd923f0f93.jpg', 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (17, '6', '1', 'AS HD 065(A) Textura Sheet', '0', '', '8x4', 'NOS', '5', '160', '~/MyProducts/0b0c7ff4-e2cd-4db4-81d4-a79a41be2a47.jpg', 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (26, '8', '13', 'AS HD 073(B) Textura Sheet', '0', 'Regular', '8x4', 'NOS', '3', '96', '~/MyProducts/a226da13-7d89-4934-a543-3130db02a0eb.jpg', 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (27, '8', '3', 'AS HD 067(A) Textura Sheet', '0', 'Regular-N/A', '8x4', 'NOS', '2', '64', '~/MyProducts/14f14a7e-4188-4f56-a43c-1a6c4f73f600.jpg', 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (28, '7', '17', 'AS HD 074(A) Textura Sheet', '0', 'Regular-N/A', '8x4', 'NOS', '2', '64', '~/MyProducts/d330cac1-842e-448a-bafc-c1ab24ea3b1d_AS%20HD%20074A.jpg', 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (29, '7', '13', 'AS HD 073(B) Textura Sheet', '0', 'Regular-N/A', '8x4', 'NOS', '1', '32', '~/MyProducts/a226da13-7d89-4934-a543-3130db02a0eb.jpg', 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (30, '7', '2', 'AS HD 066(A) Textura Sheet', '0', 'Regular-N/A', '8x4', 'NOS', '2', '64', '~/MyProducts/7bcdddf3-506e-4fd2-a28c-d863cbc9998d.jpg', 'Regular');
INSERT INTO dbo.tbl_WorkOrderDetails (Id, HeaderID, ProductId, ProductName, PartNo, Description, Size, Unit, Qty, SqFeet, UploadedImage, Type) VALUES (31, '7', '8', 'AS HD 070(A) Textura Sheet', '0', 'Regular-N/A', '8x4', 'NOS', '1', '32', '~/MyProducts/6d0ccd24-a479-4d48-b639-343dd1e3056a.jpg', 'Regular');

SET IDENTITY_INSERT dbo.tbl_WorkOrderDetails OFF;


-- Structure for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_WorkOrderHdr]
SET ANSI_NULLS ON
SET QUOTED_IDENTIFIER ON
CREATE TABLE [dbo].[tbl_WorkOrderHdr](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[SeriesNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[TallyRefNo] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WorkOrderDate] [date] NULL,
	[Dealer] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CustomerName] [nvarchar](500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CustomerRefNo] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillingGstNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillingAddress] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BillingPincode] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShippingGstNo] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShippingAddress] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[ShippingPincode] [nvarchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[DeliveryDate] [date] NULL,
	[CreatedOn] [datetime] NULL,
	[CreatedBy] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[UpdatedOn] [datetime] NULL,
	[UpdatedBy] [nvarchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[IsDeleted] [bit] NULL,
	[IsDispatched] [bit] NULL,
	[isproductioncompleted] [bit] NULL,
	[isdesignapproved] [bit] NULL,
	[AttachmentPath] [nvarchar](max) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[RankNo] [int] NULL,
	[ScheduledDate] [datetime] NULL,
	[PlaceOrderID] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK__tbl_Work__3214EC27519A97A5] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

ALTER TABLE [dbo].[tbl_WorkOrderHdr] ADD  CONSTRAINT [DF__tbl_WorkO__IsDel__2DE6D218]  DEFAULT ((1)) FOR [IsDeleted]

-- Data for table [DB_AcryshadeLaminatesTest].[dbo].[tbl_WorkOrderHdr]
SET IDENTITY_INSERT dbo.tbl_WorkOrderHdr ON;

INSERT INTO dbo.tbl_WorkOrderHdr (ID, SeriesNo, TallyRefNo, WorkOrderDate, Dealer, CustomerName, CustomerRefNo, BillingGstNo, BillingAddress, BillingPincode, ShippingGstNo, ShippingAddress, ShippingPincode, DeliveryDate, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy, IsDeleted, IsDispatched, isproductioncompleted, isdesignapproved, AttachmentPath, RankNo, ScheduledDate, PlaceOrderID) VALUES (1, 'WO/2026-27/001', 'WO/2026-27/001', '6/16/2026 12:00:00 AM', 'KEY AUTOMATION', 'LEANBOTZ INDIA PRIVATE LIMITED', '', '27AAUFK6791L1Z9', '1 144A Automation & Control Systems PCNTDA , MIDC DIAS C Tool And Company', '411026', '24ABCDE1234F1Z5', 'Ahmedabad , Dariapur (Ahmedabad), District Court (Ahmedabad), Gandhi Road (Ahmedabad), Gheekanta Road, Jamalpur (Ahmedabad), Kalupur Chakla, Khadia, Khanpur (Ahmedabad), Lal Darwaja, Manek Chowk, Municipal Corporation, Raikhad, Raipur (Ahmedabad)', '380001', '6/25/2026 12:00:00 AM', '6/16/2026 4:02:16 PM', '1', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_WorkOrderHdr (ID, SeriesNo, TallyRefNo, WorkOrderDate, Dealer, CustomerName, CustomerRefNo, BillingGstNo, BillingAddress, BillingPincode, ShippingGstNo, ShippingAddress, ShippingPincode, DeliveryDate, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy, IsDeleted, IsDispatched, isproductioncompleted, isdesignapproved, AttachmentPath, RankNo, ScheduledDate, PlaceOrderID) VALUES (2, 'WO/2026-27/002', 'WO/2026-27/002', '6/16/2026 12:00:00 AM', 'S.S. INSULATION', 'S.S. INSULATION', '', '27ABYPS7431A1ZA', 'GAT NO. 337/12 PLOT NO. 10A NANEKARWADI PUNE-NASIK HIGHWAY', '410501', '27ABYPS7431A1ZA', 'GAT NO. 337/12 PLOT NO. 10A NANEKARWADI PUNE-NASIK HIGHWAY', '410501', '6/29/2026 12:00:00 AM', '6/16/2026 4:03:35 PM', '1', '6/16/2026 5:01:16 PM', '1', 0, 0, 0, NULL, NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_WorkOrderHdr (ID, SeriesNo, TallyRefNo, WorkOrderDate, Dealer, CustomerName, CustomerRefNo, BillingGstNo, BillingAddress, BillingPincode, ShippingGstNo, ShippingAddress, ShippingPincode, DeliveryDate, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy, IsDeleted, IsDispatched, isproductioncompleted, isdesignapproved, AttachmentPath, RankNo, ScheduledDate, PlaceOrderID) VALUES (3, 'WO/2026-27/003', 'REST01', '6/16/2026 12:00:00 AM', 'KEY AUTOMATION', 'KEY AUTOMATION', 'terf', '27AAUFK6791L1Z9', '1 144A Automation & Control Systems PCNTDA , MIDC DIAS C Tool And Company', '411026', '27AAUFK6791L1Z9', '1 144A Automation & Control Systems PCNTDA , MIDC DIAS C Tool And Company', '411026', '7/10/2026 12:00:00 AM', '6/16/2026 5:50:16 PM', '1', '6/16/2026 5:53:54 PM', '1', 0, 0, 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_WorkOrderHdr (ID, SeriesNo, TallyRefNo, WorkOrderDate, Dealer, CustomerName, CustomerRefNo, BillingGstNo, BillingAddress, BillingPincode, ShippingGstNo, ShippingAddress, ShippingPincode, DeliveryDate, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy, IsDeleted, IsDispatched, isproductioncompleted, isdesignapproved, AttachmentPath, RankNo, ScheduledDate, PlaceOrderID) VALUES (4, 'WO/2026-27/004', 'WO/2026-27/003', '6/17/2026 12:00:00 AM', 'TATA MOTORS PASSENGER VEHICLES LIMITED', 'TATA MOTORS PASSENGER VEHICLES LIMITED', '', '27AAACT2727Q1ZW', 'Sector No. 15 and 15A PCNTDA K Block  Chikhali Road', '411062', '27AAACT2727Q1ZW', 'Sector No. 15 and 15A PCNTDA K Block  Chikhali Road', '411062', '6/19/2026 12:00:00 AM', '6/17/2026 10:35:55 AM', '1', NULL, NULL, 0, 0, 0, 1, NULL, NULL, '6/26/2026 12:00:00 AM', NULL);
INSERT INTO dbo.tbl_WorkOrderHdr (ID, SeriesNo, TallyRefNo, WorkOrderDate, Dealer, CustomerName, CustomerRefNo, BillingGstNo, BillingAddress, BillingPincode, ShippingGstNo, ShippingAddress, ShippingPincode, DeliveryDate, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy, IsDeleted, IsDispatched, isproductioncompleted, isdesignapproved, AttachmentPath, RankNo, ScheduledDate, PlaceOrderID) VALUES (5, 'WO/2026-27/005', 'WO/2026-27/004', '6/17/2026 12:00:00 AM', 'MRUGESH LASER ENGRAVERS', 'MRUGESH LASER ENGRAVERS', '', '27AGCPL0333M1ZH', 'GAT NO 2 RCC GROUND FLOOR AUTOMATION & CONTROL SYSTEMS PLOT NO 144A MIDC Road', '411026', '27AGCPL0333M1ZH', 'GAT NO 2 RCC GROUND FLOOR AUTOMATION & CONTROL SYSTEMS PLOT NO 144A MIDC Road', '411026', '6/30/2026 12:00:00 AM', '6/17/2026 10:37:02 AM', '1', NULL, NULL, 0, 0, 0, 1, NULL, NULL, NULL, NULL);
INSERT INTO dbo.tbl_WorkOrderHdr (ID, SeriesNo, TallyRefNo, WorkOrderDate, Dealer, CustomerName, CustomerRefNo, BillingGstNo, BillingAddress, BillingPincode, ShippingGstNo, ShippingAddress, ShippingPincode, DeliveryDate, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy, IsDeleted, IsDispatched, isproductioncompleted, isdesignapproved, AttachmentPath, RankNo, ScheduledDate, PlaceOrderID) VALUES (6, 'WO/2026-27/006', 'WO-1234', '6/24/2026 12:00:00 AM', 'KEY AUTOMATION', 'LEANBOTZ INDIA PRIVATE LIMITED', 'ORD000004', '27AAUFK6791L1Z9', '1 144A Automation & Control Systems PCNTDA , MIDC DIAS C Tool And Company', '411026', '24ABCDE1234F1Z8', 'Baranpura, Khanderao Market, Madanzampa, Mandvi (Vadodara), SRP Group I, Vadodara', '390001', '6/30/2026 12:00:00 AM', '6/24/2026 6:19:02 PM', '1', NULL, NULL, 0, 0, 0, 1, NULL, NULL, '6/26/2026 12:00:00 AM', NULL);
INSERT INTO dbo.tbl_WorkOrderHdr (ID, SeriesNo, TallyRefNo, WorkOrderDate, Dealer, CustomerName, CustomerRefNo, BillingGstNo, BillingAddress, BillingPincode, ShippingGstNo, ShippingAddress, ShippingPincode, DeliveryDate, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy, IsDeleted, IsDispatched, isproductioncompleted, isdesignapproved, AttachmentPath, RankNo, ScheduledDate, PlaceOrderID) VALUES (7, 'WO/2026-27/007', 'WO/2026-27/12345', '6/25/2026 12:00:00 AM', 'KEY AUTOMATION', 'KEY AUTOMATION', 'ORD000006', '27AAUFK6791L1Z9', '1 144A Automation & Control Systems PCNTDA , MIDC DIAS C Tool And Company', '411026', '27AAUFK6791L1Z9', '1 144A Automation & Control Systems PCNTDA , MIDC DIAS C Tool And Company', '411026', '6/30/2026 12:00:00 AM', '6/25/2026 10:54:23 AM', '1', '6/25/2026 3:17:24 PM', '1', 0, 0, 0, 1, NULL, NULL, '6/26/2026 12:00:00 AM', '1');
INSERT INTO dbo.tbl_WorkOrderHdr (ID, SeriesNo, TallyRefNo, WorkOrderDate, Dealer, CustomerName, CustomerRefNo, BillingGstNo, BillingAddress, BillingPincode, ShippingGstNo, ShippingAddress, ShippingPincode, DeliveryDate, CreatedOn, CreatedBy, UpdatedOn, UpdatedBy, IsDeleted, IsDispatched, isproductioncompleted, isdesignapproved, AttachmentPath, RankNo, ScheduledDate, PlaceOrderID) VALUES (8, 'WO/2026-27/008', 'WO/2026/27/0001234', '6/25/2026 12:00:00 AM', 'KEY AUTOMATION', 'KEY AUTOMATION', 'ORD000008', '27AAUFK6791L1Z9', '1 144A Automation & Control Systems PCNTDA , MIDC DIAS C Tool And Company', '411026', '27AAUFK6791L1Z9', '1 144A Automation & Control Systems PCNTDA , MIDC DIAS C Tool And Company', '411026', '6/30/2026 12:00:00 AM', '6/25/2026 1:13:11 PM', '1', '6/25/2026 3:06:03 PM', '1', 0, 0, 0, 1, NULL, NULL, NULL, '3');

SET IDENTITY_INSERT dbo.tbl_WorkOrderHdr OFF;


-- VIEWS

-- STORED PROCEDURES
-- Script for SP_ProductsMaster
GO
CREATE PROCEDURE [dbo].[SP_ProductsMaster]
    @ShowRecords INT = 0,
    @ID INT = 0,
    @PartName NVARCHAR(200) = NULL,
    @Productcode NVARCHAR(100) = NULL,
    @Thickness NVARCHAR(100) = NULL,
    @ProductCategory NVARCHAR(200) = NULL,
    @PartNo NVARCHAR(100) = NULL,
    @Size NVARCHAR(MAX) = NULL,
    @ImagenamePath NVARCHAR(500) = Null,
    @IsActive BIT =  Null,
    @ActionBy NVARCHAR(100) = NULL,
    @SP_Action NVARCHAR(100) = NULL,
    @Productname  NVARCHAR(100) = NULL
AS
BEGIN
    IF @SP_Action = 'ProductList'
    BEGIN
        WITH ProductMaster AS
        (
            SELECT
                ID,
                Productcode,
                ProductCategory,
                Productname,
                PartName,
                Thickness,
                PartNo,
                Size,
                ImagenamePath,
                IsActive,
                FavoriteProduct
            FROM tbl_ProdcutMaster
            WHERE IsDeleted = 0
            AND (
                    Productname LIKE CASE
                                    WHEN ISNULL(@Productname,'') <> ''
                                    THEN '%' + @Productname + '%'
                                    ELSE '%'
                                  END
                )
        ),
        NUMBERED AS
        (
            SELECT *,
                   ROW_NUMBER() OVER(ORDER BY ID DESC) RN
            FROM ProductMaster
        )
        SELECT *
        FROM NUMBERED
        WHERE @ShowRecords = 0
           OR RN <= @ShowRecords
        ORDER BY ID DESC;
    END

    IF @SP_Action = 'ProductListById'
    BEGIN
        SELECT *
        FROM tbl_ProdcutMaster
        WHERE ID = @ID;
    END

    IF @SP_Action = 'InsertProduct'
    BEGIN
        INSERT INTO tbl_ProdcutMaster
        (
             Productcode,
             ProductCategory,
             Productname,
             PartName,
             Thickness,
             PartNo,
             Size,
             ImagenamePath,
             IsActive,
            IsDeleted,
            CreatedBy,
            CreatedOn
        )
        VALUES
        (
             @Productcode,
             @ProductCategory,
             @Productname,
             @PartName,
             @Thickness,
             @PartNo,
             @Size,
             @ImagenamePath,
              1,
              0,
              @ActionBy,
             GETDATE()
        );
    END

    IF @SP_Action = 'Deleteproduct'
     BEGIN
       Update tbl_ProdcutMaster set isdeleted = 1 where  ID = @ID
     END
     
    IF @SP_Action = 'UpdateProduct'
     BEGIN
        UPDATE tbl_ProdcutMaster
            SET
                Productname = @Productname,
                ProductCategory = @ProductCategory,
                PartName    = @PartName,
                Thickness   = @Thickness,
                PartNo      = @PartNo,
                Size        = @Size,
                ImagenamePath = @ImagenamePath,
                UpdatedBy   = @ActionBy,
                UpdatedOn   = GETDATE()
         WHERE ID = @ID;
      END

END

-- Script for SP_Productioncapacity
GO
CREATE PROCEDURE [dbo].[SP_Productioncapacity]
    @ShowRecords INT = 0,
    @Id int =0,
    @WorkOrderNo NVARCHAR(200) = NULL,
    @SP_Action NVARCHAR(100) = NULL

AS
BEGIN
    DECLARE @MachineId INT;

    IF @SP_Action = 'DailyTotalcapacity'
    BEGIN
   SELECT
    AllocatedStage,
    SUM(
        TRY_CAST(MachinePerHRQty AS FLOAT) *
        TRY_CAST(MachineRunningHR AS FLOAT)
    ) AS StageDailyCapacity
FROM [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineMaster]
WHERE IsActive = 1
AND IsDeleted = 0
GROUP BY AllocatedStage;
    END

    IF @SP_Action ='machinecount'
    BEGIN
      SELECT 
    AllocatedStage,
    COUNT(ID) AS MachineCount
FROM [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineMaster]
WHERE IsActive = 1
  AND IsDeleted = 0
GROUP BY AllocatedStage
ORDER BY AllocatedStage;
    END

    IF @SP_Action='GetCapacity'
    BEGIN
      SELECT
    M.AllocatedStage,
    M.MachineName,

    (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
     TRY_CAST(M.MachineRunningHR AS FLOAT)) AS MachineCapacity,

    ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0) AS MachineLoad,

    (
        (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
         TRY_CAST(M.MachineRunningHR AS FLOAT))
        - ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0)
    ) AS MachineAvailable,

    -- ✔ LOAD %
    CASE 
        WHEN (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
              TRY_CAST(M.MachineRunningHR AS FLOAT)) = 0
        THEN 0

        ELSE 
            ROUND(
                (ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0) * 100.0)
                /
                (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
                 TRY_CAST(M.MachineRunningHR AS FLOAT))
            ,2)
    END AS LoadPercentage

FROM tbl_MachineMaster M
LEFT JOIN tbl_ProductionMachineLoading PM
    ON M.ID = PM.MachineId
    AND PM.Status = 'In-Process'

WHERE M.IsDeleted = 0
and M.IsActive=1
GROUP BY
    M.AllocatedStage,
    M.MachineName,
    M.MachinePerHRQty,
    M.MachineRunningHR;
    END
    
  --  IF @SP_Action = 'GetReceivedWO'
  --   BEGIN
  --      WITH WorkOrders
		--	AS (
		--	    SELECT * FROM tbl_ProductionInatial
  --              WHERE (
		--				WorkOrderNo LIKE CASE 
		--					WHEN @WorkOrderNo != ''
		--						THEN @WorkOrderNo
		--					ELSE '%%'
		--					END
		--	          )
		--	   ),NUMBERED
		--AS (
		--	SELECT *
		--		,ROW_NUMBER() OVER (
		--			ORDER BY Id DESC
		--			) AS RN
		--	FROM WorkOrders
		--	)
		--SELECT *
		--FROM NUMBERED
		--WHERE @ShowRecords = 0
		--	OR RN <= @ShowRecords
		--ORDER BY ID DESC
  --   END
    -----updated----------
    --IF @SP_Action = 'StartProduction'
    -- BEGIN
    --     SELECT TOP 1
    --            @MachineId = M.ID
    --        FROM tbl_MachineMaster M
    --        LEFT JOIN tbl_ProductionMachineLoading PM
    --            ON M.ID = PM.MachineId
    --            AND PM.Status = 'In-Process'
    --        WHERE M.IsDeleted = 0
    --            AND M.IsActive = 1
    --            AND M.AllocatedStage = 'Stage 1'
    --        GROUP BY
    --            M.ID,
    --            M.MachinePerHRQty,
    --            M.MachineRunningHR
    --        HAVING
    --        (
    --            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
    --             TRY_CAST(M.MachineRunningHR AS FLOAT))
    --            -
    --            ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0)
    --        ) >=
    --        (
    --            SELECT TotalQty
    --            FROM tbl_ProductionInatial
    --            WHERE ID = @Id
    --        )
    --        ORDER BY
    --        (
    --            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
    --             TRY_CAST(M.MachineRunningHR AS FLOAT))
    --            -
    --            ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0)
    --        ) DESC;


    --  	INSERT INTO tbl_ProductionMachineLoading
    --    (
    --        ProductionPlanId,
    --        WorkOrderId,
    --        MachineId,
    --        AllocatedStage,
    --        ScheduleDate,
    --        PlannedQty,
    --        ProducedQty,
    --        Status
    --    )
    --    SELECT
    --        PI.ID,
    --        PI.WorkOrderId,
    --        @MachineId,
    --        'Stage 1',
    --        GETDATE(),
    --        PI.TotalQty,
    --        0,
    --        'In-Process'
    --    FROM tbl_ProductionInatial PI
    --    WHERE PI.ID = @Id;
    -- END



--    IF @SP_Action = 'StartProduction'
--BEGIN

--    DECLARE @RemainingQty FLOAT;
--    DECLARE @MachineIdLocal INT;
--    DECLARE @AvailableQty FLOAT;
--    DECLARE @AllocateQty FLOAT;
--    DECLARE @WorkOrderId INT;

--    SELECT
--        @RemainingQty = TotalQty,
--        @WorkOrderId = WorkOrderId
--    FROM tbl_ProductionInatial
--    WHERE ID = @Id;

--    DECLARE MachineCursor CURSOR FOR

--    SELECT
--        M.ID,

--        (
--            (TRY_CAST(M.MachinePerHRQty AS FLOAT)
--            * TRY_CAST(M.MachineRunningHR AS FLOAT))

--            - ISNULL(
--                SUM(
--                    TRY_CAST(PM.PlannedQty AS FLOAT)
--                ),0
--            )
--        ) AS AvailableQty

--    FROM tbl_MachineMaster M

--    LEFT JOIN tbl_ProductionMachineLoading PM
--        ON M.ID = PM.MachineId
--        AND PM.Status = 'In-Process'

--    WHERE M.IsDeleted = 0
--      AND M.IsActive = 1
--      AND M.AllocatedStage = 'Stage 1'

--    GROUP BY
--        M.ID,
--        M.MachinePerHRQty,
--        M.MachineRunningHR

--    HAVING
--        (
--            (TRY_CAST(M.MachinePerHRQty AS FLOAT)
--            * TRY_CAST(M.MachineRunningHR AS FLOAT))

--            - ISNULL(
--                SUM(
--                    TRY_CAST(PM.PlannedQty AS FLOAT)
--                ),0
--            )
--        ) > 0

--    ORDER BY AvailableQty DESC;

--    OPEN MachineCursor;

--    FETCH NEXT FROM MachineCursor
--    INTO @MachineIdLocal, @AvailableQty;

--    WHILE @@FETCH_STATUS = 0
--          AND @RemainingQty > 0
--    BEGIN

--        SET @AllocateQty =
--        CASE
--            WHEN @RemainingQty >= @AvailableQty
--                THEN @AvailableQty
--            ELSE @RemainingQty
--        END;

--        INSERT INTO tbl_ProductionMachineLoading
--        (
--            ProductionPlanId,
--            WorkOrderId,
--            MachineId,
--            AllocatedStage,
--            ScheduleDate,
--            PlannedQty,
--            ProducedQty,
--            Status
--        )
--        VALUES
--        (
--            @Id,
--            @WorkOrderId,
--            @MachineIdLocal,
--            'Stage 1',
--            GETDATE(),
--            @AllocateQty,
--            0,
--            'In-Process'
--        );

--        SET @RemainingQty =
--            @RemainingQty - @AllocateQty;

--        FETCH NEXT FROM MachineCursor
--        INTO @MachineIdLocal, @AvailableQty;
--    END

--    CLOSE MachineCursor;
--    DEALLOCATE MachineCursor;

--    IF @RemainingQty > 0
--    BEGIN
--        RAISERROR(
--            'Insufficient machine capacity. Remaining Qty not allocated.',
--            16,
--            1
--        );
--    END

--END


      ------updated-----------
     IF @SP_Action = 'StartProduction'
BEGIN

    DECLARE @RemainingQty FLOAT;
    DECLARE @MachineIdLocal INT;
    DECLARE @AvailableQty FLOAT;
    DECLARE @AllocateQty FLOAT;
    DECLARE @WorkOrderId INT;

    SELECT
        @RemainingQty = TotalQty,
        @WorkOrderId = WorkOrderId
    FROM tbl_ProductionInatial
    WHERE ID = @Id;


    DECLARE MachineCursor CURSOR FOR

    SELECT
        M.ID,

        (
            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
             TRY_CAST(M.MachineRunningHR AS FLOAT))
            -
            ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)), 0)
        ) AS AvailableQty

    FROM tbl_MachineMaster M

    LEFT JOIN tbl_ProductionMachineLoading PM
        ON M.ID = PM.MachineId
        AND PM.Status = 'In-Process'

    WHERE M.IsDeleted = 0
      AND M.IsActive = 1
      AND M.AllocatedStage = 'Stage 1'

    GROUP BY
        M.ID,
        M.MachinePerHRQty,
        M.MachineRunningHR

    HAVING
        (
            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
             TRY_CAST(M.MachineRunningHR AS FLOAT))
            -
            ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)), 0)
        ) > 0


    ORDER BY
        -- ⭐ KEY FIX: prioritize machines already used first
        CASE
            WHEN ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)), 0) > 0
            THEN 0 ELSE 1
        END,
        M.ID;   -- maintain stable sequence


    OPEN MachineCursor;

    FETCH NEXT FROM MachineCursor
    INTO @MachineIdLocal, @AvailableQty;

    WHILE @@FETCH_STATUS = 0
          AND @RemainingQty > 0
    BEGIN

        SET @AllocateQty =
        CASE
            WHEN @RemainingQty >= @AvailableQty
                THEN @AvailableQty
            ELSE @RemainingQty
        END;

        INSERT INTO tbl_ProductionMachineLoading
        (
            ProductionPlanId,
            WorkOrderId,
            MachineId,
            AllocatedStage,
            ScheduleDate,
            PlannedQty,
            ProducedQty,
            Status
        )
        VALUES
        (
            @Id,
            @WorkOrderId,
            @MachineIdLocal,
            'Stage 1',
            GETDATE(),
            @AllocateQty,
            0,
            'In-Process'
        );

        SET @RemainingQty = @RemainingQty - @AllocateQty;

        FETCH NEXT FROM MachineCursor
        INTO @MachineIdLocal, @AvailableQty;

    END

    CLOSE MachineCursor;
    DEALLOCATE MachineCursor;


    IF @RemainingQty > 0
    BEGIN
        RAISERROR(
            'Insufficient machine capacity. Remaining Qty not allocated.',
            16,
            1
        );
    END

END


--IF @SP_Action = 'StartProduction'
--BEGIN

--    DECLARE @RemainingQty FLOAT;
--    DECLARE @MachineIdLocal INT;
--    DECLARE @AvailableQty FLOAT;
--    DECLARE @AllocateQty FLOAT;
--    DECLARE @WorkOrderId INT;

--    ---------------------------------------------------
--    -- STEP 1: GET SAFE REMAINING QTY (NO NEGATIVE)
--    ---------------------------------------------------
--    SELECT
--        @WorkOrderId = WorkOrderId,
--        @RemainingQty =
--            CASE 
--                WHEN TotalQty - ISNULL((
--                    SELECT SUM(PlannedQty)
--                    FROM tbl_ProductionMachineLoading
--                    WHERE ProductionPlanId = @Id
--                      AND AllocatedStage = 'Stage 1'
--                ), 0) < 0 
--                THEN 0
--                ELSE TotalQty - ISNULL((
--                    SELECT SUM(PlannedQty)
--                    FROM tbl_ProductionMachineLoading
--                    WHERE ProductionPlanId = @Id
--                      AND AllocatedStage = 'Stage 1'
--                ), 0)
--            END
--    FROM tbl_ProductionInatial
--    WHERE ID = @Id;

--    ---------------------------------------------------
--    -- STOP IF NOTHING LEFT
--    ---------------------------------------------------
--    IF @RemainingQty <= 0
--        RETURN;

--    ---------------------------------------------------
--    -- STEP 2: MACHINE CURSOR (CORRECT CAPACITY CALC)
--    ---------------------------------------------------
--    DECLARE MachineCursor CURSOR FOR

--    SELECT
--        M.ID,

--        (
--            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
--             TRY_CAST(M.MachineRunningHR AS FLOAT))
--            -
--            ISNULL(
--                SUM(
--                    CASE
--                        WHEN PM.ProductionPlanId = @Id
--                         AND PM.AllocatedStage = 'Stage 1'
--                        THEN PM.PlannedQty
--                        ELSE 0
--                    END
--                ), 0
--            )
--        ) AS AvailableQty

--    FROM tbl_MachineMaster M

--    LEFT JOIN tbl_ProductionMachineLoading PM
--        ON M.ID = PM.MachineId

--    WHERE M.IsDeleted = 0
--      AND M.IsActive = 1
--      AND M.AllocatedStage = 'Stage 1'

--    GROUP BY
--        M.ID,
--        M.MachinePerHRQty,
--        M.MachineRunningHR

--    HAVING
--        (
--            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
--             TRY_CAST(M.MachineRunningHR AS FLOAT))
--            -
--            ISNULL(
--                SUM(
--                    CASE
--                        WHEN PM.ProductionPlanId = @Id
--                         AND PM.AllocatedStage = 'Stage 1'
--                        THEN PM.PlannedQty
--                        ELSE 0
--                    END
--                ), 0
--            )
--        ) > 0

--    ORDER BY M.ID;

--    OPEN MachineCursor;

--    FETCH NEXT FROM MachineCursor
--    INTO @MachineIdLocal, @AvailableQty;

--    ---------------------------------------------------
--    -- STEP 3: ALLOCATION LOOP (NO OVERBOOKING)
--    ---------------------------------------------------
--    WHILE @@FETCH_STATUS = 0
--          AND @RemainingQty > 0
--    BEGIN

--        ---------------------------------------------------
--        -- STEP 3.1: REAL TIME CAPACITY CHECK
--        ---------------------------------------------------
--        DECLARE @MachineCapacity FLOAT;
--        DECLARE @UsedQty FLOAT;
--        DECLARE @FreeQty FLOAT;

--        SELECT
--            @MachineCapacity =
--                TRY_CAST(MachinePerHRQty AS FLOAT) *
--                TRY_CAST(MachineRunningHR AS FLOAT)
--        FROM tbl_MachineMaster
--        WHERE ID = @MachineIdLocal;

--        SELECT
--            @UsedQty = ISNULL(SUM(PlannedQty), 0)
--        FROM tbl_ProductionMachineLoading
--        WHERE MachineId = @MachineIdLocal
--          AND ProductionPlanId = @Id
--          AND AllocatedStage = 'Stage 1';

--        SET @FreeQty = @MachineCapacity - @UsedQty;

--        ---------------------------------------------------
--        -- SKIP IF NO CAPACITY
--        ---------------------------------------------------
--        IF @FreeQty <= 0
--        BEGIN
--            FETCH NEXT FROM MachineCursor
--            INTO @MachineIdLocal, @AvailableQty;

--            CONTINUE;
--        END

--        ---------------------------------------------------
--        -- STEP 3.2: SAFE ALLOCATION
--        ---------------------------------------------------
--        SET @AllocateQty =
--            CASE
--                WHEN @RemainingQty >= @FreeQty
--                    THEN @FreeQty
--                ELSE @RemainingQty
--            END;

--        ---------------------------------------------------
--        -- STEP 4: INSERT ONLY SAFE VALUE
--        ---------------------------------------------------
--        INSERT INTO tbl_ProductionMachineLoading
--        (
--            ProductionPlanId,
--            WorkOrderId,
--            MachineId,
--            AllocatedStage,
--            ScheduleDate,
--            PlannedQty,
--            ProducedQty,
--            Status
--        )
--        VALUES
--        (
--            @Id,
--            @WorkOrderId,
--            @MachineIdLocal,
--            'Stage 1',
--            GETDATE(),
--            @AllocateQty,
--            0,
--            'In-Process'
--        );

--        ---------------------------------------------------
--        -- STEP 5: UPDATE REMAINING
--        ---------------------------------------------------
--        SET @RemainingQty = @RemainingQty - @AllocateQty;

--        ---------------------------------------------------
--        -- NEXT MACHINE
--        ---------------------------------------------------
--        FETCH NEXT FROM MachineCursor
--        INTO @MachineIdLocal, @AvailableQty;

--    END

--    CLOSE MachineCursor;
--    DEALLOCATE MachineCursor;

--    ---------------------------------------------------
--    -- FINAL OUTPUT (NO NEGATIVE POSSIBLE)
--    ---------------------------------------------------
--    SELECT
--        @Id AS ProductionPlanId,
--        @RemainingQty AS PendingQty,
--        'SAFE PRODUCTION COMPLETED (NO OVERBOOKING)' AS Message;

--END


     IF @SP_Action = 'GetReceivedWO'
     Begin
--     WITH WorkOrders AS
--(
--    SELECT *
--    FROM tbl_ProductionInatial
--    WHERE WorkOrderNo LIKE
--    CASE
--        WHEN ISNULL(@WorkOrderNo,'') <> ''
--            THEN @WorkOrderNo
--        ELSE '%'
--    END
--),
--NUMBERED AS
--(
--    SELECT *,
--           ROW_NUMBER() OVER(ORDER BY ID DESC) AS RN
--    FROM WorkOrders
--),
--Loading AS
--(
--    SELECT
--        ProductionPlanId,
--        SUM(PlannedQty) AS ScheduledQty
--    FROM tbl_ProductionMachineLoading
--    GROUP BY ProductionPlanId
--)

--SELECT
--    N.*,
--    ISNULL(L.ScheduledQty,0) AS ScheduledQty,
--    N.TotalQty - ISNULL(L.ScheduledQty,0) AS PendingQty
--FROM NUMBERED N
--LEFT JOIN Loading L
--    ON L.ProductionPlanId = N.ID
--WHERE @ShowRecords = 0
--   OR N.RN <= @ShowRecords
--ORDER BY N.ID DESC;



--WITH WorkOrders AS
--(
--    SELECT *
--    FROM tbl_ProductionInatial
--    WHERE WorkOrderNo LIKE
--        CASE
--            WHEN ISNULL(@WorkOrderNo,'') <> ''
--                THEN @WorkOrderNo
--            ELSE '%'
--        END
--),

--NUMBERED AS
--(
--    SELECT *,
--           ROW_NUMBER() OVER(ORDER BY ID DESC) AS RN
--    FROM WorkOrders
--),

---- ✅ TOTAL per WorkOrder (FIX)
--Loading AS
--(
--    SELECT
--        ProductionPlanId,
--        SUM(PlannedQty) AS ScheduledQty,
--        MIN(ScheduleDate) AS FirstScheduleDate,
--        MAX(ScheduleDate) AS LastScheduleDate
--    FROM tbl_ProductionMachineLoading
--    GROUP BY ProductionPlanId
--)

--SELECT
--    N.ID,
--    N.WorkOrderNo,
--    N.Size,
--    CAST(CAST(N.TotalQty AS FLOAT) AS INT) AS TotalQty,
--CAST(CAST(ISNULL(L.ScheduledQty,0) AS FLOAT) AS INT) AS ScheduledQty,
--CAST(
--    CAST(N.TotalQty AS FLOAT)
--    - CAST(ISNULL(L.ScheduledQty,0) AS FLOAT)
--AS INT) AS PendingQty,
--   CONVERT(VARCHAR(19), L.FirstScheduleDate, 120) AS FirstScheduleDateTime,
--    CONVERT(VARCHAR(19), L.LastScheduleDate, 120) AS LastScheduleDateTime,

--    CASE
--        WHEN ISNULL(L.ScheduledQty,0) = 0 THEN 'Not Scheduled'
--        WHEN ISNULL(L.ScheduledQty,0) < N.TotalQty THEN 'Partially Scheduled'
--        ELSE 'Fully Scheduled'
--    END AS ProductionStatus,

--    CASE
--        WHEN L.LastScheduleDate IS NULL THEN NULL
--        WHEN CONVERT(date, L.LastScheduleDate) = CONVERT(date, GETDATE())
--            THEN 'Scheduled Today'
--        ELSE 'Scheduled'
--    END AS ScheduleStatus

--FROM NUMBERED N
--LEFT JOIN Loading L
--    ON L.ProductionPlanId = N.ID

--WHERE @ShowRecords = 0
--   OR N.RN <= @ShowRecords

--ORDER BY N.ID DESC;


WITH WorkOrders AS
(
    SELECT *
    FROM tbl_ProductionInatial
    WHERE WorkOrderNo LIKE
        CASE
            WHEN ISNULL(@WorkOrderNo,'') <> ''
                THEN @WorkOrderNo
            ELSE '%'
        END
),

NUMBERED AS
(
    SELECT *,
           ROW_NUMBER() OVER(ORDER BY ID DESC) AS RN
    FROM WorkOrders
),

-- ?? SAFE STAGE AGGREGATION
LoadingBase AS
(
    SELECT
        l.ProductionPlanId,
        l.AllocatedStage,

        SUM(TRY_CAST(l.PlannedQty AS FLOAT)) AS ScheduledQty,
        SUM(TRY_CAST(l.ProducedQty AS FLOAT)) AS ProducedQty,

        MIN(l.ScheduleDate) AS FirstScheduleDateTime,
        MAX(l.ScheduleDate) AS LastScheduleDateTime
    FROM tbl_ProductionMachineLoading l
    GROUP BY
        l.ProductionPlanId,
        l.AllocatedStage
),

-- ?? SAP STAGE COMPLETION FLAG
StageStatus AS
(
    SELECT *,
        CASE 
            WHEN ISNULL(ProducedQty,0) >= ISNULL(ScheduledQty,0)
                THEN 1
            ELSE 0
        END AS IsCompleted
    FROM LoadingBase
),

DailyLoad AS
(
    SELECT
        CONVERT(DATE, ScheduleDate) AS ScheduleDay,
        SUM(TRY_CAST(PlannedQty AS FLOAT)) AS UsedQty,
        COUNT(*) AS JobCount
    FROM tbl_ProductionMachineLoading
    GROUP BY CONVERT(DATE, ScheduleDate)
),

Capacity AS
(
    SELECT 
        SUM(
            TRY_CAST(MachinePerHRQty AS FLOAT) *
            TRY_CAST(MachineRunningHR AS FLOAT)
        ) AS DailyCapacity
    FROM tbl_MachineMaster
    WHERE IsActive = 1 AND IsDeleted = 0
),

AvailableDays AS
(
    SELECT
        C.WorkDay,
        ISNULL(D.UsedQty,0) AS UsedQty,
        CAP.DailyCapacity,
        (CAP.DailyCapacity - ISNULL(D.UsedQty,0)) AS AvailableQty
    FROM
    (
        SELECT TOP 60
            DATEADD(DAY,
                ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1,
                CAST(GETDATE() AS DATE)
            ) AS WorkDay
        FROM master..spt_values
    ) C
    CROSS JOIN Capacity CAP
    LEFT JOIN DailyLoad D
        ON D.ScheduleDay = C.WorkDay
),

NextAvailable AS
(
    SELECT TOP 1 WorkDay
    FROM AvailableDays
    WHERE AvailableQty > 0
      AND WorkDay >= DATEADD(DAY, 1, CAST(GETDATE() AS DATE))
    ORDER BY WorkDay ASC
)

SELECT
    N.ID,
    N.WorkOrderNo,
    N.Size,

    -- ?? FIX: SAFE NUMERIC CONVERSION
    CAST(TRY_CAST(N.TotalQty AS FLOAT) AS INT) AS TotalQty,

    S.AllocatedStage AS Stage,

    CAST(ISNULL(S.ScheduledQty,0) AS INT) AS ScheduledQty,

    -- ?? SAP DEPENDENCY CONTROLLED PRODUCED QTY
    CAST(
        CASE
            WHEN S.AllocatedStage = 'Stage 1'
                THEN ISNULL(S.ProducedQty,0)

            WHEN S.AllocatedStage = 'Stage 2'
                 AND EXISTS (
                    SELECT 1
                    FROM StageStatus S1
                    WHERE S1.ProductionPlanId = S.ProductionPlanId
                      AND S1.AllocatedStage = 'Stage 1'
                      AND S1.IsCompleted = 1
                 )
                THEN ISNULL(S.ProducedQty,0)

            ELSE 0
        END
    AS INT) AS ProducedQty,

    -- ?? FIX: SAFE CALCULATION (NO NVARCHAR ERROR)
    CAST(
        TRY_CAST(N.TotalQty AS FLOAT)
        - ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID),0)
    AS INT) AS PendingQty,

    CONVERT(VARCHAR(19), S.FirstScheduleDateTime, 120) AS FirstScheduleDateTime,
    CONVERT(VARCHAR(19), S.LastScheduleDateTime, 120) AS LastScheduleDateTime,

    DL.ScheduleDay,
    DL.UsedQty,
    DL.JobCount,

    -- ?? AUTO SCHEDULE DATE
    CASE
        WHEN ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID),0) = 0
            THEN CONVERT(VARCHAR(19), NA.WorkDay, 120)

        WHEN ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID),0)
             < TRY_CAST(N.TotalQty AS FLOAT)
            THEN CONVERT(VARCHAR(19), NA.WorkDay, 120)

        ELSE CONVERT(VARCHAR(19), S.LastScheduleDateTime, 120)
    END AS AutoScheduleDate,

    -- ?? PRODUCTION STATUS
    CASE
        WHEN ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID),0) = 0
            THEN 'Not Scheduled'

        WHEN ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID),0)
             < TRY_CAST(N.TotalQty AS FLOAT)
            THEN 'Partially Scheduled'

        ELSE 'Fully Scheduled'
    END AS ProductionStatus,

    -- ?? SCHEDULE STATUS
    CASE
        WHEN S.LastScheduleDateTime IS NULL THEN NULL
        WHEN CONVERT(DATE, S.LastScheduleDateTime) = CONVERT(DATE, GETDATE())
            THEN 'Scheduled Today'
        ELSE 'Scheduled'
    END AS ScheduleStatus

FROM NUMBERED N
LEFT JOIN StageStatus S
    ON S.ProductionPlanId = N.ID

OUTER APPLY
(
    SELECT TOP 1 *
    FROM DailyLoad DL2
    ORDER BY DL2.ScheduleDay DESC
) DL

CROSS APPLY NextAvailable NA

WHERE @ShowRecords = 0
   OR N.RN <= @ShowRecords

ORDER BY N.ID DESC;

     END

-- IF @SP_Action = 'StartProduction_Stage2'
--BEGIN

--    DECLARE @CurrentStage NVARCHAR(50) = 'Stage 2';
--    DECLARE @WorkOrderIdd INT;
--    DECLARE @RemainingQtyy FLOAT;
--    DECLARE @MachineIdLocall INT;
--    DECLARE @AvailableQtyy FLOAT;
--    DECLARE @AllocateQtyy FLOAT;

--    ---------------------------------------------------
--    -- STEP 1: GET WORK ORDER
--    ---------------------------------------------------
--    SELECT 
--        @WorkOrderIdd = WorkOrderId,
--        @RemainingQtyy = TotalQty
--    FROM tbl_ProductionInatial
--    WHERE ID = @Id;

--    ---------------------------------------------------
--    -- STEP 2: MACHINE CURSOR (STAGE 2 CAPACITY)
--    ---------------------------------------------------
--    DECLARE TransferCursor CURSOR FOR

--    SELECT 
--        M.ID,
--        (
--            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
--             TRY_CAST(M.MachineRunningHR AS FLOAT))
--            - ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0)
--        ) AS AvailableQty
--    FROM tbl_MachineMaster M
--    LEFT JOIN tbl_ProductionMachineLoading PM
--        ON M.ID = PM.MachineId
--        AND PM.Status = 'In-Process'
--        AND PM.AllocatedStage = @CurrentStage
--    WHERE M.IsDeleted = 0
--      AND M.IsActive = 1
--      AND M.AllocatedStage = @CurrentStage
--    GROUP BY
--        M.ID,
--        M.MachinePerHRQty,
--        M.MachineRunningHR
--    HAVING
--        (
--            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
--             TRY_CAST(M.MachineRunningHR AS FLOAT))
--            - ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0)
--        ) > 0
--    ORDER BY AvailableQty DESC;

--    OPEN TransferCursor;

--    FETCH NEXT FROM TransferCursor
--    INTO @MachineIdLocall, @AvailableQtyy;

--    WHILE @@FETCH_STATUS = 0 AND @RemainingQtyy > 0
--    BEGIN

--        SET @AllocateQtyy =
--            CASE 
--                WHEN @RemainingQtyy >= @AvailableQtyy THEN @AvailableQtyy
--                ELSE @RemainingQtyy
--            END;

--        ---------------------------------------------------
--        -- STEP 3: DEDUCT FROM STAGE 1 PROPERLY (FIFO SAFE)
--        ---------------------------------------------------
--        ;WITH Stage1 AS
--        (
--            SELECT TOP 1 Id, PlannedQty
--            FROM tbl_ProductionMachineLoading
--            WHERE ProductionPlanId = @Id
--              AND AllocatedStage = 'Stage 1'
--              AND PlannedQty > 0
--            ORDER BY Id
--        )
--        UPDATE Stage1
--        SET PlannedQty = PlannedQty - @AllocateQtyy;

--        ---------------------------------------------------
--        -- STEP 4: INSERT INTO STAGE 2
--        ---------------------------------------------------
--        INSERT INTO tbl_ProductionMachineLoading
--        (
--            ProductionPlanId,
--            WorkOrderId,
--            MachineId,
--            AllocatedStage,
--            ScheduleDate,
--            PlannedQty,
--            ProducedQty,
--            Status
--        )
--        VALUES
--        (
--            @Id,
--            @WorkOrderIdd,
--            @MachineIdLocall,
--            @CurrentStage,
--            GETDATE(),
--            @AllocateQtyy,
--            0,
--            'In-Process'
--        );

--        SET @RemainingQtyy = @RemainingQtyy - @AllocateQtyy;

--        FETCH NEXT FROM TransferCursor
--        INTO @MachineIdLocall, @AvailableQtyy;
--    END

--    CLOSE TransferCursor;
--    DEALLOCATE TransferCursor;

--    ---------------------------------------------------
--    -- FINAL OUTPUT
--    ---------------------------------------------------
--    SELECT 
--        @Id AS ProductionPlanId,
--        @RemainingQtyy AS RemainingQty,
--        @CurrentStage AS Stage,
--        'Stage 2 allocation completed correctly' AS Message;

--END


IF @SP_Action = 'StartProduction_Stage2'
BEGIN

    DECLARE @CurrentStage NVARCHAR(50) = 'Stage 2';

    DECLARE @MachineIdLocall INT;
    DECLARE @AvailableQtyy FLOAT;
    DECLARE @AllocateQtyy FLOAT;

    DECLARE @ProdId INT;
   

    ---------------------------------------------------
    -- STEP 1: WORK ORDER FIFO QUEUE
    ---------------------------------------------------
    DECLARE @WorkQueue TABLE
    (
        RowNum INT IDENTITY(1,1),
        ProductionId INT,
        WorkOrderId INT,
        RemainingQty FLOAT
    );

INSERT INTO @WorkQueue (ProductionId, WorkOrderId, RemainingQty)
SELECT
    PI.ID,
    PI.WorkOrderId,
    ISNULL(
    (
        SELECT SUM(PlannedQty)
        FROM tbl_ProductionMachineLoading
        WHERE ProductionPlanId = PI.ID
          AND AllocatedStage = 'Stage 1'
          AND PlannedQty > 0
    ),0)
FROM tbl_ProductionInatial PI
WHERE PI.ID = @Id;

    ---------------------------------------------------
    -- STEP 2: MACHINE CURSOR
    ---------------------------------------------------
    DECLARE TransferCursor CURSOR FOR

    SELECT 
        M.ID,
        (
            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
             TRY_CAST(M.MachineRunningHR AS FLOAT))
            - ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0)
        ) AS AvailableQty
    FROM tbl_MachineMaster M
    LEFT JOIN tbl_ProductionMachineLoading PM
        ON M.ID = PM.MachineId
        AND PM.Status = 'In-Process'
        AND PM.AllocatedStage = @CurrentStage
    WHERE M.IsDeleted = 0
      AND M.IsActive = 1
      AND M.AllocatedStage = @CurrentStage
    GROUP BY
        M.ID,
        M.MachinePerHRQty,
        M.MachineRunningHR
    HAVING
        (
            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
             TRY_CAST(M.MachineRunningHR AS FLOAT))
            - ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)),0)
        ) > 0
    ORDER BY M.ID;

    OPEN TransferCursor;

    FETCH NEXT FROM TransferCursor
    INTO @MachineIdLocall, @AvailableQtyy;

    ---------------------------------------------------
    -- STEP 3: LOOP WORK ORDERS
    ---------------------------------------------------
    DECLARE @i INT = 1;
    DECLARE @Max INT;

    SELECT @Max = COUNT(*) FROM @WorkQueue;

    WHILE @@FETCH_STATUS = 0 AND @i <= @Max
    BEGIN

        SELECT 
            @ProdId = ProductionId,
            @WorkOrderId = WorkOrderId,
            @RemainingQty = RemainingQty
        FROM @WorkQueue
        WHERE RowNum = @i;

        ---------------------------------------------------
        -- SKIP IF NO QTY
        ---------------------------------------------------
        IF @RemainingQty <= 0
        BEGIN
            SET @i = @i + 1;
            CONTINUE;
        END

        ---------------------------------------------------
        -- STEP 4: MACHINE ALLOCATION LOOP
        ---------------------------------------------------
        WHILE @RemainingQty > 0 AND @@FETCH_STATUS = 0
        BEGIN

            ---------------------------------------------------
            -- TAKE MIN OF MACHINE CAPACITY & REMAINING QTY
            ---------------------------------------------------
            SET @AllocateQtyy =
                CASE 
                    WHEN @RemainingQty >= @AvailableQtyy
                        THEN @AvailableQtyy
                    ELSE @RemainingQty
                END;

            ---------------------------------------------------
            -- DEDUCT FROM STAGE 1 FIFO
            ---------------------------------------------------
            ;WITH Stage1 AS
            (
                SELECT TOP 1 Id, PlannedQty
                FROM tbl_ProductionMachineLoading
                WHERE ProductionPlanId = @ProdId
                  AND AllocatedStage = 'Stage 1'
                  AND PlannedQty > 0
                ORDER BY Id
            )
            UPDATE Stage1
            SET PlannedQty = PlannedQty - @AllocateQtyy;

            ---------------------------------------------------
            -- INSERT STAGE 2 ALLOCATION
            ---------------------------------------------------
            INSERT INTO tbl_ProductionMachineLoading
            (
                ProductionPlanId,
                WorkOrderId,
                MachineId,
                AllocatedStage,
                ScheduleDate,
                PlannedQty,
                ProducedQty,
                Status
            )
            VALUES
            (
                @ProdId,
                @WorkOrderId,
                @MachineIdLocall,
                @CurrentStage,
                GETDATE(),
                @AllocateQtyy,
                0,
                'In-Process'
            );

            ---------------------------------------------------
            -- UPDATE REMAINING WORK ORDER QTY
            ---------------------------------------------------
            SET @RemainingQty = @RemainingQty - @AllocateQtyy;

            ---------------------------------------------------
            -- MOVE TO NEXT MACHINE IF CURRENT IS FULL
            ---------------------------------------------------
            IF @AllocateQtyy = @AvailableQtyy
            BEGIN
                FETCH NEXT FROM TransferCursor
                INTO @MachineIdLocall, @AvailableQtyy;

                IF @@FETCH_STATUS <> 0
                    BREAK;
            END

        END

        SET @i = @i + 1;

    END

    CLOSE TransferCursor;
    DEALLOCATE TransferCursor;

    ---------------------------------------------------
    -- FINAL OUTPUT
    ---------------------------------------------------
    SELECT 
        @Id AS ProductionPlanId,
        'Stage 2 allocation completed successfully with proper machine chaining' AS Message;

END




END


-- Script for SP_AuthorizationMaster
GO
CREATE PROCEDURE dbo.SP_AuthorizationMaster
 @ShowRecords int =0
,@Id int =0
,@MenuName nvarchar(200) = null
,@PageName nvarchar(200) = null
,@UserID int = 0
,@UserName nvarchar(200)= null
,@MenuId int = 0
,@PageAccess bit = 0
,@PagesButtonAccess bit = 0
,@ActionBy nvarchar(200) = null
,@SP_Action nvarchar(100) =null
AS
BEGIN
  IF @SP_Action='GetAuthList'
   BEGIN
     SELECT * FROM tbl_AuthPages
   END

  IF @SP_Action='CreateAuth'
   BEGIN
     INSERT INTO tbl_AuthPages(MenuName,PageName)
     VALUES(@MenuName,@PageName)
   END

  IF @SP_Action='AuthorizationInsert'
   BEGIN
     INSERT INTO tbl_UserRoleAuthorization(UserID,UserName,MenuId,MenuName,
			PageName,PageAccess,PagesButtonAccess,CreatedBy,CreatedOn)
     VALUES(@UserID,@UserName,@MenuId,@MenuName,
			@PageName,@PageAccess,@PagesButtonAccess,@ActionBy,GETDATE())
   END

   IF @SP_Action='AuthorizationDelete'
   BEGIN
     DELETE FROM tbl_UserRoleAuthorization WHERE UserID = @UserID
   END

END



-- Script for SP_UserMaster
GO
CREATE PROCEDURE [dbo].[SP_UserMaster] 
     @ShowRecords INT = 0
	,@Id int =0
	,@UserCode NVARCHAR(100) = NULL
	,@FullName NVARCHAR(500) = NULL
	,@MobileNo NVARCHAR(100) = NULL
	,@EmialId NVARCHAR(100) = NULL
	,@Password NVARCHAR(100) = NULL
	,@UserRole NVARCHAR(100) = NULL
	,@IsActive NVARCHAR(100) = NULL
	,@IsDeleted NVARCHAR(100) = NULL
	,@ActionBy NVARCHAR(100) = NULL
	,@SP_Action NVARCHAR(100) = NULL
AS
BEGIN
	IF (@SP_Action = 'UserList')
	BEGIN
		WITH UserMaster
		AS (
			SELECT UM.ID AS ID,UserCode,FullName,EmailId,UserRole,IsActivate,LoginPass
			FROM tbl_UserMaster UM
			INNER JOIN tbl_RoleMaster RM ON RM.Roles = UM.UserRole 
			WHERE UM.IsDeleted = 0 AND RM.Departments = 'In-House'
				AND (
				 @FullName = '' 
					OR FullName LIKE '%' + @FullName + '%'
					OR UserCode LIKE '%' + @FullName + '%'
					OR EmailId LIKE '%' + @FullName + '%'
					OR UserRole LIKE '%' + @FullName + '%'
					OR LoginPass LIKE '%' + @FullName + '%'
					--FullName LIKE CASE 
					--	WHEN @FullName != ''
					--		THEN @FullName
					--	ELSE '%%'
					--	END
					)
			)
			,NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY Id DESC
					) AS RN
			FROM UserMaster
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
		ORDER BY ID DESC
	END

	IF (@SP_Action = 'UserById')
	BEGIN
		SELECT * FROM tbl_UserMaster WHERE ID = @Id
	END

	IF (@SP_Action = 'UpdateData')
	BEGIN
		UPDATE tbl_UserMaster
		SET FullName = @FullName
			,MobileNo = @MobileNo
			,EmailId = @EmialId
			,LoginPass = @Password
			,UserRole=@UserRole
			,UpdatedBy = @ActionBy
			,UpdatedOn = GETDATE()
		WHERE ID = @Id
	END

	IF (@SP_Action = 'InsertData')
	BEGIN
		INSERT INTO tbl_UserMaster (
			UserCode
			,FullName
			,MobileNo
			,EmailId
			,LoginPass
			,UserRole
			,CreatedOn
			,CreatedBy
			,IsActivate
			,IsDeleted
			)
		VALUES (
			dbo.FN_GenerateUserCode()
			,@FullName
			,@MobileNo
			,@EmialId
			,@Password
			,@UserRole
			,GETDATE()
			,@ActionBy
			,1
			,0
			)
	END

	IF (@SP_Action = 'DeleteData')
	BEGIN
		UPDATE tbl_UserMaster
		SET IsDeleted = 1
		WHERE ID = @Id
	END

	IF(@SP_Action = 'VerifyRole')
	BEGIN
	  SELECT * FROM tbl_RoleMaster WHERE UPPER(Roles) = @UserRole AND IsDeleted = 0
	END

	IF(@SP_Action = 'RoleList')
	BEGIN
	  SELECT * FROM tbl_RoleMaster WHERE IsDeleted = 0 ORDER BY ID DESC
	END

	IF(@SP_Action = 'RoleListForUser')
	BEGIN
	  SELECT * FROM tbl_RoleMaster WHERE IsDeleted = 0 AND Departments='In-House' ORDER BY ID DESC
	END

	IF(@SP_Action = 'InsertRole')
	BEGIN
	  INSERT INTO tbl_RoleMaster(Roles,Departments,IsDeleted) VALUES(@UserRole,@FullName,0)
	END

	IF(@SP_Action = 'DeleteRole')
	BEGIN
	 UPDATE tbl_RoleMaster SET IsDeleted = 1 WHERE ID =@Id
	END
END

-- Script for SP_CompanyMaster
GO
CREATE PROCEDURE [dbo].[SP_CompanyMaster]
 @ShowRecords int = 0
,@Id int =0 
,@HeaderId nvarchar(100) =null 
,@CompanyCode nvarchar(100) = null
,@CompanyName nvarchar(500) = null
,@OwnerName nvarchar(500) = null
,@CompanyOrigin nvarchar(100) = null
,@CompanyEmialId nvarchar(100) = null
,@CompanyPanCard nvarchar(100) = null
,@PaymentTerms nvarchar(500) = null
,@UDYAMNo nvarchar(100) = null
,@CINNo nvarchar(100) = null
,@WebsiteLink nvarchar(500) = null
,@ActionBy nvarchar(500) = null
,@BillAddress nvarchar(max) = null
,@BillArea nvarchar(max) = null
,@BillPinCode nvarchar(100) = null
,@BillCity nvarchar(200) = null
,@BillState nvarchar(200) = null
,@BillCountry nvarchar(200) = null
,@BillGSTNo nvarchar(200) = null
,@ShipAddress nvarchar(max) = null
,@ShipArea nvarchar(max) = null
,@ShipPinCode nvarchar(100) = null
,@ShipCity nvarchar(200) = null
,@ShipState nvarchar(200) = null
,@ShipCountry nvarchar(200) = null
,@ShipGSTNo nvarchar(200) = null
,@FName nvarchar(500) = null
,@MobileNo nvarchar(100) = null
,@EmialID nvarchar(100) = null
,@Department nvarchar(100) = null
,@Designation nvarchar(100) = null
,@SP_Action nvarchar(100) = null
,@Result int output
AS
BEGIN
        -- Company Main Table
  	  IF @SP_Action = 'MainCompanyList'
	   BEGIN
		 WITH CompanyMain
			AS (
			    SELECT * FROM tbl_CompanyMain WHERE IsDeleted = 0  
			       AND (
				        @CompanyName = '' 
						OR CompanyCode LIKE '%' + @CompanyName + '%'
						OR CompanyName LIKE '%' + @CompanyName + '%'
						OR OwnerName LIKE '%' + @CompanyName + '%'
						OR CompanyOrigin LIKE '%' + @CompanyName + '%'

				         
						--CompanyName LIKE CASE 
						--	WHEN @CompanyName != ''
						--		THEN @CompanyName
						--	ELSE '%%'
						--	END
			          )
			   ),NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY Id DESC
					) AS RN
			FROM CompanyMain
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
		ORDER BY ID DESC
		 SET @Result = 0
	   END

	  IF @SP_Action = 'MainCompanyListById'
	   BEGIN
		  SELECT * FROM tbl_CompanyMain WHERE ID = @Id
		  SET @Result = @Id
	   END
	 
	  IF @SP_Action = 'InsertMainCompany'
	   BEGIN
	     INSERT INTO tbl_CompanyMain (
		     CompanyCode
			,CompanyName
			,OwnerName
			,CompanyOrigin
			,CompanyEmialId
			,CompanyPanCard
			,PaymentTerms
			,UDYAMNo
			,CINNo
			,WebsiteLink
			,IsDeleted
			,CreatedBy
			,CreatedOn
			)
		VALUES (
		     [dbo].[FN_CompanyCode]() 
			,@CompanyName
            ,@OwnerName
			,@CompanyOrigin
			,@CompanyEmialId
			,@CompanyPanCard
			,@PaymentTerms
			,@UDYAMNo
			,@CINNo
			,@WebsiteLink
			,0
			,@ActionBy
			,GETDATE()
			)
        SET @Result = SCOPE_IDENTITY()
	   END

      IF @SP_Action = 'UpdateMainCompany'
	   BEGIN
	    UPDATE tbl_CompanyMain
		SET CompanyName =@CompanyName
			,OwnerName = @OwnerName
			,CompanyOrigin = @CompanyOrigin
			,CompanyEmialId = @CompanyEmialId
			,CompanyPanCard = @CompanyPanCard
			,PaymentTerms = @PaymentTerms
			,UDYAMNo= @UDYAMNo
			,CINNo = @CINNo
			,WebsiteLink = @WebsiteLink
			,UpdatedBy = @ActionBy
			,UpdatedOn = GETDATE()
		WHERE ID = @Id
		SET @Result = @Id
	   END

      IF (@SP_Action = 'DeleteMainCompany')
		BEGIN
			UPDATE tbl_CompanyMain
			SET IsDeleted = 1
			WHERE ID = @Id
			SET @Result = @Id
		END

     -- Company Details Table
      IF @SP_Action = 'CompDetailsListById'
	   BEGIN
	     SELECT * FROM tbl_CompanyDetails WHERE HeaderId =@Id
		 SET @Result = @Id
 	   END 
     
      IF @SP_Action = 'InsertCompDetails'
	   BEGIN
	     INSERT INTO tbl_CompanyDetails (
			 HeaderId
			,BillAddress
			,BillArea
			,BillPinCode
			,BillCity
			,BillState
			,BillCountry
			,BillGSTNo
			,ShipAddress
			,ShipArea
			,ShipPinCode
			,ShipCity
			,ShipState
			,ShipCountry
			,ShipGSTNo
			)
		VALUES (
			 @HeaderId
            ,@BillAddress
			,@BillArea
			,@BillPinCode
			,@BillCity
			,@BillState
			,@BillCountry
			,@BillGSTNo
			,@ShipAddress
			,@ShipArea
			,@ShipPinCode
			,@ShipCity
			,@ShipState
			,@ShipCountry
			,@ShipGSTNo
			)
			 SET @Result = SCOPE_IDENTITY()
	   END
      
	  IF (@SP_Action = 'DeleteCompDetails')
		BEGIN
			DELETE tbl_CompanyDetails WHERE HeaderId = @Id
			SET @Result = @Id
		END

       -- Company Contact Details Table
      IF @SP_Action = 'CompCntDetailsListById'
	   BEGIN
	     SELECT * FROM tbl_CompanyContactDtls WHERE HeaderId =@Id
		 SET @Result = @Id
 	   END 
     
      IF @SP_Action = 'InsertCompCntDetails'
	   BEGIN
	     INSERT INTO tbl_CompanyContactDtls (
			 HeaderId
			,FName
			,MobileNo
			,EmialID
			,Department
			,Designation
			)
		VALUES (
			 @HeaderId
            ,@FName
			,@MobileNo
			,@EmialID
			,@Department
			,@Designation
			)
			 SET @Result = SCOPE_IDENTITY()
	   END
      
	  IF (@SP_Action = 'DeleteCompCntDetails')
		BEGIN
			DELETE tbl_CompanyContactDtls WHERE HeaderId = @Id
			SET @Result = @Id
		END
END


-- Script for SP_RebalanceStage1Capacity
GO
CREATE PROCEDURE SP_RebalanceStage1Capacity
AS
BEGIN
    SET NOCOUNT ON;

    ---------------------------------------------------
    -- STEP 1: BUILD WORK ORDER FIFO QUEUE
    ---------------------------------------------------
    DECLARE @WorkQueue TABLE
    (
        RowNum INT IDENTITY(1,1),
        WorkOrderId INT,
        ProductionId INT,
        RemainingQty FLOAT
    );

    INSERT INTO @WorkQueue (ProductionId, WorkOrderId, RemainingQty)
    SELECT
        ID,
        WorkOrderId,
        TotalQty
    FROM tbl_ProductionInatial
    ORDER BY ID ASC;


    ---------------------------------------------------
    -- STEP 2: MACHINE CURSOR (CAPACITY)
    ---------------------------------------------------
    DECLARE @MachineId INT;
    DECLARE @AvailableQty FLOAT;

    DECLARE MachineCursor CURSOR FOR
SELECT
    M.ID,
    MC.AvailableQty
FROM tbl_MachineMaster M
CROSS APPLY
(
    SELECT
        (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
         TRY_CAST(M.MachineRunningHR AS FLOAT))
        - ISNULL((
            SELECT SUM(PM.PlannedQty)
            FROM tbl_ProductionMachineLoading PM
            WHERE PM.MachineId = M.ID
              AND PM.Status = 'In-Process'
        ),0) AS AvailableQty
) MC
WHERE M.IsActive = 1
  AND M.IsDeleted = 0
  AND MC.AvailableQty > 0
ORDER BY M.ID;

    OPEN MachineCursor;

    FETCH NEXT FROM MachineCursor INTO @MachineId, @AvailableQty;

    ---------------------------------------------------
    -- STEP 3: FIFO DISTRIBUTION ENGINE
    ---------------------------------------------------
    DECLARE @i INT = 1;
    DECLARE @Max INT;
    SELECT @Max = COUNT(*) FROM @WorkQueue;

    WHILE @@FETCH_STATUS = 0 AND @i <= @Max
    BEGIN

        DECLARE @ProdId INT;
        DECLARE @WorkOrderId INT;
        DECLARE @RemainingQty FLOAT;
        DECLARE @AllocateQty FLOAT;

        SELECT
            @ProdId = ProductionId,
            @WorkOrderId = WorkOrderId,
            @RemainingQty = RemainingQty
        FROM @WorkQueue
        WHERE RowNum = @i;

        WHILE @RemainingQty > 0 AND @@FETCH_STATUS = 0
        BEGIN

            -- move to next machine if current is full
            IF @AvailableQty <= 0
            BEGIN
                FETCH NEXT FROM MachineCursor
                INTO @MachineId, @AvailableQty;

                IF @@FETCH_STATUS <> 0
                    BREAK;
            END

            SET @AllocateQty =
                CASE
                    WHEN @RemainingQty >= @AvailableQty
                        THEN @AvailableQty
                    ELSE @RemainingQty
                END;

            IF @AllocateQty <= 0
                BREAK;

            ---------------------------------------------------
            -- INSERT ALLOCATION (FINAL OUTPUT ONLY)
            ---------------------------------------------------
            INSERT INTO tbl_ProductionMachineLoading
            (
                ProductionPlanId,
                WorkOrderId,
                MachineId,
                AllocatedStage,
                ScheduleDate,
                PlannedQty,
                ProducedQty,
                Status
            )
            VALUES
            (
                @ProdId,
                @WorkOrderId,
                @MachineId,
                'Stage 1',
                GETDATE(),
                @AllocateQty,
                0,
                'In-Process'
            );

            SET @RemainingQty = @RemainingQty - @AllocateQty;
            SET @AvailableQty = @AvailableQty - @AllocateQty;

        END

        SET @i = @i + 1;

    END

    CLOSE MachineCursor;
    DEALLOCATE MachineCursor;

    ---------------------------------------------------
    -- STEP 4: RESULT
    ---------------------------------------------------
    SELECT 'AUTO PRODUCTION SCHEDULER COMPLETED SUCCESSFULLY' AS Message;

END

-- Script for SP_DashboardDetails
GO
CREATE PROCEDURE SP_DashboardDetails
 @SP_Action nvarchar(100) = NULL 
AS
BEGIN
 IF @SP_Action = 'CardsDetails'
  BEGIN
    SELECT
    (SELECT COUNT(*) FROM tbl_UserMaster WHERE UserRole = 'Dealers' AND IsDeleted = 0) AS DealersCount,
    (SELECT COUNT(*) FROM tbl_StageMaster WHERE IsDeleted = 0) AS StageCount,
    (SELECT COUNT(*) FROM tbl_MachineMaster WHERE IsDeleted = 0) AS MachineCount,
    (SELECT SUM(TRY_CAST(MachinePerHRQty AS FLOAT) * TRY_CAST(MachineRunningHR AS FLOAT)) AS StageDailyCapacity FROM [dbo].[tbl_MachineMaster] WHERE IsActive = 1 AND IsDeleted = 0) AS UnitCapacity; 
  END
 
 IF @SP_Action = 'Dealers'
  BEGIN
    SELECT UserCode AS 'User Code',FullName AS 'Distributer Name',EmailId AS 'Email Id',LoginPass AS 'Password' FROM tbl_UserMaster WHERE UserRole = 'Dealers' AND IsDeleted = 0
  END
 
 IF @SP_Action = 'Stages'
  BEGIN
   SELECT SatgeName AS 'Stage Name', SatgeCapacity AS 'Stage Capacity', CapacityUnit AS 'Unit' FROM tbl_StageMaster WHERE IsDeleted = 0
  END
 
  IF @SP_Action = 'Machines'
  BEGIN
    SELECT AllocatedStage AS 'Stage Name', MachineName AS 'Machine Name',MachineRunningHR AS 'Running Hours', MachinePerHRQty AS 'Per Hour Capacity' FROM tbl_MachineMaster WHERE IsDeleted = 0
  END
 
  IF @SP_Action = 'Capacity'
  BEGIN
     SELECT
        AllocatedStage AS 'Stages',
        SUM(
            TRY_CAST(MachinePerHRQty AS FLOAT) *
            TRY_CAST(MachineRunningHR AS FLOAT)
        ) AS 'Stage Capacity'
    FROM [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineMaster]
    WHERE IsActive = 1
    AND IsDeleted = 0
    GROUP BY AllocatedStage;
  END
 
END


    

















-- Script for SP_AutoProductionScheduler
GO
CREATE PROCEDURE SP_AutoProductionScheduler
AS
BEGIN
    ---------------------------------------------------
    DECLARE @Work TABLE
    (
        Id INT,
        WorkOrderId INT,
        RemainingQty FLOAT
    );

    INSERT INTO @Work
    SELECT
        PI.ID,
        PI.WorkOrderId,
        PI.TotalQty - ISNULL((
            SELECT SUM(PlannedQty)
            FROM tbl_ProductionMachineLoading
            WHERE ProductionPlanId = PI.ID
        ),0)
    FROM tbl_ProductionInatial PI;

    ---------------------------------------------------
    -- STEP 2: MACHINE CURSOR (STAGE 1 FIRST)
    ---------------------------------------------------
    DECLARE @MachineId INT;
    DECLARE @Capacity FLOAT;

    DECLARE MachineCursor CURSOR FOR
    SELECT
        M.ID,
        (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
         TRY_CAST(M.MachineRunningHR AS FLOAT))
        - ISNULL((
            SELECT SUM(PlannedQty)
            FROM tbl_ProductionMachineLoading
            WHERE MachineId = M.ID
              AND Status = 'In-Process'
        ),0)
    FROM tbl_MachineMaster M
    WHERE M.IsActive = 1 AND M.IsDeleted = 0
    ORDER BY M.ID;

    OPEN MachineCursor;
    FETCH NEXT FROM MachineCursor INTO @MachineId, @Capacity;

    ---------------------------------------------------
    -- STEP 3: GLOBAL ALLOCATION LOOP
    ---------------------------------------------------
    WHILE @@FETCH_STATUS = 0
    BEGIN

        WHILE @Capacity > 0
        BEGIN

            DECLARE @Id INT;
            DECLARE @WorkOrderId INT;
            DECLARE @Qty FLOAT;

            ---------------------------------------------------
            -- FIFO WORK PICK
            ---------------------------------------------------
            SELECT TOP 1
                @Id = Id,
                @WorkOrderId = WorkOrderId,
                @Qty = RemainingQty
            FROM @Work
            WHERE RemainingQty > 0
            ORDER BY Id;

            IF @Id IS NULL BREAK;

            DECLARE @Alloc FLOAT =
                CASE WHEN @Qty > @Capacity THEN @Capacity ELSE @Qty END;

            ---------------------------------------------------
            -- INSERT ALLOCATION (STAGE 1)
            ---------------------------------------------------
            INSERT INTO tbl_ProductionMachineLoading
            (
                ProductionPlanId,
                WorkOrderId,
                MachineId,
                AllocatedStage,
                ScheduleDate,
                PlannedQty,
                ProducedQty,
                Status
            )
            VALUES
            (
                @Id,
                @WorkOrderId,
                @MachineId,
                'Stage 1',
                GETDATE(),
                @Alloc,
                0,
                'In-Process'
            );

            ---------------------------------------------------
            -- UPDATE WORK + MACHINE
            ---------------------------------------------------
            UPDATE @Work
            SET RemainingQty = RemainingQty - @Alloc
            WHERE Id = @Id;

            SET @Capacity = @Capacity - @Alloc;

        END

        FETCH NEXT FROM MachineCursor INTO @MachineId, @Capacity;
    END

    CLOSE MachineCursor;
    DEALLOCATE MachineCursor;

 
    --EXEC SP_StageForward_ToStage2;

    SELECT 'FULL AUTO SCHEDULING COMPLETED' AS Message;

END

-- Script for SP_oepratordetails
GO
CREATE PROCEDURE [dbo].[SP_oepratordetails]
    @ShowRecords INT = 0,
    @Id int = 0,
    @IsDeleted bit = 0,
    @ActionBy nvarchar(500) = null,
    @SP_Action nvarchar(500) = null
AS
BEGIN
     IF (@SP_Action = 'Getmachinedetails')
    BEGIN
        select Hdr.SeriesNo,
               Hdr.TallyRefno,
               Hdr.WorkOrderDate,
               st1.sheduledate,
               st1.ProductName,
               st1.PartNo,
               st1.Size,
               st1.ReceivedQty,
               st1.CompletedQty,
               CompletedDate,
               WOStatus
        from tbl_Stage1Production as st1
            inner join [dbo].[tbl_MachineMaster] as Ms
                on Ms.id = st1.ID
          inner join [dbo].[tbl_WorkOrderHdr] as Hdr
                on Hdr.ID = st1.WOHeaderId

    END

     IF (@SP_Action = 'Getmachinedetails')
    BEGIN
        select Hdr.SeriesNo,
               Hdr.TallyRefno,
               Hdr.WorkOrderDate,
               st1.sheduledate,
               st1.ProductName,
               st1.PartNo,
               st1.Size,
               st1.ReceivedQty,
               st1.CompletedQty,
               CompletedDate,
               WOStatus
        from tbl_Stage1Production as st1
            inner join [dbo].[tbl_MachineMaster] as Ms
                on Ms.id = st1.ID
          inner join [dbo].[tbl_WorkOrderHdr] as Hdr
                on Hdr.ID = st1.WOHeaderId

    END 



        IF @SP_Action = 'DailyTotalcapacity'
    BEGIN
        SELECT AllocatedStage,
               SUM(TRY_CAST(MachinePerHRQty AS FLOAT) * TRY_CAST(MachineRunningHR AS FLOAT)) AS StageDailyCapacity
        FROM [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineMaster]
        WHERE IsActive = 1
              AND IsDeleted = 0
        GROUP BY AllocatedStage;
    END

    IF @SP_Action = 'machinecount'
    BEGIN
        SELECT AllocatedStage,
               COUNT(ID) AS MachineCount
        FROM [DB_AcryshadeLaminatesTest].[dbo].[tbl_MachineMaster]
        WHERE IsActive = 1
              AND IsDeleted = 0
        GROUP BY AllocatedStage
        ORDER BY AllocatedStage;
    END

    IF @SP_Action = 'GetCapacity'
    BEGIN
        SELECT M.ID as MachineID,
               M.AllocatedStage,
               M.MachineName,
               (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)) AS MachineCapacity,
               ISNULL(SUM(TRY_CAST(PM.ReceivedQty AS FLOAT)), 0) AS MachineLoad,
               ((TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT))
                - ISNULL(SUM(TRY_CAST(PM.ReceivedQty AS FLOAT)), 0)
               ) AS MachineAvailable,

               -- ✔ LOAD %
               CASE
                   WHEN (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)) = 0 THEN
                       0
                   ELSE
                       ROUND(
                                (ISNULL(SUM(TRY_CAST(PM.ReceivedQty AS FLOAT)), 0) * 100.0)
                                / (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)),
                                2
                            )
               END AS LoadPercentage
        FROM tbl_MachineMaster M
            LEFT JOIN tbl_Stage1Production PM
                ON M.ID = PM.MachineId
                   --AND PM.Status = 'In-Process'
        WHERE M.IsDeleted = 0
              AND M.IsActive = 1 AND M.AllocatedStage ='Stage 1'
        GROUP BY M.ID,
                 M.AllocatedStage,
                 M.MachineName,
                 M.MachinePerHRQty,
                 M.MachineRunningHR;
    END

    IF @SP_Action = 'StartProduction'
    BEGIN

        DECLARE @RemainingQty FLOAT;
        DECLARE @MachineIdLocal INT;
        DECLARE @AvailableQty FLOAT;
        DECLARE @AllocateQty FLOAT;
        DECLARE @WorkOrderId INT;

        SELECT @RemainingQty = TotalQty,
               @WorkOrderId = WorkOrderId
        FROM tbl_ProductionInatial
        WHERE ID = @Id;


        DECLARE MachineCursor CURSOR FOR
        SELECT M.ID,
               ((TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT))
                - ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)), 0)
               ) AS AvailableQty
        FROM tbl_MachineMaster M
            LEFT JOIN tbl_ProductionMachineLoading PM
                ON M.ID = PM.MachineId
                   AND PM.Status = 'In-Process'
        WHERE M.IsDeleted = 0
              AND M.IsActive = 1
              AND M.AllocatedStage = 'Stage 1'
        GROUP BY M.ID,
                 M.MachinePerHRQty,
                 M.MachineRunningHR
        HAVING ((TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT))
                - ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)), 0)
               ) > 0
        ORDER BY
            -- ⭐ KEY FIX: prioritize machines already used first
            CASE
                WHEN ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)), 0) > 0 THEN
                    0
                ELSE
                    1
            END,
            M.ID; -- maintain stable sequence


        OPEN MachineCursor;

        FETCH NEXT FROM MachineCursor
        INTO @MachineIdLocal,
             @AvailableQty;

        WHILE @@FETCH_STATUS = 0 AND @RemainingQty > 0
        BEGIN

            SET @AllocateQty = CASE
                                   WHEN @RemainingQty >= @AvailableQty THEN
                                       @AvailableQty
                                   ELSE
                                       @RemainingQty
                               END;

            INSERT INTO tbl_ProductionMachineLoading
            (
                ProductionPlanId,
                WorkOrderId,
                MachineId,
                AllocatedStage,
                ScheduleDate,
                PlannedQty,
                ProducedQty,
                Status
            )
            VALUES
            (@Id, @WorkOrderId, @MachineIdLocal, 'Stage 1', GETDATE(), @AllocateQty, 0, 'In-Process');

            SET @RemainingQty = @RemainingQty - @AllocateQty;

            FETCH NEXT FROM MachineCursor
            INTO @MachineIdLocal,
                 @AvailableQty;

        END

        CLOSE MachineCursor;
        DEALLOCATE MachineCursor;


        IF @RemainingQty > 0
        BEGIN
            RAISERROR('Insufficient machine capacity. Remaining Qty not allocated.', 16, 1);
        END

    END

    --IF @SP_Action = 'StartProduction'
    --BEGIN

    --    DECLARE @RemainingQty FLOAT;
    --    DECLARE @MachineIdLocal INT;
    --    DECLARE @AvailableQty FLOAT;
    --    DECLARE @AllocateQty FLOAT;
    --    DECLARE @WorkOrderId INT;

    --    ---------------------------------------------------
    --    -- STEP 1: GET SAFE REMAINING QTY (NO NEGATIVE)
    --    ---------------------------------------------------
    --    SELECT
    --        @WorkOrderId = WorkOrderId,
    --        @RemainingQty =
    --            CASE 
    --                WHEN TotalQty - ISNULL((
    --                    SELECT SUM(PlannedQty)
    --                    FROM tbl_ProductionMachineLoading
    --                    WHERE ProductionPlanId = @Id
    --                      AND AllocatedStage = 'Stage 1'
    --                ), 0) < 0 
    --                THEN 0
    --                ELSE TotalQty - ISNULL((
    --                    SELECT SUM(PlannedQty)
    --                    FROM tbl_ProductionMachineLoading
    --                    WHERE ProductionPlanId = @Id
    --                      AND AllocatedStage = 'Stage 1'
    --                ), 0)
    --            END
    --    FROM tbl_ProductionInatial
    --    WHERE ID = @Id;

    --    ---------------------------------------------------
    --    -- STOP IF NOTHING LEFT
    --    ---------------------------------------------------
    --    IF @RemainingQty <= 0
    --        RETURN;

    --    ---------------------------------------------------
    --    -- STEP 2: MACHINE CURSOR (CORRECT CAPACITY CALC)
    --    ---------------------------------------------------
    --    DECLARE MachineCursor CURSOR FOR

    --    SELECT
    --        M.ID,

    --        (
    --            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
    --             TRY_CAST(M.MachineRunningHR AS FLOAT))
    --            -
    --            ISNULL(
    --                SUM(
    --                    CASE
    --                        WHEN PM.ProductionPlanId = @Id
    --                         AND PM.AllocatedStage = 'Stage 1'
    --                        THEN PM.PlannedQty
    --                        ELSE 0
    --                    END
    --                ), 0
    --            )
    --        ) AS AvailableQty

    --    FROM tbl_MachineMaster M

    --    LEFT JOIN tbl_ProductionMachineLoading PM
    --        ON M.ID = PM.MachineId

    --    WHERE M.IsDeleted = 0
    --      AND M.IsActive = 1
    --      AND M.AllocatedStage = 'Stage 1'

    --    GROUP BY
    --        M.ID,
    --        M.MachinePerHRQty,
    --        M.MachineRunningHR

    --    HAVING
    --        (
    --            (TRY_CAST(M.MachinePerHRQty AS FLOAT) *
    --             TRY_CAST(M.MachineRunningHR AS FLOAT))
    --            -
    --            ISNULL(
    --                SUM(
    --                    CASE
    --                        WHEN PM.ProductionPlanId = @Id
    --                         AND PM.AllocatedStage = 'Stage 1'
    --                        THEN PM.PlannedQty
    --                        ELSE 0
    --                    END
    --                ), 0
    --            )
    --        ) > 0

    --    ORDER BY M.ID;

    --    OPEN MachineCursor;

    --    FETCH NEXT FROM MachineCursor
    --    INTO @MachineIdLocal, @AvailableQty;

    --    ---------------------------------------------------
    --    -- STEP 3: ALLOCATION LOOP (NO OVERBOOKING)
    --    ---------------------------------------------------
    --    WHILE @@FETCH_STATUS = 0
    --          AND @RemainingQty > 0
    --    BEGIN

    --        ---------------------------------------------------
    --        -- STEP 3.1: REAL TIME CAPACITY CHECK
    --        ---------------------------------------------------
    --        DECLARE @MachineCapacity FLOAT;
    --        DECLARE @UsedQty FLOAT;
    --        DECLARE @FreeQty FLOAT;

    --        SELECT
    --            @MachineCapacity =
    --                TRY_CAST(MachinePerHRQty AS FLOAT) *
    --                TRY_CAST(MachineRunningHR AS FLOAT)
    --        FROM tbl_MachineMaster
    --        WHERE ID = @MachineIdLocal;

    --        SELECT
    --            @UsedQty = ISNULL(SUM(PlannedQty), 0)
    --        FROM tbl_ProductionMachineLoading
    --        WHERE MachineId = @MachineIdLocal
    --          AND ProductionPlanId = @Id
    --          AND AllocatedStage = 'Stage 1';

    --        SET @FreeQty = @MachineCapacity - @UsedQty;

    --        ---------------------------------------------------
    --        -- SKIP IF NO CAPACITY
    --        ---------------------------------------------------
    --        IF @FreeQty <= 0
    --        BEGIN
    --            FETCH NEXT FROM MachineCursor
    --            INTO @MachineIdLocal, @AvailableQty;

    --            CONTINUE;
    --        END

    --        ---------------------------------------------------
    --        -- STEP 3.2: SAFE ALLOCATION
    --        ---------------------------------------------------
    --        SET @AllocateQty =
    --            CASE
    --                WHEN @RemainingQty >= @FreeQty
    --                    THEN @FreeQty
    --                ELSE @RemainingQty
    --            END;

    --        ---------------------------------------------------
    --        -- STEP 4: INSERT ONLY SAFE VALUE
    --        ---------------------------------------------------
    --        INSERT INTO tbl_ProductionMachineLoading
    --        (
    --            ProductionPlanId,
    --            WorkOrderId,
    --            MachineId,
    --            AllocatedStage,
    --            ScheduleDate,
    --            PlannedQty,
    --            ProducedQty,
    --            Status
    --        )
    --        VALUES
    --        (
    --            @Id,
    --            @WorkOrderId,
    --            @MachineIdLocal,
    --            'Stage 1',
    --            GETDATE(),
    --            @AllocateQty,
    --            0,
    --            'In-Process'
    --        );

    --        ---------------------------------------------------
    --        -- STEP 5: UPDATE REMAINING
    --        ---------------------------------------------------
    --        SET @RemainingQty = @RemainingQty - @AllocateQty;

    --        ---------------------------------------------------
    --        -- NEXT MACHINE
    --        ---------------------------------------------------
    --        FETCH NEXT FROM MachineCursor
    --        INTO @MachineIdLocal, @AvailableQty;

    --    END

    --    CLOSE MachineCursor;
    --    DEALLOCATE MachineCursor;

    --    ---------------------------------------------------
    --    -- FINAL OUTPUT (NO NEGATIVE POSSIBLE)
    --    ---------------------------------------------------
    --    SELECT
    --        @Id AS ProductionPlanId,
    --        @RemainingQty AS PendingQty,
    --        'SAFE PRODUCTION COMPLETED (NO OVERBOOKING)' AS Message;

    --END

    IF @SP_Action = 'GetReceivedWO'
    Begin
        --     WITH WorkOrders AS
        --(
        --    SELECT *
        --    FROM tbl_ProductionInatial
        --    WHERE WorkOrderNo LIKE
        --    CASE
        --        WHEN ISNULL(@WorkOrderNo,'') <> ''
        --            THEN @WorkOrderNo
        --        ELSE '%'
        --    END
        --),
        --NUMBERED AS
        --(
        --    SELECT *,
        --           ROW_NUMBER() OVER(ORDER BY ID DESC) AS RN
        --    FROM WorkOrders
        --),
        --Loading AS
        --(
        --    SELECT
        --        ProductionPlanId,
        --        SUM(PlannedQty) AS ScheduledQty
        --    FROM tbl_ProductionMachineLoading
        --    GROUP BY ProductionPlanId
        --)

        --SELECT
        --    N.*,
        --    ISNULL(L.ScheduledQty,0) AS ScheduledQty,
        --    N.TotalQty - ISNULL(L.ScheduledQty,0) AS PendingQty
        --FROM NUMBERED N
        --LEFT JOIN Loading L
        --    ON L.ProductionPlanId = N.ID
        --WHERE @ShowRecords = 0
        --   OR N.RN <= @ShowRecords
        --ORDER BY N.ID DESC;



        --WITH WorkOrders AS
        --(
        --    SELECT *
        --    FROM tbl_ProductionInatial
        --    WHERE WorkOrderNo LIKE
        --        CASE
        --            WHEN ISNULL(@WorkOrderNo,'') <> ''
        --                THEN @WorkOrderNo
        --            ELSE '%'
        --        END
        --),

        --NUMBERED AS
        --(
        --    SELECT *,
        --           ROW_NUMBER() OVER(ORDER BY ID DESC) AS RN
        --    FROM WorkOrders
        --),

        ---- ✅ TOTAL per WorkOrder (FIX)
        --Loading AS
        --(
        --    SELECT
        --        ProductionPlanId,
        --        SUM(PlannedQty) AS ScheduledQty,
        --        MIN(ScheduleDate) AS FirstScheduleDate,
        --        MAX(ScheduleDate) AS LastScheduleDate
        --    FROM tbl_ProductionMachineLoading
        --    GROUP BY ProductionPlanId
        --)

        --SELECT
        --    N.ID,
        --    N.WorkOrderNo,
        --    N.Size,
        --    CAST(CAST(N.TotalQty AS FLOAT) AS INT) AS TotalQty,
        --CAST(CAST(ISNULL(L.ScheduledQty,0) AS FLOAT) AS INT) AS ScheduledQty,
        --CAST(
        --    CAST(N.TotalQty AS FLOAT)
        --    - CAST(ISNULL(L.ScheduledQty,0) AS FLOAT)
        --AS INT) AS PendingQty,
        --   CONVERT(VARCHAR(19), L.FirstScheduleDate, 120) AS FirstScheduleDateTime,
        --    CONVERT(VARCHAR(19), L.LastScheduleDate, 120) AS LastScheduleDateTime,

        --    CASE
        --        WHEN ISNULL(L.ScheduledQty,0) = 0 THEN 'Not Scheduled'
        --        WHEN ISNULL(L.ScheduledQty,0) < N.TotalQty THEN 'Partially Scheduled'
        --        ELSE 'Fully Scheduled'
        --    END AS ProductionStatus,

        --    CASE
        --        WHEN L.LastScheduleDate IS NULL THEN NULL
        --        WHEN CONVERT(date, L.LastScheduleDate) = CONVERT(date, GETDATE())
        --            THEN 'Scheduled Today'
        --        ELSE 'Scheduled'
        --    END AS ScheduleStatus

        --FROM NUMBERED N
        --LEFT JOIN Loading L
        --    ON L.ProductionPlanId = N.ID

        --WHERE @ShowRecords = 0
        --   OR N.RN <= @ShowRecords

        --ORDER BY N.ID DESC;


        WITH WorkOrders
        AS (SELECT *
            FROM tbl_ProductionInatial
            --WHERE WorkOrderNo LIKE CASE
            --                           WHEN ISNULL(@WorkOrderNo, '') <> '' THEN
            --                               @WorkOrderNo
            --                           ELSE
            --                               '%'
            --                       END
           ),
             NUMBERED
        AS (SELECT *,
                   ROW_NUMBER() OVER (ORDER BY ID DESC) AS RN
            FROM WorkOrders
           ),

             -- ?? SAFE STAGE AGGREGATION
             LoadingBase
        AS (SELECT l.ProductionPlanId,
                   l.AllocatedStage,
                   SUM(TRY_CAST(l.PlannedQty AS FLOAT)) AS ScheduledQty,
                   SUM(TRY_CAST(l.ProducedQty AS FLOAT)) AS ProducedQty,
                   MIN(l.ScheduleDate) AS FirstScheduleDateTime,
                   MAX(l.ScheduleDate) AS LastScheduleDateTime
            FROM tbl_ProductionMachineLoading l
            GROUP BY l.ProductionPlanId,
                     l.AllocatedStage
           ),

             -- ?? SAP STAGE COMPLETION FLAG
             StageStatus
        AS (SELECT *,
                   CASE
                       WHEN ISNULL(ProducedQty, 0) >= ISNULL(ScheduledQty, 0) THEN
                           1
                       ELSE
                           0
                   END AS IsCompleted
            FROM LoadingBase
           ),
             DailyLoad
        AS (SELECT CONVERT(DATE, ScheduleDate) AS ScheduleDay,
                   SUM(TRY_CAST(PlannedQty AS FLOAT)) AS UsedQty,
                   COUNT(*) AS JobCount
            FROM tbl_ProductionMachineLoading
            GROUP BY CONVERT(DATE, ScheduleDate)
           ),
             Capacity
        AS (SELECT SUM(TRY_CAST(MachinePerHRQty AS FLOAT) * TRY_CAST(MachineRunningHR AS FLOAT)) AS DailyCapacity
            FROM tbl_MachineMaster
            WHERE IsActive = 1
                  AND IsDeleted = 0
           ),
             AvailableDays
        AS (SELECT C.WorkDay,
                   ISNULL(D.UsedQty, 0) AS UsedQty,
                   CAP.DailyCapacity,
                   (CAP.DailyCapacity - ISNULL(D.UsedQty, 0)) AS AvailableQty
            FROM
            (
                SELECT TOP 60
                    DATEADD(DAY, ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) - 1, CAST(GETDATE() AS DATE)) AS WorkDay
                FROM master..spt_values
            ) C
                CROSS JOIN Capacity CAP
                LEFT JOIN DailyLoad D
                    ON D.ScheduleDay = C.WorkDay
           ),
             NextAvailable
        AS (SELECT TOP 1
                WorkDay
            FROM AvailableDays
            WHERE AvailableQty > 0
                  AND WorkDay >= DATEADD(DAY, 1, CAST(GETDATE() AS DATE))
            ORDER BY WorkDay ASC
           )
        SELECT N.ID,
               N.WorkOrderNo,
               N.Size,

               -- ?? FIX: SAFE NUMERIC CONVERSION
               CAST(TRY_CAST(N.TotalQty AS FLOAT) AS INT) AS TotalQty,
               S.AllocatedStage AS Stage,
               CAST(ISNULL(S.ScheduledQty, 0) AS INT) AS ScheduledQty,

               -- ?? SAP DEPENDENCY CONTROLLED PRODUCED QTY
               CAST(CASE
                        WHEN S.AllocatedStage = 'Stage 1' THEN
                            ISNULL(S.ProducedQty, 0)
                        WHEN S.AllocatedStage = 'Stage 2'
                             AND EXISTS
    (
        SELECT 1
        FROM StageStatus S1
        WHERE S1.ProductionPlanId = S.ProductionPlanId
              AND S1.AllocatedStage = 'Stage 1'
              AND S1.IsCompleted = 1
    )          THEN
                            ISNULL(S.ProducedQty, 0)
                        ELSE
                            0
                    END AS INT) AS ProducedQty,

               -- ?? FIX: SAFE CALCULATION (NO NVARCHAR ERROR)
               CAST(TRY_CAST(N.TotalQty AS FLOAT) - ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID), 0) AS INT) AS PendingQty,
               CONVERT(VARCHAR(19), S.FirstScheduleDateTime, 120) AS FirstScheduleDateTime,
               CONVERT(VARCHAR(19), S.LastScheduleDateTime, 120) AS LastScheduleDateTime,
               DL.ScheduleDay,
               DL.UsedQty,
               DL.JobCount,

               -- ?? AUTO SCHEDULE DATE
               CASE
                   WHEN ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID), 0) = 0 THEN
                       CONVERT(VARCHAR(19), NA.WorkDay, 120)
                   WHEN ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID), 0) < TRY_CAST(N.TotalQty AS FLOAT) THEN
                       CONVERT(VARCHAR(19), NA.WorkDay, 120)
                   ELSE
                       CONVERT(VARCHAR(19), S.LastScheduleDateTime, 120)
               END AS AutoScheduleDate,

               -- ?? PRODUCTION STATUS
               CASE
                   WHEN ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID), 0) = 0 THEN
                       'Not Scheduled'
                   WHEN ISNULL(SUM(S.ScheduledQty) OVER (PARTITION BY N.ID), 0) < TRY_CAST(N.TotalQty AS FLOAT) THEN
                       'Partially Scheduled'
                   ELSE
                       'Fully Scheduled'
               END AS ProductionStatus,

               -- ?? SCHEDULE STATUS
               CASE
                   WHEN S.LastScheduleDateTime IS NULL THEN
                       NULL
                   WHEN CONVERT(DATE, S.LastScheduleDateTime) = CONVERT(DATE, GETDATE()) THEN
                       'Scheduled Today'
                   ELSE
                       'Scheduled'
               END AS ScheduleStatus
        FROM NUMBERED N
            LEFT JOIN StageStatus S
                ON S.ProductionPlanId = N.ID
            OUTER APPLY
        (SELECT TOP 1 * FROM DailyLoad DL2 ORDER BY DL2.ScheduleDay DESC) DL
            CROSS APPLY NextAvailable NA
        WHERE @ShowRecords = 0
              OR N.RN <= @ShowRecords
        ORDER BY N.ID DESC;

    END

    IF @SP_Action = 'StartProduction_Stage2'
    BEGIN

        DECLARE @CurrentStage NVARCHAR(50) = 'Stage 2';

        DECLARE @MachineIdLocall INT;
        DECLARE @AvailableQtyy FLOAT;
        DECLARE @AllocateQtyy FLOAT;

        DECLARE @ProdId INT;


        ---------------------------------------------------
        -- STEP 1: WORK ORDER FIFO QUEUE
        ---------------------------------------------------
        DECLARE @WorkQueue TABLE
        (
            RowNum INT IDENTITY(1, 1),
            ProductionId INT,
            WorkOrderId INT,
            RemainingQty FLOAT
        );

        INSERT INTO @WorkQueue
        (
            ProductionId,
            WorkOrderId,
            RemainingQty
        )
        SELECT PI.ID,
               PI.WorkOrderId,
               ISNULL(
               (
                   SELECT SUM(PlannedQty)
                   FROM tbl_ProductionMachineLoading
                   WHERE ProductionPlanId = PI.ID
                         AND AllocatedStage = 'Stage 1'
                         AND PlannedQty > 0
               ),
               0
                     )
        FROM tbl_ProductionInatial PI
        WHERE PI.ID = @Id;

        ---------------------------------------------------
        -- STEP 2: MACHINE CURSOR
        ---------------------------------------------------
        DECLARE TransferCursor CURSOR FOR
        SELECT M.ID,
               ((TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT))
                - ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)), 0)
               ) AS AvailableQty
        FROM tbl_MachineMaster M
            LEFT JOIN tbl_ProductionMachineLoading PM
                ON M.ID = PM.MachineId
                   AND PM.Status = 'In-Process'
                   AND PM.AllocatedStage = @CurrentStage
        WHERE M.IsDeleted = 0
              AND M.IsActive = 1
              AND M.AllocatedStage = @CurrentStage
        GROUP BY M.ID,
                 M.MachinePerHRQty,
                 M.MachineRunningHR
        HAVING ((TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT))
                - ISNULL(SUM(TRY_CAST(PM.PlannedQty AS FLOAT)), 0)
               ) > 0
        ORDER BY M.ID;

        OPEN TransferCursor;

        FETCH NEXT FROM TransferCursor
        INTO @MachineIdLocall,
             @AvailableQtyy;

        ---------------------------------------------------
        -- STEP 3: LOOP WORK ORDERS
        ---------------------------------------------------
        DECLARE @i INT = 1;
        DECLARE @Max INT;

        SELECT @Max = COUNT(*)
        FROM @WorkQueue;

        WHILE @@FETCH_STATUS = 0 AND @i <= @Max
        BEGIN

            SELECT @ProdId = ProductionId,
                   @WorkOrderId = WorkOrderId,
                   @RemainingQty = RemainingQty
            FROM @WorkQueue
            WHERE RowNum = @i;

            ---------------------------------------------------
            -- SKIP IF NO QTY
            ---------------------------------------------------
            IF @RemainingQty <= 0
            BEGIN
                SET @i = @i + 1;
                CONTINUE;
            END

            ---------------------------------------------------
            -- STEP 4: MACHINE ALLOCATION LOOP
            ---------------------------------------------------
            WHILE @RemainingQty > 0 AND @@FETCH_STATUS = 0
            BEGIN

                ---------------------------------------------------
                -- TAKE MIN OF MACHINE CAPACITY & REMAINING QTY
                ---------------------------------------------------
                SET @AllocateQtyy = CASE
                                        WHEN @RemainingQty >= @AvailableQtyy THEN
                                            @AvailableQtyy
                                        ELSE
                                            @RemainingQty
                                    END;

                ---------------------------------------------------
                -- DEDUCT FROM STAGE 1 FIFO
                ---------------------------------------------------




                ;
                WITH Stage1
                AS (SELECT TOP 1
                        Id,
                        PlannedQty
                    FROM tbl_ProductionMachineLoading
                    WHERE ProductionPlanId = @ProdId
                          AND AllocatedStage = 'Stage 1'
                          AND PlannedQty > 0
                    ORDER BY Id
                   )
                UPDATE Stage1
                SET PlannedQty = PlannedQty - @AllocateQtyy;

                ---------------------------------------------------
                -- INSERT STAGE 2 ALLOCATION
                ---------------------------------------------------
                INSERT INTO tbl_ProductionMachineLoading
                (
                    ProductionPlanId,
                    WorkOrderId,
                    MachineId,
                    AllocatedStage,
                    ScheduleDate,
                    PlannedQty,
                    ProducedQty,
                    Status
                )
                VALUES
                (@ProdId, @WorkOrderId, @MachineIdLocall, @CurrentStage, GETDATE(), @AllocateQtyy, 0, 'In-Process');

                ---------------------------------------------------
                -- UPDATE REMAINING WORK ORDER QTY
                ---------------------------------------------------
                SET @RemainingQty = @RemainingQty - @AllocateQtyy;

                ---------------------------------------------------
                -- MOVE TO NEXT MACHINE IF CURRENT IS FULL
                ---------------------------------------------------
                IF @AllocateQtyy = @AvailableQtyy
                BEGIN
                    FETCH NEXT FROM TransferCursor
                    INTO @MachineIdLocall,
                         @AvailableQtyy;

                    IF @@FETCH_STATUS <> 0
                        BREAK;
                END

            END

            SET @i = @i + 1;

        END

        CLOSE TransferCursor;
        DEALLOCATE TransferCursor;

        ---------------------------------------------------
        -- FINAL OUTPUT
        ---------------------------------------------------
        SELECT @Id AS ProductionPlanId,
               'Stage 2 allocation completed successfully with proper machine chaining' AS Message;

    END

    IF @SP_Action = 'productionwo'
    BEGIN
        SELECT 
            hdr.ID,
            hdr.SeriesNo,
            hdr.TallyRefNo as WorkOrderNo,
            hdr.RankNo,
            hdr.Dealer,

        STUFF((
            SELECT 
                ''
       

                + 'ProductName = ' + ISNULL(dt.ProductName,'') + ' ,'
                + 'PartNo = ' + ISNULL(dt.PartNo,'') + ' ,'
                + 'Description = ' + ISNULL(dt.Description,'') + ', '
                + 'Size = ' + ISNULL(dt.Size,'') + ' '
                + 'Qty = ' + CAST(dt.Qty AS VARCHAR(50)) + ', '
                + 'Unit = ' + ISNULL(dt.Unit,'') + ', '

      
            FROM tbl_WorkOrderDetails dt
            WHERE dt.HeaderID = hdr.ID
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 0, '') AS Details

        FROM tbl_WorkOrderHdr hdr
        WHERE hdr.IsDeleted = 0
          AND hdr.isdesignapproved = 1
        ORDER BY RankNo ASC
    END




    --Below Actions by Nikhil  

    IF @SP_Action = 'ProductionSchedular'
    BEGIN
      WITH WorkOrder AS(
          SELECT ID,TallyRefNo as WorkOrderNo,Dealer,CustomerName,CONVERT(nvarchar(10),WorkOrderDate,105) as WorkOrderDate,RankNo
          FROM tbl_WorkOrderHdr 
          WHERE IsDeleted = 0
             AND isdesignapproved = 1
      ),NUMBERED AS(
        SELECT *,ROW_NUMBER() OVER(ORDER BY  CASE WHEN RankNo IS NULL THEN 1 ELSE 0 END, RankNo ASC) AS RN
        FROM WorkOrder
      )
      SELECT * FROM NUMBERED
          WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
      ORDER BY CASE WHEN RankNo IS NULL THEN 1 ELSE 0 END,RankNo ASC
    END

    IF @SP_Action = 'ScheduledWorkOrder'
      BEGIN
         WITH WorkOrder AS(
           SELECT WH.RankNo as RankNo,WH.ID as ID, WH.TallyRefNo as WorkOrderNo,CONVERT(nvarchar(10),WH.WorkOrderDate,105) as WorkOrderDate,
            COUNT(WD.Id) as ProductCount,SUM(CAST(WD.Qty as decimal)) AS Qty, 
            SUM(CAST(ISNULL(WD.SqFeet, 0) AS decimal)) AS SqFeet,
            ISNULL(MAX(SP.WOStatus),'Pending') as WOStatus
            FROM tbl_WorkOrderDetails WD
            LEFT JOIN tbl_WorkOrderHdr WH ON WH.ID = WD.HeaderID
            LEFT JOIN (
                        SELECT WOHeaderId,
                               MAX(WOStatus) AS WOStatus
                        FROM tbl_Stage1Production
                        GROUP BY WOHeaderId
                    ) SP ON SP.WOHeaderId = WD.HeaderID
             WHERE IsDeleted = 0 AND isdesignapproved = 1 AND RankNo IS NOT NULL
            GROUP BY WH.RankNo,WH.ID, WH.TallyRefNo ,CONVERT(nvarchar(10),WH.WorkOrderDate,105) 
          ),NUMBERED AS(
            SELECT *,ROW_NUMBER() OVER(ORDER BY  CASE WHEN RankNo IS NULL THEN 1 ELSE 0 END, RankNo ASC) AS RN
            FROM WorkOrder
          )
          SELECT * FROM NUMBERED
              WHERE @ShowRecords = 0
			    OR RN <= @ShowRecords
          ORDER BY CASE WHEN RankNo IS NULL THEN 1 ELSE 0 END,RankNo ASC
      END

    IF @SP_Action = 'AssignWorkOrders'
      BEGIN
        WITH WorkOrder AS (
           SELECT WH.RankNo as RankNo,
               WH.ID as ID,
               WH.TallyRefNo as WorkOrderNo,
               CONVERT(nvarchar(10), WH.WorkOrderDate, 105) as WorkOrderDate,
               COUNT(WD.Id) as ProductCount,
               SUM(CAST(WD.Qty as decimal)) AS Qty,
               SUM(CAST(ISNULL(WD.SqFeet, 0) AS DECIMAL(18, 2))) AS SqFeet,
               ISNULL(MAX(SP.WOStatus), 'Pending') as WOStatus
        FROM tbl_WorkOrderDetails WD
            LEFT JOIN tbl_WorkOrderHdr WH
                ON WH.ID = WD.HeaderID
            LEFT JOIN
            (
                SELECT WOHeaderId,
                       MAX(WOStatus) AS WOStatus
                FROM tbl_Stage1Production
                GROUP BY WOHeaderId
            ) SP
                ON SP.WOHeaderId = WD.HeaderID
        WHERE IsDeleted = 0
              AND isdesignapproved = 1
              AND RankNo IS NOT NULL
        GROUP BY WH.RankNo,
                 WH.ID,
                 WH.TallyRefNo,
                 CONVERT(nvarchar(10), WH.WorkOrderDate, 105)
       ),
         NUMBERED
    AS (SELECT *,
               ROW_NUMBER() OVER (ORDER BY CASE WHEN RankNo IS NULL THEN 1 ELSE 0 END, RankNo ASC) AS RN
        FROM WorkOrder
       )
    SELECT *
    FROM NUMBERED
    WHERE @ShowRecords = 0
          OR RN <= @ShowRecords
    ORDER BY CASE
                 WHEN RankNo IS NULL THEN
                     1
                 ELSE
                     0
             END,
             RankNo ASC
      END

    --IF @SP_Action ='InsertWOToProd' 
    -- BEGIN
    --    INSERT INTO tbl_Stage1Production(MachineID,WOHeaderId,ProductName,PartNo,Size,ReceivedQty,ReceivedDate,WOStatus,sheduledate)
    --    VALUES(@MachineID,@WOHeaderId,@ProductName,@PartNo,@Size,@ReceivedQty,GETDATE(),'In-Process', @sheduledate)
    -- END

    --IF @SP_Action = 'S1CompletedQty'
    --  BEGIN

    --        DECLARE @S1ID INT,
    --                @S2ID INT,
    --                @S2MCID INT;

    --        SET @S1ID = @Id;

    --        --------------------------------------------------
    --        -- Update Stage 1
    --        --------------------------------------------------
    --        --UPDATE tbl_Stage1Production
    --        --SET CompletedQty = CAST(ISNULL(CompletedQty,0) as decimal) + CAST(ISNULL(@ReceivedQty,0) as decimal),
    --        --    CompletedDate = GETDATE()
    --        --WHERE ID = @S1ID;

    --        --------------------------------------------------
    --        -- Check if record already exists in Stage 2
    --        --------------------------------------------------
    --        SELECT @S2ID = ID
    --        FROM tbl_Stage2Production
    --        WHERE Stage1HeaderId = @S1ID;

    --        IF @S2ID IS NOT NULL
    --        BEGIN
    --            UPDATE tbl_Stage2Production
    --            SET CompletedQty = CAST(ISNULL(CompletedQty,0) as decimal)  + CAST(ISNULL(@ReceivedQty,0) as decimal) ,
    --                CompletedDate = GETDATE()
    --            WHERE ID = @S2ID;
    --        END
    --        ELSE
    --        BEGIN

    --            --------------------------------------------------
    --            -- Find Available Stage 2 Machine
    --            --------------------------------------------------
    --            ;WITH Stage2Machine AS
    --            (
    --                SELECT
    --                    M.ID AS MachineID,
    --                    (
    --                        (TRY_CAST(M.MachinePerHRQty AS FLOAT)
    --                        * TRY_CAST(M.MachineRunningHR AS FLOAT))
    --                        -
    --                        ISNULL(SUM(TRY_CAST(PM.ReceivedQty AS FLOAT)),0)
    --                    ) AS MachineAvailable
    --                FROM tbl_MachineMaster M
    --                LEFT JOIN tbl_Stage2Production PM
    --                    ON PM.MachineId = M.ID
    --                WHERE M.IsDeleted = 0
    --                  AND M.IsActive = 1
    --                  AND M.AllocatedStage = 'Stage 2'
    --                GROUP BY
    --                    M.ID,
    --                    M.MachinePerHRQty,
    --                    M.MachineRunningHR
    --            )
    --            SELECT TOP 1
    --                @S2MCID = MachineID
    --            FROM Stage2Machine
    --            WHERE MachineAvailable > 0
    --            ORDER BY MachineAvailable DESC;

    --            --------------------------------------------------
    --            -- Insert New Stage 2 Record
    --            --------------------------------------------------
    --            INSERT INTO tbl_Stage2Production
    --            (
    --                Stage1HeaderId,
    --                MachineId,
    --                WOHeaderId,
    --                ProductName,
    --                PartNo,
    --                Size,
    --                ReceivedQty,
    --                ReceivedDate,
    --                WOStatus
    --            )
    --            SELECT
    --                S1.ID,
    --                @S2MCID,
    --                S1.WOHeaderId,
    --                S1.ProductName,
    --                S1.PartNo,
    --                S1.Size,
    --                @ReceivedQty,
    --                GETDATE(),
    --                S1.WOStatus
    --            FROM tbl_Stage1Production S1
    --            WHERE S1.ID = @S1ID;

    --    END
    --END

    --IF @SP_Action ='S1RejectedQty' 
    -- BEGIN
    --    UPDATE tbl_Stage1Production SET RejectedQty=ISNULL(CAST(RejectedQty as decimal), 0) + ISNULL(CAST(@ReceivedQty as decimal),0)  WHERE ID=@Id
    -- END
END







-- Script for SP_AssignedMachines
GO
CREATE PROCEDURE dbo.SP_AssignedMachines
 @ShowRecords int =0
,@Id int =0
,@MachineID nvarchar(100)= null
,@OperatorID nvarchar(100)= null
,@FromDate date= null
,@ToDate date= null
,@FromTime time(0)= null
,@ToTime time(0)= null
,@ActionBy nvarchar(100)= null
,@SP_Action nvarchar(100)= null
AS
BEGIN
    IF @SP_Action ='GetList'
     BEGIN
        SELECT AM.ID AS ID,(MM.AllocatedStage+'- '+MM.MachineName )AS MachineID, UM.FullName AS OperatorID,
        CONVERT(nvarchar(10),AM.FromDate,105) AS FromDate,CONVERT(nvarchar(10),AM.ToDate,105) AS ToDate,
        LTRIM(RIGHT(CONVERT(varchar, CAST(FromTime AS datetime), 100), 7))  AS FromTime, 
         LTRIM(RIGHT(CONVERT(varchar, CAST(ToTime AS datetime), 100), 7)) AS ToTime
        FROM tbl_AssignedMachines AM
        INNER JOIN tbl_MachineMaster MM ON MM.ID = AM.MachineID
        INNER JOIN tbl_UserMaster UM ON UM.ID = AM.OperatorID 
        WHERE AM.IsDeleted = 0
     END

    IF @SP_Action ='InsertMachine'
     BEGIN
       INSERT INTO tbl_AssignedMachines(MachineID,OperatorID,FromDate,ToDate,FromTime,ToTime,CreatedBy,CreatedOn,IsDeleted)
       VALUES (@MachineID,@OperatorID,@FromDate,@ToDate,@FromTime,@ToTime,@ActionBy,GETDATE(),0)
     END

    IF @SP_Action ='DeleteAssiMachine'
     BEGIN
       UPDATE tbl_AssignedMachines SET IsDeleted = 1,DeletedBy = @ActionBy,DeletedOn=GETDATE() WHERE ID = @Id
     END

    IF @SP_Action = 'CheckMCAvailability'
     BEGIN
       SELECT ID,CONVERT(nvarchar(10),ToDate,105) AS ToDate
       ,LTRIM(RIGHT(CONVERT(varchar, CAST(ToTime AS datetime), 100), 7)) AS ToTime
       FROM tbl_AssignedMachines WHERE IsDeleted = 0 AND MachineID = @MachineID AND CAST(ToDate AS datetime) + CAST(ToTime AS datetime) > GETDATE()
     END

     IF @SP_Action = 'CheckOPAvailability'
     BEGIN
       SELECT ID,CONVERT(nvarchar(10),ToDate,105) AS ToDate
       ,LTRIM(RIGHT(CONVERT(varchar, CAST(ToTime AS datetime), 100), 7)) AS ToTime
       FROM tbl_AssignedMachines WHERE OperatorID = @OperatorID AND CAST(ToDate AS datetime) + CAST(ToTime AS datetime) > GETDATE()
     END

END



					













-- Script for SP_AUTH_TOKEN_MASTER
GO
CREATE PROCEDURE [dbo].[SP_AUTH_TOKEN_MASTER]
    @UserName NVARCHAR(MAX)=NULL,
    @AuthToken NVARCHAR(MAX) = NULL,
    @TokenExpiry DATETIME = NULL,
    @Sek NVARCHAR(MAX) = NULL,
    @ClientId NVARCHAR(MAX) = NULL,
    @Action NVARCHAR(50) 
AS
BEGIN
    SET NOCOUNT ON;

    IF @Action = 'GetToken'
    BEGIN
        SELECT UserName, AuthToken As AuthKey, CONVERT(NVARCHAR, TokenExpiry, 120) AS TokenExpiry, Sek, ClientId
        FROM AUTH_TOKEN_MASTER
        WHERE UserName = @UserName
    END

   IF @Action = 'UpsertToken'
    BEGIN
            INSERT INTO AUTH_TOKEN_MASTER(UserName, AuthToken, TokenExpiry, Sek, ClientId)
            VALUES(@UserName, @AuthToken, @TokenExpiry, @Sek, @ClientId);
    END

   IF @Action = 'DeleteOldToken'
   BEGIN
    DELETE AUTH_TOKEN_MASTER
   END
END

-- Script for SP_WorkOrderMaster
GO

CREATE PROCEDURE [dbo].[SP_WorkOrderMaster]
(   @ShowRecords int =0,
    @Id int  = 0,
    @TallyRefNo NVARCHAR(20) = Null ,
	@WorkOrderNo Nvarchar(200) = Null,
    @WorkOrderDate  datetime = Null,
    @Dealer NVARCHAR(200) = Null,
    @CustomerName NVARCHAR(500) = Null,
    @CustomerRefNo NVARCHAR(100) = Null,
    @BillingGstNo Nvarchar(200) = Null,
    @BillingAddress NVARCHAR(max) = Null,
    @BillingPincode NVARCHAR(100) = Null,
    @ShippingGstNo Nvarchar(200) = Null,
    @ShippingAddress nvarchar(max) = null,
    @ShippingPincode nvarchar(100) = null,
    @DeliveryDate datetime = null,
	@AttachmentPath nvarchar(max) = null,
    @ActionBy nvarchar(100) = null,
  
    -- DETAIL PARAMETERS
    @ProductId nvarchar(100) = NULL,
	@HeaderID nvarchar(200) = null,
    @ProductName NVARCHAR(500) = NULL,
	@SqFeet NVARCHAR(100) = NULL,
	@UploadedImage NVARCHAR(500) = NULL,
    @PartNo NVARCHAR(300) = NULL,
	@Type NVARCHAR(300) = NULL,
    @Description NVARCHAR(max) = NULL,
    @Size NVARCHAR(50) = NULL,
    @Qty NVARCHAR(50) = NULL,
    @Unit NVARCHAR(20) = NULL,

    @SP_Action NVARCHAR(20) = Null,
    @Result int output
)
AS
BEGIN
      -- HDR Table
  	  IF @SP_Action = 'WoHdrList'
	   BEGIN
		 WITH WorkOrderMaster
			AS (
			    SELECT ID,TallyRefNo,CONVERT(nvarchar(10),WorkOrderDate,105) AS WorkOrderDate,Dealer,CustomerName,isdesignapproved,AttachmentPath
				FROM tbl_WorkOrderHdr WHERE IsDeleted = 0  
			       AND (
				        @Dealer = ''
                       OR TallyRefNo LIKE '%'+ @Dealer + '%'
					   OR Dealer LIKE '%'+ @Dealer + '%'
					   OR CustomerName LIKE '%'+ @Dealer + '%'
						--Dealer LIKE CASE 
						--	WHEN @Dealer != ''
						--		THEN @Dealer
						--	ELSE '%%'
						--	END
			          )
			   ),NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY Id DESC
					) AS RN
			FROM WorkOrderMaster
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
		ORDER BY ID DESC
		 SET @Result = 0
	   END

	  IF @SP_Action = 'WoHdrListById'
	   BEGIN
		  SELECT * FROM tbl_WorkOrderHdr WHERE ID = @Id
		  SET @Result = @Id
	   END
	 
	  IF @SP_Action = 'InsertWoHdr'
	   BEGIN
	     INSERT INTO tbl_WorkOrderHdr (
			 SeriesNo
			,TallyRefNo
			,WorkOrderDate
			,Dealer
			,CustomerName
			,CustomerRefNo
			,BillingGstNo
			,BillingAddress
			,BillingPincode
			,ShippingGstNo
			,ShippingAddress
			,ShippingPincode
			,DeliveryDate
			,CreatedBy
			,CreatedOn
			,IsDeleted
			,IsDispatched
			,isproductioncompleted
			,AttachmentPath
			)
		VALUES (
			[dbo].[FN_WorkOrderNo]()
			,@TallyRefNo
			,@WorkOrderDate
			,@Dealer
			,@CustomerName
			,@CustomerRefNo
			,@BillingGstNo
			,@BillingAddress
			,@BillingPincode
			,@ShippingGstNo
			,@ShippingAddress
			,@ShippingPincode
			,@DeliveryDate
			,@ActionBy
			,GETDATE()
			,0
			,0
			,0
			,@AttachmentPath
			)
        SET @Result = SCOPE_IDENTITY()
	   END

      IF @SP_Action = 'UpdateWoHdr'
	   BEGIN
	    UPDATE tbl_WorkOrderHdr
		SET TallyRefNo =@TallyRefNo
			,WorkOrderDate = @WorkOrderDate
			,Dealer = @Dealer
			,CustomerName = @CustomerName
			,CustomerRefNo = @CustomerRefNo
			,BillingGstNo = @BillingGstNo
			,BillingAddress = @BillingAddress
			,BillingPincode = @BillingPincode
			,ShippingGstNo = @ShippingGstNo
			,ShippingAddress = @ShippingAddress
			,ShippingPincode = @ShippingPincode
			,DeliveryDate = @DeliveryDate
			,UpdatedOn =GETDATE()
			,UpdatedBy = @ActionBy
			,AttachmentPath= @AttachmentPath
		WHERE ID = @Id
		SET @Result = @Id
	   END

      IF (@SP_Action = 'DeleteWoHdr')
		BEGIN
			UPDATE tbl_WorkOrderHdr
			SET IsDeleted = 1
			WHERE ID = @Id
			SET @Result = @Id
		END

     -- DTLS Table
      IF @SP_Action = 'WODTLSListById'
	   BEGIN
	     SELECT * FROM tbl_WorkOrderDetails WHERE HeaderID=@Id
		 SET @Result = @Id
 	   END 
     
      IF @SP_Action = 'InsertWODTLS'
	   BEGIN
	     INSERT INTO tbl_WorkOrderDetails (
			 HeaderID
			,ProductId
			,ProductName
			,PartNo
			,Description
			,Size
			,Unit
			,Qty
			,SqFeet
			,UploadedImage
			,Type
			)
		VALUES (
			 @HeaderId
            ,@ProductId
			,@ProductName
			,@PartNo
			,@Description
			,@Size
			,@Unit
			,@Qty
			,@SqFeet
			,@UploadedImage
			,@Type
			)
			 SET @Result = SCOPE_IDENTITY()
	   END
      
	  IF (@SP_Action = 'DeleteWODTLS')
		BEGIN
			DELETE tbl_WorkOrderDetails WHERE HeaderID = @Id
			SET @Result = @Id
		END

     --W/O For Production
	  IF (@SP_Action = 'SendForProduction')
	 BEGIN
			INSERT INTO tbl_ProductionInatial
			(
				WorkOrderId,
				WorkOrderNo,
				TotalQty,
				Size
			)
			SELECT
				hdr.ID,
				hdr.TallyRefNo,
				SUM(CAST(dtls.Qty as decimal)) AS Qty,
				dtls.Size
			FROM tbl_WorkOrderDetails dtls
			INNER JOIN tbl_WorkOrderHdr hdr
				ON hdr.ID = dtls.HeaderID
			WHERE hdr.ID = @Id
			GROUP BY
				hdr.ID,
				hdr.TallyRefNo,
				dtls.Size;

      SET @Result = @Id
	END

	  IF (@SP_Action ='approveworkorder')
	  BEGIN
	    update tbl_WorkOrderHdr set isdesignapproved = 1 where ID=@Id
	  END
		
	  IF (@SP_Action ='DisApprove')
	  BEGIN
	    update tbl_WorkOrderHdr set isdesignapproved = 0 where ID=@Id
	  END

	  IF (@SP_Action = 'PlaceorderHDR')
	   BEGIN 
	     INSERT INTO tbl_DealersOrderHDR(OrderID,DealerID,CreatedDate,OrderStatus)
		 VALUES ('ORD' + RIGHT('000000' + CAST(NEXT VALUE FOR dbo.OrderSequence AS VARCHAR(6)), 6),@Dealer,GETDATE(),'Order Placed');
		 SET @Result = SCOPE_IDENTITY();
	   END

       IF (@SP_Action = 'PlaceorderDtls')
	   BEGIN 
	     INSERT INTO tbl_DealersOrderDTLs(HeaderID,ProductID,ProductName,ProductType,Size,Qty,ProductNote,ImagePathName)
		 VALUES (@HeaderID,@ProductId,@ProductName,@Type,@Size,@Qty,@Description,@UploadedImage);
		 SET @Result = SCOPE_IDENTITY();
	   END 
END

-- Script for SP_ProductionsPlanning
GO
CREATE PROCEDURE [dbo].[SP_ProductionsPlanning]
    @ShowRecords INT = 0,
    @Id INT = 0,
    @MachineID  NVARCHAR(200) = null,
    @Qty NVARCHAR(200) = null,
    @WOHeaderId NVARCHAR(100)= null,
    @ProductName NVARCHAR(500)= null,
    @PartNo NVARCHAR(100)= null,
    @Size NVARCHAR(100)= null,
    @ReceivedQty NVARCHAR(100)= null,
    @WorkOrderNo NVARCHAR(200) = NULL,
    @SP_Action NVARCHAR(100) = NULL,
    @sheduledate DATE = Null,
    @HeaderID nvarchar(100)= Null
   ,@TotalQty nvarchar(100)= null
   ,@AllocatedQty nvarchar(100)= null
   ,@AllocatedSqFeet nvarchar(200)= null
   ,@SqFeet nvarchar(100)= null
   ,@Stage1MachineID nvarchar(100)= null
   ,@Stage1CompletedQty nvarchar(100)= null
   ,@Stage1CompletedDate datetime = null
   ,@Stage2MachineID nvarchar(100)= null
   ,@Stage2CompletedQty nvarchar(100)= null
   ,@Stage2CompletedDate datetime= null
   ,@Result INT OUTPUT

AS
BEGIN
     
    --old working action
    IF @SP_Action = 'GetOperatorDetailsS1'
     BEGIN
        SELECT UM.FullName as OperatorName,MM.ID as MachineID ,MM.MachineName as MachineName,MM.AllocatedStage as StageName
        ,SUM(ISNULL(CAST(MPD.AllocatedQty as decimal),0)) as TargetQty
        ,SUM(ISNULL(CAST(MPD.Stage1CompletedQty as decimal),0)) as CompletedQty
        FROM tbl_AssignedMachines AM
        LEFT JOIN tbl_UserMaster UM ON AM.OperatorID = UM.ID
        LEFT JOIN tbl_MachineMaster MM ON AM.MachineId = MM.ID   
        LEFT JOIN tbl_MachineProductionDTLS MPD ON AM.MachineID = MPD.Stage1MachineID
        WHERE (@WOHeaderId = 'Admin'OR AM.OperatorID = @Id) AND MM.AllocatedStage = 'Stage 1'
        GROUP BY UM.FullName,MM.ID,MM.MachineName,MM.AllocatedStage
     END

    IF @SP_Action = 'GetOperatorDetailsS2'
     BEGIN
        SELECT UM.FullName as OperatorName,MM.ID as MachineID ,MM.MachineName as MachineName,MM.AllocatedStage as StageName
        ,SUM(ISNULL(CAST(MPD.AllocatedQty as decimal),0)) as TargetQty
        ,SUM(ISNULL(CAST(MPD.Stage2CompletedQty as decimal),0)) as CompletedQty
        FROM tbl_AssignedMachines AM
        LEFT JOIN tbl_UserMaster UM ON AM.OperatorID = UM.ID
        LEFT JOIN tbl_MachineMaster MM ON AM.MachineId = MM.ID   
        LEFT JOIN tbl_MachineProductionDTLS MPD ON AM.MachineID = MPD.Stage2MachineID
        WHERE (@WOHeaderId = 'Admin'OR AM.OperatorID = @Id) AND MM.AllocatedStage = 'Stage 2'
        GROUP BY UM.FullName,MM.ID,MM.MachineName,MM.AllocatedStage
     END
  
    IF @SP_Action= 'GetMachineCapacity'
     BEGIN
       SELECT M.ID as MachineID,
               M.AllocatedStage,
               M.MachineName,
               (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)) AS MachineCapacity,
               ISNULL(SUM(TRY_CAST(MPD.AllocatedSqFeet AS FLOAT)), 0) - ISNULL(SUM(TRY_CAST(MPD.Stage1CompetedSqFeet AS FLOAT)), 0) AS MachineLoad,
               ((TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT))
                - (ISNULL(SUM(TRY_CAST(MPD.AllocatedSqFeet AS FLOAT)), 0) - ISNULL(SUM(TRY_CAST(MPD.Stage1CompetedSqFeet AS FLOAT)), 0))
               ) AS MachineAvailable,

               -- ✔ LOAD %
               CASE
                   WHEN (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)) = 0 THEN
                       0
                   ELSE
                       ROUND(
                                ((ISNULL(SUM(TRY_CAST(MPD.AllocatedSqFeet AS FLOAT)), 0) - 
                                ISNULL(SUM(TRY_CAST(MPD.Stage1CompetedSqFeet AS FLOAT)), 0)) * 100.0)
                                / (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)),
                                2
                            )
               END AS LoadPercentage
        FROM tbl_MachineMaster M
            LEFT JOIN tbl_MachineProductionDTLS MPD 
            ON MPD.Stage1MachineID = M.ID 
            --AND MPH.Status = 'In-Process'
        WHERE M.IsDeleted = 0
              AND M.IsActive = 1 AND M.AllocatedStage ='Stage 1'
        GROUP BY M.ID,
                 M.AllocatedStage,
                 M.MachineName,
                 M.MachinePerHRQty,
                 M.MachineRunningHR;
     END
    
    IF @SP_Action = 'GetWorkOrder'
     BEGIN
       WITH WorkOrder AS(
            SELECT 
                hdr.RankNo,
                hdr.ScheduledDate,
                hdr.ID AS MainID,
                hdr.TallyRefNo,
                hdr.Dealer,
                hdr.CustomerName,
                hdr.isdesignapproved,

                dtls.ID AS DetailedID,
                dtls.ProductName,
                dtls.PartNo,
                dtls.Size,
                dtls.Qty AS Qty,
                dtls.SqFeet AS SqFeet,

                mph.ID AS ProductionID,
                mph.S1Status as Status,
                mpd.Stage1MachineId as MachineID,

                ISNULL(mpd.AllocatedQty,0) AS AllocatedQty,
                ISNULL(mpd.AllocatedSqFeet,0) AS AllocatedSqFeet,

                dtls.Qty - ISNULL(CAST(mpd.AllocatedQty as FLOAT),0) AS RemainingQty,
                dtls.SqFeet - ISNULL(CAST(mpd.AllocatedSqFeet as FLOAT),0) AS RemainingSqFeet

            FROM tbl_WorkOrderDetails dtls
            INNER JOIN tbl_WorkOrderHDR hdr
                ON hdr.ID = dtls.HeaderID

            LEFT JOIN tbl_MachineProductionHDR mph
                ON mph.WorkOrderID = hdr.ID

            LEFT JOIN tbl_MachineProductionDTLS mpd
                ON mpd.HeaderID = mph.ID
                AND mpd.ProductName = dtls.ProductName
                AND mpd.Size = dtls.Size

            WHERE hdr.isdesignapproved = 1
            AND hdr.IsDeleted = 0 AND (mph.S1Status IS NULL OR mph.S1Status <> 'Completed') 
          ),NUMBERED AS(
            SELECT *,ROW_NUMBER() OVER(ORDER BY MainID DESC) AS RN
            FROM WorkOrder
          )
          SELECT * FROM NUMBERED
              WHERE @ShowRecords = 0
			    OR RN <= @ShowRecords
          ORDER BY MainID DESC
     END

    IF @SP_Action = 'AssignWorkOrderS1'
      BEGIN
        WITH WorkOrder AS (
           SELECT
                mph.RankSrNo AS RankNo,
                mph.WorkOrderNo AS WorkOrderNo,
                mph.AssignedDate AS ScheduledDate,
                hdr.Dealer,
                hdr.isdesignapproved,

                mpd.ID AS DetailedID,
                mpd.ProductName,
                mpd.Size,
                mpd.TotalQty AS totQty,
                mpd.SqFeet AS SqFeet,

                mph.ID AS ProductionID,
                mph.S1Status as Status,
                mpd.Stage1MachineId as MachineID,

                ISNULL(mpd.AllocatedQty,0) AS AllocatedQty,
                ISNULL(mpd.AllocatedSqFeet,0) AS AllocatedSqFeet,

                ISNULL(mpd.Stage2CompletedQty,0) AS Stage2CompletedQty,
                ISNULL(mpd.Stage1CompletedQty,0) AS Stage1CompletedQty,
                ISNULL(mpd.Stage1CompetedSqFeet,0) AS Stage1CompetedSqFeet,
               CONVERT(nvarchar(10),mpd.Stage1CompletedDate,105) AS Stage1CompletedDate

            FROM tbl_MachineProductionDTLS mpd
            INNER JOIN tbl_MachineProductionHDR mph
                ON mph.ID = mpd.HeaderID

            LEFT JOIN tbl_WorkOrderHdr hdr
                ON hdr.ID = mph.WorkOrderID

            WHERE hdr.isdesignapproved = 1
            AND hdr.IsDeleted = 0 AND mpd.Stage1MachineID = @Id
       ),
         NUMBERED AS (SELECT *, ROW_NUMBER() OVER (ORDER BY CASE WHEN RankNo IS NULL THEN 1 ELSE 0 END, RankNo ASC) AS RN
           FROM WorkOrder
       )
        SELECT *
            FROM NUMBERED
            WHERE @ShowRecords = 0
                  OR RN <= @ShowRecords
            ORDER BY CASE
                         WHEN RankNo IS NULL THEN
                             1
                         ELSE
                             0
                     END,
                     RankNo ASC
      END

    IF @SP_Action = 'InsertToProductionHdrS1'
     BEGIN
       INSERT INTO tbl_MachineProductionHDR (WorkOrderID,WorkOrderNo,RankSrNo,AssignedDate,S1Status)
       VALUES(@WOHeaderId,@WorkOrderNo,NULL,@sheduledate,'Machine Allocated')

       SET @Result = SCOPE_IDENTITY();
     END

    IF @SP_Action = 'InsertToProductionDtlsS1'
     BEGIN
       INSERT INTO tbl_MachineProductionDTLS (HeaderID,ProductName,Size,TotalQty,SqFeet,AllocatedQty,AllocatedSqFeet
       ,Stage1MachineID,Stage1CompletedQty,Stage1CompetedSqFeet)
       VALUES(@HeaderID,@ProductName,@Size,@TotalQty,@SqFeet,@AllocatedQty,@AllocatedSqFeet,@Stage1MachineID,'0','0')

       SET @Result = SCOPE_IDENTITY();
     END

    IF @SP_Action = 'AssignWorkOrderS2'
      BEGIN
        WITH WorkOrder AS (
           SELECT
                mph.RankSrNo AS RankNo,
                mph.WorkOrderNo AS WorkOrderNo,
                mph.AssignedDate AS ScheduledDate,
                hdr.Dealer,
                hdr.isdesignapproved,

                mpd.ID AS DetailedID,
                mpd.ProductName,
                mpd.Size,
                mpd.TotalQty AS totQty,
                mpd.SqFeet AS SqFeet,

                mph.ID AS ProductionID,
                mph.S2Status as Status,
                mpd.Stage2MachineId as MachineID,

                ISNULL(mpd.AllocatedQty,0) AS AllocatedQty,
                ISNULL(mpd.AllocatedSqFeet,0) AS AllocatedSqFeet,

                ISNULL(mpd.Stage1CompletedQty,0) AS Stage1CompletedQty, 
                ISNULL(mpd.Stage2CompletedQty,0) AS Stage2CompletedQty,
                ISNULL(mpd.Stage2CompetedSqFeet,0) AS Stage2CompetedSqFeet,
                CONVERT(nvarchar(10),mpd.Stage2CompletedDate,105) AS Stage2CompletedDate

            FROM tbl_MachineProductionDTLS mpd
            INNER JOIN tbl_MachineProductionHDR mph
                ON mph.ID = mpd.HeaderID

            LEFT JOIN tbl_WorkOrderHdr hdr
                ON hdr.ID = mph.WorkOrderID

            WHERE hdr.isdesignapproved = 1
            AND hdr.IsDeleted = 0 --AND mpd.Stage2MachineID = @Id
       ),
         NUMBERED AS (SELECT *, ROW_NUMBER() OVER (ORDER BY CASE WHEN RankNo IS NULL THEN 1 ELSE 0 END, RankNo ASC) AS RN
           FROM WorkOrder
       )
        SELECT *
            FROM NUMBERED
            WHERE @ShowRecords = 0
                  OR RN <= @ShowRecords
            ORDER BY CASE
                         WHEN RankNo IS NULL THEN
                             1
                         ELSE
                             0
                     END,
                     RankNo ASC
      END

    IF @SP_Action = 'InsertToProductionDtlsS2'
     BEGIN
       INSERT INTO tbl_MachineProductionDTLS (HeaderID,ProductName,Size,TotalQty,SqFeet,AllocatedQty,AllocatedSqFeet
       ,Stage1MachineID,Stage1CompletedQty,Stage1CompetedSqFeet)
       VALUES(@HeaderID,@ProductName,@Size,@TotalQty,@SqFeet,@AllocatedQty,@AllocatedSqFeet,@Stage1MachineID,'0','0')

       SET @Result = SCOPE_IDENTITY();
     END

    IF @SP_Action = 'GetCompletedWOList'
     BEGIN
       WITH WorkOrder AS(
            SELECT WO.ID AS ID,TallyRefNo,CONVERT(nvarchar(10),WorkOrderDate,105) AS WorkOrderDate,Dealer,CustomerName,isdesignapproved,AttachmentPath
				FROM tbl_WorkOrderHdr WO 
				LEFT JOIN tbl_MachineProductionhdr MP
				ON MP.WorkOrderID = WO.ID
				WHERE IsDeleted = 0 AND MP.S2Status ='Completed'
			       AND (
				        @MachineID = ''
                       OR TallyRefNo LIKE '%'+ @MachineID + '%'
					   OR Dealer LIKE '%'+ @MachineID + '%'
					   OR CustomerName LIKE '%'+ @MachineID + '%'
			          )
          ),NUMBERED AS(
            SELECT *,ROW_NUMBER() OVER(ORDER BY ID DESC) AS RN
            FROM WorkOrder
          )
          SELECT * FROM NUMBERED
              WHERE @ShowRecords = 0
			    OR RN <= @ShowRecords
          ORDER BY ID DESC
     END



       -- new created one

     IF @SP_Action= 'GetMachineCapacityss'
     BEGIN
       SELECT M.ID as MachineID,
               M.AllocatedStage,
               M.MachineName,
               (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)) AS MachineCapacity,
               ISNULL(SUM(TRY_CAST(MPA.AllocatedSqFeet AS FLOAT)), 0) - ISNULL(SUM(TRY_CAST(MPA.CompletedQty AS FLOAT)), 0) AS MachineLoad,
               ((TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT))
                - (ISNULL(SUM(TRY_CAST(MPA.AllocatedSqFeet AS FLOAT)), 0) - ISNULL(SUM(TRY_CAST(MPA.CompletedSqFeet AS FLOAT)), 0))
               ) AS MachineAvailable,

               -- ✔ LOAD %
               CASE
                   WHEN (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)) = 0 THEN
                       0
                   ELSE
                       ROUND(
                                ((ISNULL(SUM(TRY_CAST(MPA.AllocatedSqFeet AS FLOAT)), 0) - 
                                ISNULL(SUM(TRY_CAST(MPA.CompletedQty AS FLOAT)), 0)) * 100.0)
                                / (TRY_CAST(M.MachinePerHRQty AS FLOAT) * TRY_CAST(M.MachineRunningHR AS FLOAT)),
                                2
                            )
               END AS LoadPercentage
        FROM tbl_MachineMaster M
            LEFT JOIN tbl_MachineProductionAllocation MPA 
            ON MPA.MachineID = M.ID
            LEFT JOIN tbl_MachineProductionDTLS MPD
            ON MPA.ProductDtlID = MPD.ID
            --AND MPH.Status = 'In-Process'
        WHERE M.IsDeleted = 0
              AND M.IsActive = 1 AND M.AllocatedStage ='Stage 1'
        GROUP BY M.ID,
                 M.AllocatedStage,
                 M.MachineName,
                 M.MachinePerHRQty,
                 M.MachineRunningHR;
     END
    
     IF @SP_Action = 'GetWorkOrdersss'
     BEGIN
       WITH WorkOrder AS(
             SELECT 
                hdr.RankNo,
                hdr.ScheduledDate,
                hdr.ID AS MainID,
                hdr.TallyRefNo,
                hdr.Dealer,
                hdr.CustomerName,
                hdr.isdesignapproved,

                dtls.ID AS DetailedID,
                dtls.ProductName,
                dtls.PartNo,
                dtls.Size,
                dtls.Qty AS Qty,
                dtls.SqFeet AS SqFeet,

                mph.ID AS ProductionID,
                mph.S1Status as Status,
                STUFF(
                (
                    SELECT ',' + mpa2.MachineID
                    FROM tbl_MachineProductionAllocation mpa2
                    INNER JOIN tbl_MachineProductionDTLS mpd2
                        ON mpd2.ID = mpa2.ProductDtlID
                    WHERE mpd2.HeaderID = mph.ID
                      AND mpd2.ProductName = dtls.ProductName
                      AND mpd2.Size = dtls.Size
                    FOR XML PATH(''), TYPE
                ).value('.', 'NVARCHAR(MAX)'), 1, 1, '') AS MachineID,

                ISNULL(SUM(CAST(mpa.AllocatedQty as decimal)) ,0) AS AllocatedQty,
                ISNULL(SUM(CAST(mpa.AllocatedSqFeet as decimal)),0) AS AllocatedSqFeet,

                dtls.Qty - ISNULL(SUM(CAST(mpa.AllocatedQty as decimal)),0) AS RemainingQty,
                dtls.SqFeet - ISNULL(SUM(CAST(mpa.AllocatedSqFeet as decimal)),0) AS RemainingSqFeet

            FROM tbl_WorkOrderDetails dtls
            INNER JOIN tbl_WorkOrderHDR hdr
                ON hdr.ID = dtls.HeaderID

            LEFT JOIN tbl_MachineProductionHDR mph
                ON mph.WorkOrderID = hdr.ID

            LEFT JOIN tbl_MachineProductionDTLS mpd
                ON mpd.HeaderID = mph.ID
                AND mpd.ProductName = dtls.ProductName
                AND mpd.Size = dtls.Size

            LEFT JOIN tbl_MachineProductionAllocation mpa
                ON mpd.ID = mpa.ProductDtlID

            WHERE hdr.isdesignapproved = 1
            AND hdr.IsDeleted = 0  AND mpa.NextStageId IS NULL
            GROUP BY  hdr.RankNo,
                hdr.ScheduledDate,
                hdr.ID,
                hdr.TallyRefNo,
                hdr.Dealer,
                hdr.CustomerName,
                hdr.isdesignapproved,

                dtls.ID ,
                dtls.ProductName,
                dtls.PartNo,
                dtls.Size,
                dtls.Qty,
                dtls.SqFeet,

                mph.ID,
                mph.S1Status
          ),NUMBERED AS(
            SELECT *,ROW_NUMBER() OVER(ORDER BY MainID DESC) AS RN
            FROM WorkOrder
          )
          SELECT * FROM NUMBERED
              WHERE @ShowRecords = 0
			    OR RN <= @ShowRecords
          ORDER BY MainID DESC
     END
        
     IF @SP_Action = 'InsertToProductionHdr'
     BEGIN
       INSERT INTO tbl_MachineProductionHDR (WorkOrderID,WorkOrderNo,RankSrNo,AssignedDate,S1Status)
       VALUES(@WOHeaderId,@WorkOrderNo,NULL,@sheduledate,'Machine Allocated')

       SET @Result = SCOPE_IDENTITY();
     END

     IF @SP_Action = 'InsertToProductionDtls'
     BEGIN
       INSERT INTO tbl_MachineProductionDTLS (HeaderID,ProductName,Size,TotalQty,SqFeet)
       VALUES(@HeaderID,@ProductName,@Size,@TotalQty,@SqFeet)

       SET @Result = SCOPE_IDENTITY();
     END

     IF @SP_Action = 'InsertToProductionDtlsAllocation'
     BEGIN
       INSERT INTO tbl_MachineProductionAllocation (ProductDtlID,MachineID,AllocatedQty,AllocatedSqFeet,CompletedQty,CompletedSqFeet)
       VALUES(@HeaderID,@MachineID,@AllocatedQty,@AllocatedSqFeet,'0','0')

       SET @Result = SCOPE_IDENTITY();
     END

     IF @SP_Action = 'AssignWorkOrders'
      BEGIN
        WITH WorkOrder AS (
           SELECT
                mph.RankSrNo AS RankNo,
                mph.WorkOrderNo AS WorkOrderNo,
                mph.AssignedDate AS ScheduledDate,
                hdr.Dealer,
                mpa.ID AS DetailedID,
                mpd.ProductName,
                mpd.Size,
                mpd.TotalQty AS totQty,
                mpd.SqFeet AS SqFeet,

               CASE
                    WHEN SUM(ISNULL(CAST(mpa.CompletedQty AS decimal(18,2)),0)) = 0
                        THEN 'Machine Allocated'

                    WHEN SUM(ISNULL(CAST(mpa.CompletedQty AS decimal(18,2)),0))
                         < SUM(ISNULL(CAST(mpa.AllocatedQty AS decimal(18,2)),0))
                        THEN 'Work Started'

                    ELSE 'Completed'
                END AS Status1,

                 CASE
                    WHEN SUM(ISNULL(CAST(mpa.AllocatedQty AS decimal),0)) = 0 
                        THEN ''

                    WHEN (SUM(ISNULL(CAST(mpa.AllocatedQty AS decimal),0)) != 0 
                         AND SUM(ISNULL(CAST(mpa.AllocatedQty AS decimal),0)) <= SUM(ISNULL(CAST(mpd.TotalQty AS decimal),0)))
                        THEN 'Partially Active'

                    WHEN SUM(ISNULL(CAST(mpa.AllocatedQty AS decimal),0)) = SUM(ISNULL(CAST(mpd.TotalQty AS decimal),0))
                        THEN 'Active'

                    ELSE 'Completed'
                END AS Status2,

                mpd.HeaderID AS ProductionID,
                MAX(mpa.MachineID) as MachineID,

                ISNULL(SUM(CAST(mpa.AllocatedQty as decimal)),0) AS AllocatedQty,
                ISNULL(SUM(CAST(mpa.AllocatedSqFeet as decimal)),0) AS AllocatedSqFeet,

                ISNULL(SUM(CAST(mpa.CompletedQty as decimal)),0) AS CompletedQty,
                ISNULL(SUM(CAST(mpa.CompletedSqFeet as decimal)),0) AS CompetedSqFeet,
               CONVERT(nvarchar(10),MAX(mpa.CompletedDate),105) AS CompletedDate
            
            FROM tbl_MachineProductionAllocation mpa
            INNER JOIN tbl_MachineProductionDTLS mpd
                ON mpd.ID = mpa.ProductDtlID
            INNER JOIN tbl_MachineProductionHDR mph
                ON mph.ID = mpd.HeaderID

            LEFT JOIN tbl_WorkOrderHdr hdr
                ON hdr.ID = mph.WorkOrderID

            WHERE hdr.isdesignapproved = 1
            AND hdr.IsDeleted = 0 AND mpa.MachineID = @Id
            GROUP BY   mph.RankSrNo ,
                mph.WorkOrderNo,
                mph.AssignedDate,
                hdr.Dealer,
                mpa.ID,
                mpd.ProductName,
                mpd.Size,
                mpd.TotalQty,
                mpd.SqFeet,

                mph.S1Status,
                mpd.HeaderID
       ),
         NUMBERED AS (SELECT *, ROW_NUMBER() OVER (ORDER BY CASE WHEN RankNo IS NULL THEN 1 ELSE 0 END, RankNo ASC) AS RN
           FROM WorkOrder
       )
        SELECT *
            FROM NUMBERED
            WHERE @ShowRecords = 0
                  OR RN <= @ShowRecords
            ORDER BY CASE
                         WHEN RankNo IS NULL THEN
                             1
                         ELSE
                             0
                     END,
                     RankNo ASC
      END
     
END


-- Script for SP_DealerMaster
GO
CREATE PROCEDURE [dbo].[SP_DealerMaster]
     @ShowRecords INT = 0
	,@Id int =0
	,@UserCode NVARCHAR(100) = NULL
	,@FullName NVARCHAR(500) = NULL
	,@CompanyName NVARCHAR(500) = NULL
	,@MobileNo NVARCHAR(100) = NULL
	,@EmialId NVARCHAR(100) = NULL
	,@Password NVARCHAR(100) = NULL
	,@Type NVARCHAR(100) =NULL
	,@GstNo NVARCHAR(100) =NULL
	,@PanCardNo NVARCHAR(100) =NULL
	,@UANNo NVARCHAR(100) =NULL
	,@BillAddress NVARCHAR(max) =NULL
	,@BillArea NVARCHAR(max) =NULL
	,@BillPinCode NVARCHAR(100) =NULL
	,@BillState NVARCHAR(100) =NULL
	,@BillCity NVARCHAR(100) =NULL
	,@BillCountry NVARCHAR(100) = NULL
	,@ShipAddress NVARCHAR(max) =NULL
	,@ShipArea NVARCHAR(max) =NULL
	,@ShipPinCode NVARCHAR(100) =NULL
	,@ShipState NVARCHAR(100) =NULL
	,@ShipCity NVARCHAR(100) =NULL
	,@ShipCountry NVARCHAR(100) = NULL
	,@UserRole NVARCHAR(100) = NULL
	,@RelationId NVARCHAR(100) = NULL
	,@IsActive NVARCHAR(100) = NULL
	,@IsDeleted NVARCHAR(100) = NULL
	,@ActionBy NVARCHAR(100) = NULL
	,@SP_Action NVARCHAR(100) = NULL
	AS 
	BEGIN
	  IF @SP_Action = 'DealerList'
	   BEGIN
		   WITH UserMaster
			AS (
			    SELECT UM.ID AS ID,UserCode,FullName,CompanyName,EmailId,IsActivate,LoginPass FROM tbl_UserMaster UM 
				INNER JOIN tbl_RoleMaster RM ON RM.Roles = UM.UserRole 
				WHERE UM.IsDeleted = 0 AND RM.Departments = 'Outsourcing'
			       AND (
				    @FullName = '' 
					OR FullName LIKE '%' + @FullName + '%'
					OR UserCode LIKE '%' + @FullName + '%'
					OR CompanyName LIKE '%' + @FullName + '%'
					OR EmailId LIKE '%' + @FullName + '%'
					OR LoginPass LIKE '%' + @FullName + '%'

						--FullName LIKE CASE 
						--	WHEN @FullName != ''
						--		THEN @FullName
						--	ELSE '%%'
						--	END
			          )
			   ),NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY Id DESC
					) AS RN
			FROM UserMaster
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
		ORDER BY ID DESC
	   END

	  IF @SP_Action = 'DealerListById'
	   BEGIN
		  SELECT * FROM tbl_UserMaster WHERE ID = @Id
	   END

      IF @SP_Action = 'CheckEmialId'
	   BEGIN
	     SELECT EmailId FROM tbl_UserMaster WHERE IsDeleted=0 AND EmailId =@EmialId
 	   END
	 
	  IF @SP_Action = 'InsertDealer'
	   BEGIN
	     INSERT INTO tbl_UserMaster (
			UserCode
			,FullName
			,CompanyName
			,MobileNo
			,EmailId
			,LoginPass
			,Type
			,GstNo
			,PanCardNo
			,UANNo
			,BillAddress
			,BillArea
			,BillPinCode
			,BillState
			,BillCity
			,BillCountry
			,ShipAddress
			,ShipArea
			,ShipPinCode
			,ShipState
			,ShipCity
			,ShipCountry
			,UserRole
			,IsActivate
			,IsDeleted
			,CreatedOn
			,CreatedBy
			)
		VALUES (
			dbo.FN_GenerateUserCode()
			,@FullName
			,@CompanyName
			,@MobileNo
			,@EmialId
			,@Password
			,@Type
			,@GstNo
			,@PanCardNo
			,@UANNo
			,@BillAddress
			,@BillArea
			,@BillPinCode
			,@BillState
			,@BillCity
			,@BillCountry
			,@ShipAddress
			,@ShipArea
			,@ShipPinCode
			,@ShipState
			,@ShipCity
			,@ShipCountry
			,@UserRole	
			,1
			,0
			,GETDATE()
			,@ActionBy
			)
	   END

      IF @SP_Action = 'UpdateDealer'
	   BEGIN
	    UPDATE tbl_UserMaster
		SET FullName = @FullName
		    ,CompanyName = @CompanyName
			,MobileNo = @MobileNo
			,EmailId = @EmialId
			,LoginPass = @Password
			,Type = @Type
			,GstNo=@GstNo
			,PanCardNo = @PanCardNo
			,UANNo = @UANNo
			,BillAddress= @BillAddress
			,BillArea = @BillArea
			,BillPinCode = @BillPinCode
			,BillState = @BillState
			,BillCity =@BillCity
			,BillCountry=@BillCountry
			,ShipAddress= @ShipAddress
			,ShipArea = @ShipArea
			,ShipPinCode = @ShipPinCode
			,ShipState = @ShipState
			,ShipCity = @ShipCity
			,ShipCountry = @ShipCountry
			,UserRole=@UserRole
			,UpdatedBy = @ActionBy
			,UpdatedOn = GETDATE()
		WHERE ID = @Id
	   END

      IF (@SP_Action = 'DeleteDealer')
		BEGIN
			UPDATE tbl_UserMaster
			SET IsDeleted = 1
			WHERE ID = @Id
		END

      IF(@SP_Action = 'RoleListForDealer')
		BEGIN
		  SELECT * FROM tbl_RoleMaster WHERE IsDeleted = 0 AND Departments='Outsourcing' ORDER BY ID DESC
		END
	END

-- Script for SP_StageMaster
GO
CREATE PROCEDURE [dbo].[SP_StageMaster]
	 @ShowRecords INT = 0
	,@Id int =0
	,@SatgeName nvarchar(500) = null
	,@SatgeDescription nvarchar(MAX) = null
	,@SatgeCapacity nvarchar(100) = null
	,@CapacityUnit nvarchar(100) = null
	,@IsDeleted bit  = 0
	,@ActionBy nvarchar(500)= null
	,@SP_Action nvarchar(500) = null
AS
BEGIN
  IF @SP_Action = 'GetStageList'
   BEGIN
      WITH StageMaster
			AS (
			    SELECT * FROM tbl_StageMaster WHERE IsDeleted = 0 
			       AND (
				         @SatgeName = '' 
						OR SatgeName LIKE '%' + @SatgeName + '%'
						OR SatgeDescription LIKE '%' + @SatgeName + '%'
						OR SatgeCapacity LIKE '%' + @SatgeName + '%'
						OR CapacityUnit LIKE '%' + @SatgeName + '%'
						--SatgeName LIKE CASE 
						--	WHEN @SatgeName != ''
						--		THEN @SatgeName
						--	ELSE '%%'
						--	END
			          )
			   ),NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY ID DESC
					) AS RN
			FROM StageMaster
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
		ORDER BY ID DESC
   END

  IF @SP_Action = 'StageListById'
	   BEGIN
		  SELECT * FROM tbl_StageMaster WHERE ID = @Id
	   END
	 
  IF @SP_Action = 'InsertStage'
	   BEGIN
	     INSERT INTO tbl_StageMaster (
			 SatgeName
			,SatgeDescription
			,SatgeCapacity
			,CapacityUnit
			,IsDeleted
			,CreatedBy
			,CreatedOn
			)
		VALUES (
			@SatgeName
			,@SatgeDescription
			,@SatgeCapacity
			,@CapacityUnit
			,0
			,@ActionBy
			,GETDATE()
			)
	   END

  IF @SP_Action = 'UpdateStage'
	   BEGIN
	    UPDATE tbl_StageMaster
		SET SatgeName = @SatgeName
		    ,SatgeDescription = @SatgeDescription
			,SatgeCapacity = @SatgeCapacity
			,CapacityUnit = @CapacityUnit
			,UpdatedBy = @ActionBy
			,UpdatedOn = GETDATE()
		WHERE ID = @Id
	   END
	   
  IF (@SP_Action = 'DeleteStage')
		BEGIN
			UPDATE tbl_StageMaster
			SET IsDeleted = 1
			WHERE ID = @Id
		END
END





-- Script for SP_MachineMaster
GO
CREATE PROCEDURE [dbo].[SP_MachineMaster]
  @ShowRecords INT = 0
 ,@ID int =0
 ,@MachineName nvarchar(max)= null
 ,@MachineDescription nvarchar(max)= null
 ,@MachinePerHRQty nvarchar(100) =null
 ,@MachineRunningHR nvarchar(10)= null
 ,@MachineImageName nvarchar(max)= null
 ,@AllocatedStage nvarchar(10)= null
 ,@IsActive bit = 0
 ,@IsActivateDate datetime = null
 ,@IsDeactiveDate datetime = null
 ,@ActionBy nvarchar(100) =null
 ,@SP_Action nvarchar(100) = null
AS
BEGIN
      IF @SP_Action = 'MachineList'
	   BEGIN
		   WITH MachineMaster
			AS (
			    SELECT ID,MachineName,MachineDescription,MachinePerHRQty,MachineRunningHR,AllocatedStage,IsActive,IsActivateDate,IsDeactiveDate,MachineImageName
				FROM tbl_MachineMaster WHERE IsDeleted = 0 
			       AND (
				         @MachineName = '' 
							OR MachineName LIKE '%' + @MachineName + '%'
							OR AllocatedStage LIKE '%' + @MachineName + '%'
							OR MachineDescription LIKE '%' + @MachineName + '%'
							OR MachinePerHRQty LIKE '%' + @MachineName + '%'
						    OR MachineRunningHR LIKE '%' + @MachineName + '%'
				       
						--MachineName LIKE CASE 
						--	WHEN @MachineName != ''
						--		THEN @MachineName
						--	ELSE '%%'
						--	END
			          )
			   ),NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY Id DESC
					) AS RN
			FROM MachineMaster
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
		ORDER BY ID DESC
	   END

	  IF @SP_Action = 'MachineListById'
	   BEGIN
		  SELECT * FROM tbl_MachineMaster WHERE ID = @Id
	   END
	 
	  IF @SP_Action = 'InsertMachine'
	   BEGIN
	     INSERT INTO tbl_MachineMaster (
			 MachineName
			,MachineDescription
			,MachinePerHRQty
			,MachineRunningHR
			,AllocatedStage
			,MachineImageName
			,IsActive
			,IsActivateDate
			,IsDeleted
			,CreatedBy
			,CreatedOn
			)
		VALUES (
			 @MachineName
			,@MachineDescription
			,@MachinePerHRQty
			,@MachineRunningHR
			,@AllocatedStage
			,@MachineImageName
			,1
			,GETDATE()
			,0
			,@ActionBy
			,GETDATE()
			)
	   END

      IF @SP_Action = 'UpdateMachine'
	   BEGIN
	    UPDATE tbl_MachineMaster
		SET MachineName = @MachineName
		    ,MachineDescription = @MachineDescription
			,MachinePerHRQty = @MachinePerHRQty
			,MachineRunningHR = @MachineRunningHR
			,MachineImageName = @MachineImageName
			,AllocatedStage = @AllocatedStage
			,UpdatedBy = @ActionBy
			,UpdatedOn = GETDATE()
		WHERE ID = @Id
	   END

      IF (@SP_Action = 'DeleteMachine')
		BEGIN
			UPDATE tbl_MachineMaster
			SET IsDeleted = 1
			WHERE ID = @Id
		END

      IF(@SP_Action = 'StageList')
		BEGIN
		  SELECT * FROM tbl_StageMaster WHERE IsDeleted = 0 ORDER BY ID DESC
		END
END




-- Script for Sp_TransporterMaster
GO
CREATE PROCEDURE [dbo].[Sp_TransporterMaster]
(
    @transporter_code NVARCHAR(20) = Null ,
    @transporter_name NVARCHAR(100) = Null,
    @gst_no NVARCHAR(20) = Null,
    @pan_no NVARCHAR(20) = Null,
    @contact_person NVARCHAR(100) = Null,
    @mobile NVARCHAR(15) = Null,
    @email NVARCHAR(100) = Null,
    @ActionBy NVARCHAR(100) = Null,
    @address NVARCHAR(MAX) = Null,
    @city NVARCHAR(50) = Null,
    @state NVARCHAR(50) = Null,
    @pincode NVARCHAR(10) = Null,
    @vehicle_type NVARCHAR(50) = Null,
    @rate_per_km DECIMAL(10,2) = Null,
    @service_route NVARCHAR(200) = Null,
    @bank_name NVARCHAR(100) = Null,
    @account_no NVARCHAR(30) = Null,
    @ifsc_code NVARCHAR(20) = Null,
    @status NVARCHAR(10) = Null,
    @SP_Action NVARCHAR(20) = Null,
    @ShowRecords INT = 0,
    @id Bigint = 0
)
AS
BEGIN

    SET NOCOUNT ON;

     IF(@SP_Action='InsertDealer')

    BEGIN

    INSERT INTO tbl_Transportermaster
    (
        transporter_code,
        transporter_name,
        gst_no,
        pan_no,

        contact_person,
        mobile,
        email,

        address,
        city,
        state,
        pincode,

        vehicle_type,
        rate_per_km,

       

        bank_name,
        account_no,
        ifsc_code,

        status,
        serviceRoute,
        IsDeleted,
        CreatedBy,
        CreatedOn
    )
    VALUES
    (
        @transporter_code,
        @transporter_name,
        @gst_no,
        @pan_no,

        @contact_person,
        @mobile,
        @email,

        @address,
        @city,
        @state,
        @pincode,

        @vehicle_type,
        @rate_per_km,

       

        @bank_name,
        @account_no,
        @ifsc_code,

        1,
        @service_route,
        0,
        @ActionBy,
        GETDATE()
    );
    END

     IF (@SP_Action = 'TransporterList')
    BEGIN

        WITH CTE_Transporter AS
        (
            SELECT *
            FROM tbl_Transportermaster
            WHERE IsDeleted = 0
            AND (@transporter_name IS NULL OR transporter_name LIKE '%' + @transporter_name + '%')
            AND (@city IS NULL OR city LIKE '%' + @city + '%')
            AND (@mobile IS NULL OR mobile LIKE '%' + @mobile + '%')
            AND (@status IS NULL OR status = @status)
        ),

        CTE_Numbered AS
        (
            SELECT *,
                   ROW_NUMBER() OVER (ORDER BY id DESC) AS RN
            FROM CTE_Transporter
        )

        SELECT *
        FROM CTE_Numbered
        WHERE @ShowRecords = 0 OR RN <= @ShowRecords
        ORDER BY id DESC;

END

     IF(@SP_Action ='GetByTransporterbyId')
     BEGIN
      select * from tbl_Transportermaster where id = @id and IsDeleted = 0 
     END

     IF (@SP_Action = 'UpdateTransporter')
      BEGIN
          UPDATE tbl_Transportermaster
    SET
        transporter_code = @transporter_code,
        transporter_name = @transporter_name,
        gst_no = @gst_no,
        pan_no = @pan_no,
        contact_person = @contact_person,
        mobile = @mobile,
        email = @email,
        address = @address,
        city = @city,
        state = @state,
        pincode = @pincode,
        vehicle_type = @vehicle_type,
        rate_per_km = @rate_per_km,
        bank_name = @bank_name,
        account_no = @account_no,
        ifsc_code = @ifsc_code,
        serviceRoute = @service_route,
        UpdatedBy = @ActionBy,
        UpdatedOn = GETDATE()

     WHERE id = @Id
         AND IsDeleted = 0;
       END

    IF (@SP_Action = 'DeleteTransporter')
     BEGIN

    UPDATE tbl_Transportermaster
    SET IsDeleted = 1
    WHERE id = @Id;

END
END

-- Script for SP_RawMaterialMaster
GO
CREATE PROCEDURE [dbo].[SP_RawMaterialMaster]
 @ShowRecords INT = 0
,@Id int =0
,@SupplierName nvarchar(500)= null
,@PurchaseNo nvarchar(500) =null
,@PurchaseDate datetime =null
,@HeaderId nvarchar(20) =null
,@RawMaterialName nvarchar(200)= null
,@RawMaterialCode nvarchar(100) =null
,@RawMaterialCategory nvarchar(200) =null
,@RawMaterialDesc nvarchar(max) =null
,@RawMaterialQty nvarchar(20) =null
,@Unit nvarchar(20)= null
,@PerQtyRate nvarchar(20)= null
,@GstPercentage nvarchar(20)= null
,@GstAmount nvarchar(20)= null
,@ActionBy NVARCHAR(100) = NULL
,@SP_Action NVARCHAR(100) = NULL
,@Result INT OUTPUT 
AS 
BEGIN
     -- HDR Table
  	  IF @SP_Action = 'RawMatHDRList'
	   BEGIN
		 WITH RawMaterialMaster
			AS (
			    SELECT ID,SupplierName,PurchaseNo,CONVERT(nvarchar(10),PurchaseDate,105) AS PurchaseDate FROM tbl_RawMaterial_HDR WHERE IsDeleted = 0  
			       AND (
				         @PurchaseNo = '' 
							OR SupplierName LIKE '%' + @PurchaseNo + '%'
							OR PurchaseNo LIKE '%' + @PurchaseNo + '%'
							
						--PurchaseNo LIKE CASE 
						--	WHEN @PurchaseNo != ''
						--		THEN @PurchaseNo
						--	ELSE '%%'
						--	END
			          )
			   ),NUMBERED
		AS (
			SELECT *
				,ROW_NUMBER() OVER (
					ORDER BY Id DESC
					) AS RN
			FROM RawMaterialMaster
			)
		SELECT *
		FROM NUMBERED
		WHERE @ShowRecords = 0
			OR RN <= @ShowRecords
		ORDER BY ID DESC
		 SET @Result = 0
	   END

	  IF @SP_Action = 'RawMatHDRListById'
	   BEGIN
		  SELECT * FROM tbl_RawMaterial_HDR WHERE ID = @Id
		  SET @Result = @Id
	   END
	 
	  IF @SP_Action = 'InsertRawMatHDR'
	   BEGIN
	     INSERT INTO tbl_RawMaterial_HDR (
			 SupplierName
			,PurchaseNo
			,PurchaseDate
			,IsActive
			,IsDeleted
			,CreatedBy
			,CreatedOn
			)
		VALUES (
			 @SupplierName
            ,@PurchaseNo
			,@PurchaseDate
			,1
			,0
			,@ActionBy
			,GETDATE()
			)
        SET @Result = SCOPE_IDENTITY()
	   END

      IF @SP_Action = 'UpdateRawMatHDR'
	   BEGIN
	    UPDATE tbl_RawMaterial_HDR
		SET SupplierName =@SupplierName
			,PurchaseNo = @PurchaseNo
			,PurchaseDate = @PurchaseDate
			,IsActive = 1
			,UpdatedBy = @ActionBy
			,UpdatedOn = GETDATE()
		WHERE ID = @Id
		SET @Result = @Id
	   END

      IF (@SP_Action = 'DeleteRawMatHDR')
		BEGIN
			UPDATE tbl_RawMaterial_HDR
			SET IsDeleted = 1
			WHERE ID = @Id
			SET @Result = @Id
		END

     -- DTLS Table
      IF @SP_Action = 'RawMatDTLSListById'
	   BEGIN
	     SELECT * FROM tbl_RawMaterial_DTLS WHERE HeaderId =@Id
		 SET @Result = @Id
 	   END 
     
      IF @SP_Action = 'InsertRawMatDTLS'
	   BEGIN
	     INSERT INTO tbl_RawMaterial_Dtls (
			 HeaderId
			,RawMaterialName
			,RawMaterialCode
			,RawMaterialCategory
			,RawMaterialDesc
			,RawMaterialQty
			,Unit
			,PerQtyRate
			,GstPercentage
			,GstAmount
			)
		VALUES (
			 @HeaderId
            ,@RawMaterialName
			,@RawMaterialCode
			,@RawMaterialCategory
			,@RawMaterialDesc
			,@RawMaterialQty
			,@Unit
			,@PerQtyRate
			,@GstPercentage
			,@GstAmount
			)
			 SET @Result = SCOPE_IDENTITY()
	   END
      
	  IF (@SP_Action = 'DeleteRawMatDTLS')
		BEGIN
			DELETE tbl_RawMaterial_Dtls WHERE HeaderId = @Id
			SET @Result = @Id
		END
END










































-- Script for SP_Reports
GO
CREATE PROCEDURE [dbo].[SP_Reports]
    @ShowRecords INT = 0,
    @ID INT = 0,
    @SP_Action NVARCHAR(100) = NULL

AS
BEGIN

    IF @SP_Action = 'productionsreports'

BEGIN

SELECT
    st1.ID,
    Hdr.WorkOrderNo,
    st1.ProductName,
    st1.PartNo,
    st1.Size,

    ISNULL(TRY_CAST(st1.ReceivedQty AS INT), 0) AS ReceivedQty,

    Mas.MachineName,
    Mas.AllocatedStage,
    st1.WOStatus,

    ISNULL(TRY_CAST(st1.CompletedQty AS INT), 0) AS CompletedQty,

    (
        ISNULL(TRY_CAST(st1.ReceivedQty AS INT), 0)
        -
        ISNULL(TRY_CAST(st1.CompletedQty AS INT), 0)
    ) AS BalanceQty,

    ISNULL(TRY_CAST(st1.RejectedQty AS INT), 0) AS RejectedQty

FROM tbl_Stage1Production AS st1
INNER JOIN tbl_WorkOrderHdr AS Hdr
    ON st1.WOHeaderId = Hdr.ID
INNER JOIN tbl_MachineMaster AS Mas
    ON Mas.ID = st1.MachineId

UNION ALL

SELECT
    st2.ID,
    Hdr.WorkOrderNo,
    st2.ProductName,
    st2.PartNo,
    st2.Size,

    ISNULL(TRY_CAST(st2.ReceivedQty AS INT), 0) AS ReceivedQty,

    Mas.MachineName,
    Mas.AllocatedStage,
    st2.WOStatus,

    ISNULL(TRY_CAST(st2.CompletedQty AS INT), 0) AS CompletedQty,

    (
        ISNULL(TRY_CAST(st2.ReceivedQty AS INT), 0)
        -
        ISNULL(TRY_CAST(st2.CompletedQty AS INT), 0)
    ) AS BalanceQty,

    ISNULL(TRY_CAST(st2.RejectedQty AS INT), 0) AS RejectedQty

FROM tbl_Stage2Production AS st2
INNER JOIN tbl_WorkOrderHdr AS Hdr
    ON st2.WOHeaderId = Hdr.ID
INNER JOIN tbl_MachineMaster AS Mas
    ON Mas.ID = st2.MachineId

ORDER BY WorkOrderNo;



END


  

   
   

END


-- FUNCTIONS
-- Script for FN_GenerateUserCode
GO
CREATE FUNCTION dbo.FN_GenerateUserCode()
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @NextNumber INT
    DECLARE @NewCode VARCHAR(20)
    DECLARE @FinancialYear VARCHAR(10)
    DECLARE @StartYear INT
    DECLARE @EndYear INT

    -- ==============================
    -- FINANCIAL YEAR CALCULATION
    -- APRIL TO MARCH
    -- ==============================
    IF MONTH(GETDATE()) >= 4
    BEGIN
        SET @StartYear = YEAR(GETDATE())
        SET @EndYear = YEAR(GETDATE()) + 1
    END
    ELSE
    BEGIN
        SET @StartYear = YEAR(GETDATE()) - 1
        SET @EndYear = YEAR(GETDATE())
    END

    -- FORMAT : 2026-27
    SET @FinancialYear = 
        CAST(@StartYear AS VARCHAR(4)) + '-' + 
        RIGHT(CAST(@EndYear AS VARCHAR(4)), 2)

    -- ==============================
    -- GET MAX RUNNING NUMBER
    -- ==============================
    SELECT 
        @NextNumber = ISNULL(MAX(
            TRY_CAST(RIGHT(UserCode, 3) AS INT)
        ), 0) + 1
    FROM tbl_UserMaster
    WHERE UserCode LIKE 'AL/' + @FinancialYear + '/%'

    -- ==============================
    -- FINAL CODE FORMAT
    -- AL/2026-27/001
    -- ==============================
    SET @NewCode = 
        'AL/' + @FinancialYear + '/' +
        RIGHT('000' + CAST(@NextNumber AS VARCHAR(3)), 3)

    RETURN @NewCode
END


-- Script for FN_CompanyCode
GO

CREATE FUNCTION [dbo].[FN_CompanyCode]()
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @NextNumber INT
    DECLARE @NewCode VARCHAR(20)
    DECLARE @FinancialYear VARCHAR(10)
    DECLARE @StartYear INT
    DECLARE @EndYear INT

    -- ==============================
    -- FINANCIAL YEAR CALCULATION
    -- APRIL TO MARCH
    -- ==============================
    IF MONTH(GETDATE()) >= 4
    BEGIN
        SET @StartYear = YEAR(GETDATE())
        SET @EndYear = YEAR(GETDATE()) + 1
    END
    ELSE
    BEGIN
        SET @StartYear = YEAR(GETDATE()) - 1
        SET @EndYear = YEAR(GETDATE())
    END

    -- FORMAT : 2026-27
    SET @FinancialYear = 
        CAST(@StartYear AS VARCHAR(4)) + '-' + 
        RIGHT(CAST(@EndYear AS VARCHAR(4)), 2)

    -- ==============================
    -- GET MAX RUNNING NUMBER
    -- ==============================
    SELECT 
        @NextNumber = ISNULL(MAX(
            TRY_CAST(RIGHT(CompanyCode, 3) AS INT)
        ), 0) + 1
    FROM tbl_CompanyMain
    WHERE CompanyCode LIKE @FinancialYear + '/%'

    -- ==============================
    -- FINAL CODE FORMAT
    -- 2026-27/001
    -- ==============================
    SET @NewCode = 
        @FinancialYear + '/' +
        RIGHT('000' + CAST(@NextNumber AS VARCHAR(3)), 3)

    RETURN @NewCode
END

-- Script for FN_WorkOrderNo
GO
CREATE FUNCTION dbo.FN_WorkOrderNo()
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @NextNumber INT
    DECLARE @NewCode VARCHAR(20)
    DECLARE @FinancialYear VARCHAR(10)
    DECLARE @StartYear INT
    DECLARE @EndYear INT

    IF MONTH(GETDATE()) >= 4
    BEGIN
        SET @StartYear = YEAR(GETDATE())
        SET @EndYear = YEAR(GETDATE()) + 1
    END
    ELSE
    BEGIN
        SET @StartYear = YEAR(GETDATE()) - 1
        SET @EndYear = YEAR(GETDATE())
    END

    SET @FinancialYear =
        CAST(@StartYear AS VARCHAR(4))
        + '-'
        + RIGHT(CAST(@EndYear AS VARCHAR(4)), 2)

    SELECT
        @NextNumber = ISNULL(MAX(
            TRY_CAST(RIGHT(SeriesNo, 3) AS INT)
        ), 0) + 1
    FROM tbl_WorkOrderHdr
    WHERE SeriesNo LIKE 'WO/' + @FinancialYear + '/%'

    SET @NewCode =
        'WO/' + @FinancialYear + '/'
        + RIGHT('000' + CAST(@NextNumber AS VARCHAR(3)), 3)

    RETURN @NewCode
END

-- Script for FN_ProductNo
GO
CREATE FUNCTION [dbo].[FN_ProductNo]()
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @NextNumber INT;
    DECLARE @NewCode VARCHAR(20);

    SELECT
        @NextNumber = ISNULL(
            MAX(TRY_CAST(RIGHT(ProductCode, 3) AS INT)),
            0
        ) + 1
    FROM [dbo].[tbl_ProdcutMaster]
    WHERE ProductCode LIKE 'P%';

    SET @NewCode =
        'P' + RIGHT('000' + CAST(@NextNumber AS VARCHAR(3)), 3);

    RETURN @NewCode;
END;



-- TRIGGERS

